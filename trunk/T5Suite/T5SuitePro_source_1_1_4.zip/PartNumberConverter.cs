using System;
using System.Collections.Generic;
using System.Text;

namespace T5SuitePro
{
    class PartNumberConverter
    {
        public PartNumberConverter()
        {

        }

        public ECUInformation GetECUInfo(string partnumber, string enginetype)
        {
            //4903 = for high altitude use!
            ECUInformation returnvalue = new ECUInformation();

            returnvalue.Tunedbyt5stostage = 0;
            if (enginetype.EndsWith("T5S1")) returnvalue.Tunedbyt5stostage = 1;
            else if (enginetype.EndsWith("T5S2")) returnvalue.Tunedbyt5stostage = 2;
            else if (enginetype.EndsWith("T5S3")) returnvalue.Tunedbyt5stostage = 3;

            switch (partnumber)
            {
                /*case "4300851":
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    break;*/
                case "4302998":
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    break;
                case "4302980":
                    returnvalue.Isaero = false;
                    returnvalue.Isfpt = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Bhp = 200;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                /*case "4301917":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Bhp = 200;
                    break;*/
                /*case "4301909":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Bhp = 170;
                    break;*/
                case "4781845":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4660833":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 154;
                    returnvalue.Enginetype = EngineType.B204E;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2529;
                    break;
                /*case "4300828":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Bhp = 200;
                    break;*/
                /*case "4300836":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Bhp = 170;
                    break;*/
                case "4300877":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4302972":
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "07B95":
                    // hirsch tuned file, invalid for tuning
                    break;
                case "9136490":
                    //9000 B234L 1993
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4300810":
                    //1993 9000 B234R 
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "9136516":
                    //91 36 516 88 28 196 1993 9000 B234R/TCS 
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4300356":
                    //43 00 356 43 00 356 1994 9000 B234I 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 150;
                    returnvalue.Enginetype = EngineType.B234I;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Turbomodel = TurboModel.None;
                    break;
                case "4300851":
                    //43 00 851 43 00 851 1994 9000 B234R (No TCS) 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4300414":
                    //43 00 414 43 00 414 1994 9000 B234R/TCS 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4300828":
                    //43 00 828 43 00 828 1994 9000 B234L 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4903886":
                    //49 03 886 49 03 886 1994-1995 9000 B234E
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4903902":
                    //49 03 902 49 03 902 1994-1995 9000 B234L 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4903928":
                    //49 03 928 49 03 928 1994 1995 9000 B234R
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4301909":
                    //43 01 909 43 01 909 1995 9000 B234E 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4301917":
                    //43 01 917 43 01 917 1995 9000 B234L & Aero A/T 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4301974":
                    //43 01 974 43 01 974 1995 9000 B234R/TCS Aero M/T 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4660338":
                    //46 60 338 46 60 338 1995 9000 B234R (No TCS) 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4300364":
                    //43 00 364 43 00 364 1996 9000 B234E 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4300836":
                    //43 00 836 43 00 836 1996 9000 B234L/R A/T 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Enginetype = EngineType.B234L;
                    break;
                case "4300422":
                    //43 00 422 43 00 422 1996 9000 B234R 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4780243":
                    //47 80 243 47 80 243 1997 9000 B234E 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    break;
                case "4780250":
                    //47 80 250 47 80 250 1997 9000 B234L 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4780268":
                    //47 80 268 47 80 268 1997 9000 B234R 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4611737":
                    //46 11 737 47 81 878 1998 9000 B234L 
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4611752":
                    //46 11 752 47 81 894 1998 9000 B234R 
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                case "4903894":
                    //49 03 894 49 03 894 1996-1998 9000 B234E
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 170;
                    returnvalue.Enginetype = EngineType.B234E;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4903910":
                    //49 03 910 49 03 910 1996-1998 9000 B234L
                    returnvalue.Isaero = false;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Enginetype = EngineType.B234L;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretTB2531;
                    break;
                case "4903936":
                    //49 03 936 49 03 936 1996-1998 9000 B234R
                    returnvalue.Isaero = true;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Valid = true;
                    returnvalue.Bhp = 225;
                    returnvalue.Carmodel = CarModel.Saab9000;
                    returnvalue.Enginetype = EngineType.B234R;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.MitsuTD04;
                    break;
                    // 93 software versions
                case "4780656": // 9-3 B204R M/T Stock = 1 bar boost pressure
                case "5171491": // 9-3 B204R M/T
                    returnvalue.Isaero = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Valid = true;
                    returnvalue.Enginetype = EngineType.B204R;
                    returnvalue.Bhp = 200;
                    returnvalue.Stage1boost = 1.15; 
                    returnvalue.Stage2boost = 1.25; 
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;
                    break;
                case "4611919":// 9-3 B204L M/T
                    returnvalue.Isaero = false;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Enginetype = EngineType.B204L;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Bhp = 185;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;
                    break;
                case "4782496": //9-3 B204L M/T
                    returnvalue.Isaero = false;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Enginetype = EngineType.B204L;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Bhp = 185;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;

                    break;
                case "4611935": //9-3 B204L A/T
                    returnvalue.Isaero = false;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Enginetype = EngineType.B204L;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Bhp = 185;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;

                    break;
                case "4782538": //9-3 B235R Viggen
                    returnvalue.Isaero = true;
                    //returnvalue.Isviggen = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Enginetype = EngineType.B235R;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Bhp = 225;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;

                    break;
                case "5166731": //9-3 B235R Viggen
                case "4571923":  //45 71 923	53 81 074	2000	9-3 B235R Viggen
                case "5166855":  //51 66 855	51 66 855	2001	9-3 B235R
                case "5169974":  //51 69 974	51 69 974	2002	9-3 B235R
                    returnvalue.Isaero = true;
                    //returnvalue.Isviggen = true;
                    returnvalue.Enginetype = EngineType.B235R;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = true;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = false;
                    returnvalue.Bhp = 225;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;


                    break;
                case "4571907": //45 71 907	53 81 108	2000	9-3 B205L
                case "5169883": //51 69 883	51 69 883	2001	9-3 B205L
                case "5169982": //51 69 982	51 69 982	2002	9-3 B205L
                    returnvalue.Isaero = false;
                    //returnvalue.Isviggen = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Enginetype = EngineType.B205L;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Bhp = 185;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;


                    break;
                case "4571915": //45 71 915	53 81 140	2000	9-3 B205R
                case "5166822": //51 66 822	51 66 822	2001	9-3 B205R
                case "5169990": //51 69 990	51 69 990	2002	9-3 B205R
                    returnvalue.Isaero = false;
                    //returnvalue.Isviggen = true;
                    returnvalue.Enginetype = EngineType.B205R;
                    returnvalue.Isturbo = true;
                    returnvalue.Carmodel = CarModel.Saab93;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Valid = true;
                    returnvalue.Isfpt = true;
                    returnvalue.Bhp = 200;
                    returnvalue.Stage1boost = 1.15;
                    returnvalue.Stage2boost = 1.25;
                    returnvalue.Stage3boost = 1.35;
                    returnvalue.Turbomodel = TurboModel.GarretT25;

                    break;
                    // saab 900 partnumbers
                case "9132671": // 91 32 671	91 32 671	1994	B204L M/T
                case "4445318": //44 45 318	44 45 318	1995	B204L M/T
                case "9132689": //91 32 689 1)	91 32 689	1996	B204L M/T
                case "4239919": //42 39 919	47 80 284	1996	B204L A/T
                case "4662565": //46 62 565 2)	47 80 276	1996	B204L M/T
                case "4780276": //47 80 276	47 80 276	1997	B204L M/T
                case "4780284": //47 80 284	47 80 284	1997	B204L A/T
                case "4781779": //47 81 779	47 81 779	1998	B204L M/T
                case "4782660": //47 82 660	51 71 848	1998	B204L A/T
                    // stock = 0.8 bar boost
                    returnvalue.Bhp = 185;
                    returnvalue.Carmodel = CarModel.Saab900SE;
                    returnvalue.Is2point3liter = false;
                    returnvalue.Isaero = false;
                    returnvalue.Enginetype = EngineType.B204L;
                    returnvalue.Isfpt = true;
                    returnvalue.Isturbo = true;
                    returnvalue.Valid = true;
                    returnvalue.Stage1boost = 1.0;
                    returnvalue.Stage2boost = 1.1;
                    returnvalue.Stage3boost = 1.2;
                    returnvalue.Turbomodel = TurboModel.GarretT25;

                    break;
            }
            return returnvalue;
        }
    }

    enum CarModel : int
    {
        Unknown = 0,
        Saab900 = 1,
        Saab9000 = 2,
        Saab900SE = 3,
        Saab93 = 4,
        Saab95 = 5
    }

    enum EngineType : int
    {
        Unknown,
        B204,
        B204E,
        B204L,
        B204R,
        B205,
        B205E,
        B205L,
        B205R,
        B234,
        B234I,
        B234E,
        B234L,
        B234R,
        B235,
        B235E,
        B235L,
        B235R
    }

    enum TurboModel : int
    {
        None,
        GarretT25,
        GarretTB2529,
        GarretTB2531,
        MitsuTD04
    }

    class ECUInformation
    {
        double _stage1boost = 1.15;

        public double Stage1boost
        {
            get { return _stage1boost; }
            set { _stage1boost = value; }
        }
        double _stage2boost = 1.25;

        public double Stage2boost
        {
            get { return _stage2boost; }
            set { _stage2boost = value; }
        }
        double _stage3boost = 1.35;

        public double Stage3boost
        {
            get { return _stage3boost; }
            set { _stage3boost = value; }
        }

        private EngineType _enginetype = EngineType.Unknown;

        internal EngineType Enginetype
        {
            get { return _enginetype; }
            set { _enginetype = value; }
        }

        private CarModel _carmodel = CarModel.Unknown;

        internal CarModel Carmodel
        {
            get { return _carmodel; }
            set { _carmodel = value; }
        }

        private TurboModel _turbomodel = TurboModel.None;

        internal TurboModel Turbomodel
        {
            get { return _turbomodel; }
            set { _turbomodel = value; }
        }


        private bool _valid = false;

        public bool Valid
        {
            get { return _valid; }
            set { _valid = value; }
        }
        private bool _isturbo = false;

        public bool Isturbo
        {
            get { return _isturbo; }
            set { _isturbo = value; }
        }
        private bool _isaero = false;

        public bool Isaero
        {
            get { return _isaero; }
            set { _isaero = value; }
        }
        private bool _isfpt = false;

        public bool Isfpt
        {
            get { return _isfpt; }
            set { _isfpt = value; }
        }
        private bool _is2point3liter = false;

        public bool Is2point3liter
        {
            get { return _is2point3liter; }
            set { _is2point3liter = value; }
        }

        private int _bhp = 0;

        public int Bhp
        {
            get { return _bhp; }
            set { _bhp = value; }
        }

        private int _tunedbyt5stostage = 0;

        public int Tunedbyt5stostage
        {
            get { return _tunedbyt5stostage; }
            set { _tunedbyt5stostage = value; }
        }


    }
}
