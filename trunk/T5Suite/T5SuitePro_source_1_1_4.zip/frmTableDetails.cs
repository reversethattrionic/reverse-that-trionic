using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmTableDetails : DevExpress.XtraEditors.XtraForm
    {
        private bool m_issixteenbit = false;
        private int m_TableWidth = 8;
        private bool m_datasourceMutated = false;

        public bool DatasourceMutated
        {
            get { return m_datasourceMutated; }
            set { m_datasourceMutated = value; }
        }
        private bool m_SaveChanges = false;

        public bool SaveChanges
        {
            get { return m_SaveChanges; }
            set { m_SaveChanges = value; }
        }
        private byte[] m_map_content;

        public byte[] Map_content
        {
            get { return m_map_content; }
            set { m_map_content = value; }
        }
        private Int32 m_map_address = 0;

        public Int32 Map_address
        {
            get { return m_map_address; }
            set { m_map_address = value; }
        }
        private Int32 m_map_length = 0;

        public Int32 Map_length
        {
            get { return m_map_length; }
            set { m_map_length = value; }
        }
        private string m_map_name = string.Empty;

        public string Map_name
        {
            get { return m_map_name; }
            set
            {
                m_map_name = value;
                this.Text = "Table details [" + m_map_name + "]";
            }
        }


        private string m_x_axis_name = string.Empty;

        public string X_axis_name
        {
            get { return m_x_axis_name; }
            set { m_x_axis_name = value; }
        }
        private string m_y_axis_name = string.Empty;

        public string Y_axis_name
        {
            get { return m_y_axis_name; }
            set { m_y_axis_name = value; }
        }
        private string m_z_axis_name = string.Empty;

        public string Z_axis_name
        {
            get { return m_z_axis_name; }
            set { m_z_axis_name = value; }
        }

        public frmTableDetails()
        {
            InitializeComponent();
        }

        public void ShowTable(int tablewidth, bool issixteenbits)
        {
            m_TableWidth = tablewidth;
            m_issixteenbit = issixteenbits;
            DataTable dt = new DataTable();
            if (m_map_length != 0 && m_map_name != string.Empty)
            {
                if (tablewidth > 0)
                {
                    int numberrows = (int)(m_map_length / tablewidth);
                    if (issixteenbits) numberrows /= 2;
                    int map_offset = 0;
                    /* if (numberrows > 0)
                     {*/
                    // aantal kolommen = 8

                    dt.Columns.Clear();
                    for (int c = 0; c < tablewidth; c++)
                    {
                        dt.Columns.Add(c.ToString());
                    }
                    if (issixteenbits)
                    {
                        for (int i = 0; i < numberrows; i++)
                        {
                            //ListViewItem lvi = new ListViewItem();
                            //lvi.UseItemStyleForSubItems = false;
                            object[] objarr = new object[tablewidth];
                            int b;
                            for (int j = 0; j < tablewidth; j++)
                            {
                                b = (byte)m_map_content.GetValue(map_offset++);
                                b *= 256;
                                b += (byte)m_map_content.GetValue(map_offset++);
                                if (b > 0x8000) b ^= 0xFFFF;
                                objarr.SetValue(b.ToString("X4"), j);
                                //lvi.SubItems.Add(b.ToString("X4"));
                                //lvi.SubItems[j + 1].BackColor = Color.FromArgb((int)(b / 256), 255 - (int)(b / 256), 0);
                            }
                            //listView2.Items.Add(lvi);
                            dt.Rows.Add(objarr);
                        }
                        // en dan het restant nog in een nieuwe rij zetten
                        if (map_offset < m_map_length)
                        {
                            object[] objarr = new object[tablewidth];
                            int b;
                            int sicnt = 0;
                            for (int v = map_offset; v < m_map_length /*- 1*/; v++)
                            {
                                //b = (byte)m_map_content.GetValue(map_offset++);
                                b = (byte)m_map_content.GetValue(map_offset++);
                                b *= 256;
                                b += (byte)m_map_content.GetValue(map_offset++);
                                if (b > 0x8000) b ^= 0xFFFF;
                                objarr.SetValue(b.ToString("X4"), sicnt);
                                sicnt++;
                                //lvi.SubItems[lvi.SubItems.Count - 1].BackColor = Color.FromArgb((int)(b / 256), 255 - (int)(b / 256), 0);
                            }
                            /*for (int t = 0; t < (tablewidth - 1) - sicnt; t++)
                            {
                                lvi.SubItems.Add("");
                            }*/
                            //listView2.Items.Add(lvi);
                            dt.Rows.Add(objarr);
                        }

                    }
                    else
                    {

                        for (int i = 0; i < numberrows; i++)
                        {
                            object[] objarr = new object[tablewidth];
                            byte b;
                            for (int j = 0; j < (tablewidth); j++)
                            {
                                 b = (byte)m_map_content.GetValue(map_offset++);
                                objarr.SetValue(b.ToString("X2"), j);
                            }
                            dt.Rows.Add(objarr);
                        }
                        // en dan het restant nog in een nieuwe rij zetten
                        if (map_offset < m_map_length)
                        {
                            object[] objarr = new object[tablewidth];
                            byte b;
                            int sicnt = 0;
                            for (int v = map_offset; v < m_map_length /*- 1*/; v++)
                            {
                                b = (byte)m_map_content.GetValue(map_offset++);
                                objarr.SetValue(b.ToString("X2"), sicnt);
                                sicnt++;
                            }
                            dt.Rows.Add(objarr);
                        }
                    }
                }
                gridControl1.DataSource = dt;
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (m_datasourceMutated)
            {
                DialogResult dr = MessageBox.Show("Data was mutated, do you want to save these changes in you binary?", "Warning", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    m_SaveChanges = true;
                    this.Close();
                }
                else if (dr == DialogResult.No)
                {
                    m_SaveChanges = false;
                    this.Close();
                }
                else
                {
                    // cancel
                    // do nothing
                }
            }
            else
            {
                m_SaveChanges = false;
                this.Close();
            }
        }

        private void gridView1_CustomDrawCell(object sender, DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs e)
        {
            try
            {
                if (e.CellValue != null)
                {
                    if (e.CellValue != DBNull.Value)
                    {
                        int b = Convert.ToInt32(e.CellValue.ToString(), 16);
                        
                        SolidBrush sb = new SolidBrush(Color.FromArgb(b, 255 - b , 0));

                        e.Graphics.FillRectangle(sb, e.Bounds);
                    }
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
        }

        private void gridView1_RowUpdated(object sender, DevExpress.XtraGrid.Views.Base.RowObjectEventArgs e)
        {
            m_datasourceMutated = true;
            simpleButton2.Enabled = true;
            simpleButton3.Enabled = true;
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            ShowTable(m_TableWidth, m_issixteenbit);
            simpleButton2.Enabled = false;
            simpleButton3.Enabled = false;
        }
    }
}