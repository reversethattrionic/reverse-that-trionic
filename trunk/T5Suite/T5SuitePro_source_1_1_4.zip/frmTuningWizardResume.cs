using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmTuningWizardResume : DevExpress.XtraEditors.XtraForm
    {
        public frmTuningWizardResume()
        {
            InitializeComponent();
        }

        public void SetDataTable(System.Data.DataTable dt)
        {
            gridControl1.DataSource = dt;
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}