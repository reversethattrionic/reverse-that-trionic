using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmFirmwareInfo : DevExpress.XtraEditors.XtraForm
    {

        public string CarModel
        {
            get
            {
                return textEdit1.Text;
            }
            set
            {
                textEdit1.Text = value;
                textEdit1.Properties.MaxLength = textEdit1.Text.Length;
            }
        }

        public string EngineType
        {
            get
            {
                return textEdit2.Text;
            }
            set
            {
                textEdit2.Text = value;
                textEdit2.Properties.MaxLength = textEdit2.Text.Length;

            }
        }

        public string PartNumber
        {
            get
            {
                return textEdit3.Text;
            }
            set
            {
                textEdit3.Text = value;
                textEdit3.Properties.MaxLength = textEdit3.Text.Length;

            }
        }

        public string SoftwareID
        {
            get
            {
                return textEdit4.Text;
            }
            set
            {
                textEdit4.Text = value;
                textEdit4.Properties.MaxLength = textEdit4.Text.Length;

            }
        }

        public string VSSCode
        {
            get
            {
                return textEdit5.Text;
            }
            set
            {
                textEdit5.Text = value;
                textEdit5.Properties.MaxLength = textEdit5.Text.Length;

            }
        }

        public Int32 Checksum
        {
            get
            {
                return Convert.ToInt32(textEdit6.Text, 16) ;
            }
            set
            {
                try
                {
                    textEdit6.Text = value.ToString("X4");
                    textEdit6.Properties.MaxLength = textEdit6.Text.Length;
                }
                catch (Exception E)
                {
                    Console.WriteLine("Failed to determine checksum in info screen: "+ E.Message );
                }

            }
        }

        public bool VSSEnabled
        {
            get
            {
                return checkEdit1.Checked;
            }
            set
            {
                checkEdit1.Checked = value;
            }
        }

        public bool AutoGearBox
        {
            get
            {
                return checkEdit2.Checked;
            }
            set
            {
                checkEdit2.Checked = value;
            }
        }

        public bool HeatplatesPresent
        {
            get
            {
                return checkEdit3.Checked;
            }
            set
            {
                checkEdit3.Checked = value;
            }
        }


        public frmFirmwareInfo()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}