using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmChecksumVerification : DevExpress.XtraEditors.XtraForm
    {
        public frmChecksumVerification()
        {
            InitializeComponent();
        }

        private string m_filechecksum = string.Empty;

        public string Filechecksum
        {
            get { return m_filechecksum; }
            set
            {
                m_filechecksum = value;
                lblFileChecksum.Text = "0x" + m_filechecksum;
            }
        }
        private string m_calcchecksum = string.Empty;

        public string Calcchecksum
        {
            get { return m_calcchecksum; }
            set
            {
                m_calcchecksum = value;
                lblCalculatedChecksum.Text = "0x" + m_calcchecksum;
            }
        }

        private string m_message = string.Empty;

        public string Message
        {
            get { return m_message; }
            set
            {
                m_message = value;
                labelControl5.Text = m_message;
                labelControl5.ForeColor = Color.Red;
                simpleButton1.Enabled = true;
            }
        }

        


        private void simpleButton2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}