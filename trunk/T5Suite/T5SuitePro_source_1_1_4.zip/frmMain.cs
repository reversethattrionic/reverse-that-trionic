#region todolist
// 1.  Symbol compare between 2 binaries: results in symbol list with differences, uses 2 symbol collections & takes time! ( done )
// 2.  open maps in dockpanel in stead of in new windows.  ( done )
// 3.  Keep track of changes made in binary, mark the changed symbols in the symbol list ( done )
// 4.  Import the exported maps from excel! ( done )
// 16. Save the symbols and data (ischanged parameter also) to XML file so that it can be re-loaded next time the program runs. This will result in a repository of XML files so that the symbol don't need to be parsed every time.  ( done )
// 18. Auto reload last selected binary from XML at startup (save filename to registry/ini) ( done )
// 26. MapViewer, increment and decrement selection (+/-) ( done )
// 30. Standaard filter aan op symbollist met flashaddress > 0 ( done )
// 20. to_ecu.s19 overschrijven als ie al bestaat ( done )
// 25. MapViewer, fill optie maken, niet nodig, +/- ( done )
// 26. MapViewer, increment and decrement percentage .. not needed +/- is sufficient! ( done )
// 28. MapViewer, average increase / decrease per map, number of changed bytes, percentage of changed bytes ( done )
// 31. MapViewer, add axis values (customdrawindicator etc) ( done )
// 33. Auto adjust mapviewer width to number of columns in viewer! ( done )
// 34. Auto adjust columnheader text with (X4/X2) in hexmode to the maximum value for the xaxislabel in MapViewer ( done )
// 32. Add user manual and T5 document in HTML (2 browsers in 2 dockpanels) (done)
// 36. When opening a symbol, check for exsistance and if already open, show tab. (done)
// Hessu: decimal places in mapviewer not rounded and not limited to 2 digits ( done )
// Hessu: when opening symbol from window "symbols found in binary" to view symbol data and there are allready
//        some opened "symbol data" windows, should just opened window get top/active in "symbol data" window ( done )
// Hessu: when opening binary, t5suite wont recommended/fix/verify checksum automatically or give recommendation to fix.. ( done )
// 11. Auto update checksum on save (option) ( done )
// 13. Interface with PE micro flash tool (command line parameters) (done, test)
// 19. In pe micro interface cfg file instelbaar o.i.d. ( niet nodig )
// 23. Bij schrijven naar pe micro checksum controleren en vragen om te updaten als nodig (daana pas bin -> s19 doen) ( done )
// 24. Bij lezen van pe micro checksum controleren en vragen om te updaten als nodig (s19 bestand overschijven na update) ( done )
// 12. Auto save S19 file next to binary ( done )
// Hessu: Once when i edit maps with tunerpro, opened it to t5suite and i burn it to ecu.. In first startup i get Check engine.. ;) ( done )
// Hessu: View tables in hex wont cause any chances in allreay opened maps (switching should work globally) ( done )
// 21. bij lezen van pe mirco bestandsnaam instelbaar maken (kopie maken van fromecu_xxx.s19) ( done )
// Hessu: Rpm limitter views "wrong" value. (2x8bit? Should be 16bit?)  ( done )
// Hessu: Should some like "tryk_vakt_tab!,Regl_tryck_?gm!, reg_kon_mat! &etc.. Maps 
//        turn 90 dec to one column with many rows. Takes less horizontal space in 
//        display and more easy to read than about ~5x5 matrix without all/any rpm 
//        values. I think that eg. Reg_con_mat x/y axis values can hardcode from 
//        2500-5500 scale because its hardcoded in binary. ( done )

// 5.  Auto backup binary file when changes made (option, default on)
// 6.  Internal 3d surface chart for map viewing / editing ( progress )
// 7.  Complete the symbol descriptions 
// 8.  Complete x, y and z axis conversion for all symbols
// 9.  Mark important maps for tuning as important
// 10. Create a tuning wizard that takes to user through all important tuning maps / symbols (convert to stage x wizard)
// 14. All routines to .NET assembly in stead of inside the application (file access, helpers, collections etc)
// 15. Include different map sets for stage 1 - x for different models/hardware setups in a repository. (XML, all symbols?)
// 17. Indicate group of symbol by color / icon (Fuel, Ignition, Boost, Misc, etc). ( done, extend symbol information )
// 22. Bij schrijven naar pe micro, bestand opslaan (bin)
// 27. MapViewer, Shape option (normalcurve, gaussian curve?!)
// 29. Engine emulator maken!!!
// 35. Extract symbol information tables from the application and store them into a XML file (symbolname, descr, type (fuel, ign), data with (8/16 bit) axis names etc)
// Hessu: "3bar map view" feature shows all important (boost, fuel, ignition) maps with x/y/z values scaled to *1.2
// Hessu: "3bar converting wizard" feature that rescale .bin files all nesessary maps works with 3 bar map sensor hardware.
// 1 instellingenscherm maken met alle opties?
// T7 ondersteuning. 
        //T5SymbolHelper maken waarin alle T5 info zit en T7SymbolHelper
        //T5FileParser maken 
        //T7FileParser maken


 
#endregion


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.Mail;
using Microsoft.Office.Interop.Excel;
//using System.Data.Odbc;
using System.Data.OleDb;
using Microsoft.Win32;
using PSTaskDialog;

namespace T5SuitePro
{
    public partial class frmMain : Form
    {
        string m_currentfile = string.Empty;
        msiupdater m_msiUpdater;
        private Microsoft.Office.Interop.Excel.Application xla;
        //int m_current_endoffile = 0;
        SymbolCollection m_symbols = new SymbolCollection();
        AddressLookupCollection m_addresslookup = new AddressLookupCollection();
        myListViewColumnSorter listviewsorter = new myListViewColumnSorter();
        private AppSettings m_appSettings = new AppSettings();
        private bool from_prog_change = false;
        private bool m_fileiss19 = false;
        private string m_currentsramfile = string.Empty;
        private System.Data.DataTable m_symbolInfoTable = new System.Data.DataTable("SYMBOLINFO");
        //private Engine m_engine;
        System.Data.DataTable mrudt = new System.Data.DataTable();
        System.Data.DataTable _symbolnameHelper = new System.Data.DataTable();

        public frmMain()
        {
            frmSplash splash = new frmSplash();
            splash.Show();
            System.Windows.Forms.Application.DoEvents();
            InitializeComponent();
            if (!File.Exists(System.Windows.Forms.Application.StartupPath + "\\SymbolInfo.xml"))
            {
                CreateSymbolInfoTable();
            }
        }

        private void CreateSymbolInfoTable()
        {
            m_symbolInfoTable.Columns.Add("SYMBOLNAME");
            m_symbolInfoTable.Columns.Add("SYMBOLDESCRIPTION");
            m_symbolInfoTable.Columns.Add("XAXIS_SYMBOL");
            m_symbolInfoTable.Columns.Add("YAXIS_SYMBOL");
            m_symbolInfoTable.Columns.Add("ZAXIS_SYMBOL");
            m_symbolInfoTable.Columns.Add("SYMBOL_SIXTEENBIT", Type.GetType("System.Boolean"));
            m_symbolInfoTable.Columns.Add("SYMBOL_UPSIDEDOWN", Type.GetType("System.Boolean"));
            m_symbolInfoTable.Columns.Add("SYMBOL_CORRECTIONFACTOR", Type.GetType("System.Double"));
            m_symbolInfoTable.Columns.Add("SYMBOL_CORRECTIONOFFSET", Type.GetType("System.Double"));
            m_symbolInfoTable.Columns.Add("SYMBOL_TYPE", Type.GetType("System.Int32"));

        }

        private void LoadDocumentation()
        {
            try
            {
                if (File.Exists(System.Windows.Forms.Application.StartupPath + "//user_manual.mht"))
                {
                    webBrowserUserManual.Navigate(System.Windows.Forms.Application.StartupPath + "//user_manual.mht");
                }
                else
                {
                    dockPanel1.Hide();
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
            try
            {
                if (File.Exists(System.Windows.Forms.Application.StartupPath + "//T5_documentation.mht"))
                {
                    webBrowserDocumentation.Navigate(System.Windows.Forms.Application.StartupPath + "//T5_documentation.mht");
                }
                else
                {
                    dockPanel2.Hide();
                }
            }
            catch (Exception E2)
            {
                Console.WriteLine(E2.Message);
            }
        }

        private void SetDefaultFilters()
        {
            DevExpress.XtraGrid.Columns.ColumnFilterInfo fltr = new DevExpress.XtraGrid.Columns.ColumnFilterInfo(@"([FLASHADDRESS] > 0)", "Only symbols within binary");
            gridViewSymbols.ActiveFilter.Clear();
            gridViewSymbols.ActiveFilter.Add(gcSymbolsFlash, fltr);
            /*** set filter ***/
            gridViewSymbols.ActiveFilterEnabled = true;
        }

        

        private void TryToLoadFile(string filename)
        {
            try
            {
                OpenFile(filename);
            }
            catch (Exception E)
            {
                MessageBox.Show("Failed to open file: " + filename + " error: " + E.Message);
            }
        }

        private void dockSymbols_Click(object sender, EventArgs e)
        {

        }

        private void StartTableViewer()
        {
            if (gridViewSymbols.SelectedRowsCount > 0)
            {
                int[] selrows = gridViewSymbols.GetSelectedRows();
                if (selrows.Length > 0)
                {
                    DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                    DevExpress.XtraBars.Docking.DockPanel dockPanel;
                    DevExpress.XtraBars.Docking.DockPanel sramdockPanel;
                    bool pnlfound = false;
                    bool srampnlfound = false;
                    try
                    {
                        foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                        {
                            if (pnl.Text == "Symbol: " + dr.Row["SYMBOLNAME"].ToString() + " [" + Path.GetFileName(m_currentfile) + "]")
                            {
                                dockPanel = pnl;
                                pnlfound = true;
                                dockPanel.Show();
                                // nog data verversen?

                            }
                            if (pnl.Text == "SRAM Symbol: " + dr.Row["SYMBOLNAME"].ToString() + " [" + Path.GetFileName(m_currentfile) + "]")
                            {
                                sramdockPanel = pnl;
                                srampnlfound = true;
                                //sramdockPanel.Show();
                                // nog data verversen?

                            }
                        }
                    }
                    catch (Exception E)
                    {
                        Console.WriteLine(E.Message);
                    }
                    if (!pnlfound)
                    {
                        dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                        //dockPanel = dockManager1.AddPanel(DevExpress.XtraBars.Docking.DockingStyle.Fill);
                        MapViewer tabdet = new MapViewer();
                        tabdet.Filename = m_currentfile;
                        tabdet.GraphVisible = m_appSettings.ShowGraphs;
                        if (barViewInHex.Checked)
                        {
                            tabdet.Viewtype = ViewType.Hexadecimal;
                        }
                        else
                        {
                            tabdet.Viewtype = ViewType.Easy;
                        }
                        //tabdet.IsHexMode = barViewInHex.Checked;
                        tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
                        tabdet.Map_name = dr.Row["SYMBOLNAME"].ToString();
                        tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
                        tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
                        tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
                        tabdet.Y_axisvalues = GetYaxisValues(tabdet.Map_name);
                        // z, y and z axis to do
                        string xdescr = string.Empty;
                        string ydescr = string.Empty;
                        string zdescr = string.Empty;
                        GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
                        tabdet.X_axis_name = xdescr;
                        tabdet.Y_axis_name = ydescr;
                        tabdet.Z_axis_name = zdescr;
                        int columns = 8;
                        int rows = 8;
                        int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                        int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                        int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"].ToString());
                        if (address != 0)
                        {
                            if (address > 0x40000) address -= 0x40000;
                            tabdet.Map_address = address;
                            tabdet.Map_sramaddress = sramaddress;
                            int length = Convert.ToInt32(dr.Row["LENGTHBYTES"].ToString());
                            tabdet.Map_length = length;
                            byte[] mapdata = readdatafromfile(m_currentfile, address, length);
                            tabdet.Map_content = mapdata;
                            tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
                            tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
                            tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
                            tabdet.ShowTable(columns, isSixteenBitTable(tabdet.Map_name));
                            tabdet.Dock = DockStyle.Fill;
                            tabdet.onSymbolSave += new MapViewer.NotifySaveSymbol(tabdet_onSymbolSave);
                            tabdet.onClose += new MapViewer.ViewerClose(tabdet_onClose);
                            tabdet.onAxisLock += new MapViewer.NotifyAxisLock(tabdet_onAxisLock);
                            tabdet.onSliderMove += new MapViewer.NotifySliderMove(tabdet_onSliderMove);
                            tabdet.onSelectionChanged += new MapViewer.SelectionChanged(tabdet_onSelectionChanged);
                            tabdet.onSplitterMoved += new MapViewer.SplitterMoved(tabdet_onSplitterMoved);
                            tabdet.onSurfaceGraphViewChanged += new MapViewer.SurfaceGraphViewChanged(tabdet_onSurfaceGraphViewChanged);
                            tabdet.onGraphSelectionChanged += new MapViewer.GraphSelectionChanged(tabdet_onGraphSelectionChanged);
                            tabdet.onViewTypeChanged += new MapViewer.ViewTypeChanged(tabdet_onViewTypeChanged);

                            dockPanel.Controls.Add(tabdet);
                            //dockPanel.DockAsTab(dockPanel1);
                            dockPanel.Text = "Symbol: " + tabdet.Map_name + " [" + Path.GetFileName(m_currentfile) + "]";
                            bool isDocked = false;
                            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                            {
                                if (pnl.Text.StartsWith("Symbol: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                                {
                                    dockPanel.DockAsTab(pnl, 0);
                                    isDocked = true;
                                    break;
                                }
                            }
                            if (!isDocked)
                            {
                                dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
                                if (tabdet.X_axisvalues.Length > 0)
                                {
                                    dockPanel.Width = 30 + ((tabdet.X_axisvalues.Length + 1) * 35);
                                }
                                else
                                {
                                    dockPanel.Width = this.Width - dockSymbols.Width - 10;

                                }
                                if (dockPanel.Width < 400) dockPanel.Width = 400;

                            }

                            /*                        tabdet.ShowDialog();
                                                    if (tabdet.DatasourceMutated && tabdet.SaveChanges)
                                                    {
                                                        // save data to binary
                                                        savedatatobinary(tabdet.Map_address, tabdet.Map_length, tabdet.Map_content);
                                                    }*/
                        }
                     
                    }
                    if (!srampnlfound)
                    {
                        // ook openen
                        // show sram equivalent for the current symbol
                        if (m_currentsramfile != string.Empty)
                        {

                            try
                            {
                                if (dr.Row["SRAMADDRESS"] != DBNull.Value)
                                {
                                    int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"]);
                                    int length = Convert.ToInt32(dr.Row["LENGTHBYTES"]);
                                    StartSRAMTableViewer();
                                }
                            }
                            catch (Exception E)
                            {
                                Console.WriteLine(E.Message);
                            }
                        }
                    }
                    
                    /**/
                    /*
                    frmTableDetails tabdet = new frmTableDetails();
                    tabdet.Map_name = dr.Row["SYMBOLNAME"].ToString();
                    int columns = 8;
                    int rows = 8;
                    int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                    int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                    if (address != 0)
                    {
                        if (address > 0x40000) address -= 0x40000;
                        tabdet.Map_address = address;
                        int length = Convert.ToInt32(dr.Row["LENGTHBYTES"].ToString());
                        tabdet.Map_length = length;
                        byte[] mapdata = readdatafromfile(m_currentfile,address, length);
                        tabdet.Map_content = mapdata;
                        tabdet.ShowTable(columns, isSixteenBitTable(tabdet.Map_name));
                        tabdet.ShowDialog();
                        if (tabdet.DatasourceMutated && tabdet.SaveChanges)
                        {
                            // save data to binary
                            savedatatobinary(tabdet.Map_address, tabdet.Map_length, tabdet.Map_content);
                        }
                    }*/
                }
            }

        }

        void tabdet_onViewTypeChanged(object sender, MapViewer.ViewTypeChangedEventArgs e)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        if (c != sender)
                        {
                            MapViewer vwr = (MapViewer)c;
                            if (vwr.Map_name == e.Mapname)
                            {
                                vwr.Viewtype = e.View;
                                vwr.ReShowTable();
                                vwr.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                if (c2 != sender)
                                {
                                    MapViewer vwr2 = (MapViewer)c2;
                                    if (vwr2.Map_name == e.Mapname)
                                    {
                                        vwr2.Viewtype = e.View;
                                        vwr2.ReShowTable();
                                        vwr2.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                if (c3 != sender)
                                {
                                    MapViewer vwr3 = (MapViewer)c3;
                                    if (vwr3.Map_name == e.Mapname)
                                    {
                                        vwr3.Viewtype = e.View;
                                        vwr3.ReShowTable();
                                        vwr3.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

        void tabdet_onSurfaceGraphViewChanged(object sender, MapViewer.SurfaceGraphViewChangedEventArgs e)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        if (c != sender)
                        {
                            MapViewer vwr = (MapViewer)c;
                            if (vwr.Map_name == e.Mapname)
                            {
                                vwr.SetSurfaceGraphView(e.Pov_x, e.Pov_y, e.Pov_z, e.Pan_x, e.Pan_y, e.Pov_d);
                                vwr.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                if (c2 != sender)
                                {
                                    MapViewer vwr2 = (MapViewer)c2;
                                    if (vwr2.Map_name == e.Mapname)
                                    {
                                        vwr2.SetSurfaceGraphView(e.Pov_x, e.Pov_y, e.Pov_z, e.Pan_x, e.Pan_y, e.Pov_d);
                                        vwr2.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                if (c3 != sender)
                                {
                                    MapViewer vwr3 = (MapViewer)c3;
                                    if (vwr3.Map_name == e.Mapname)
                                    {
                                        vwr3.SetSurfaceGraphView(e.Pov_x, e.Pov_y, e.Pov_z, e.Pan_x, e.Pan_y, e.Pov_d);
                                        vwr3.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

        void tabdet_onSplitterMoved(object sender, MapViewer.SplitterMovedEventArgs e)
        {
            // andere cell geselecteerd, doe dat ook bij andere viewers met hetzelfde symbool (mapname)
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        if (c != sender)
                        {
                            MapViewer vwr = (MapViewer)c;
                            if (vwr.Map_name == e.Mapname)
                            {
                                vwr.SetSplitter(e.Panel1height, e.Panel2height, e.Splitdistance, e.Panel1collapsed, e.Panel2collapsed);
                                vwr.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                if (c2 != sender)
                                {
                                    MapViewer vwr2 = (MapViewer)c2;
                                    if (vwr2.Map_name == e.Mapname)
                                    {
                                        vwr2.SetSplitter(e.Panel1height, e.Panel2height,e.Splitdistance, e.Panel1collapsed, e.Panel2collapsed);
                                        vwr2.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                if (c3 != sender)
                                {
                                    MapViewer vwr3 = (MapViewer)c3;
                                    if (vwr3.Map_name == e.Mapname)
                                    {
                                        vwr3.SetSplitter(e.Panel1height, e.Panel2height, e.Splitdistance, e.Panel1collapsed, e.Panel2collapsed);
                                        vwr3.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        void tabdet_onSelectionChanged(object sender, MapViewer.CellSelectionChangedEventArgs e)
        {
            // andere cell geselecteerd, doe dat ook bij andere viewers met hetzelfde symbool (mapname)
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        if (c != sender)
                        {
                            MapViewer vwr = (MapViewer)c;
                            if (vwr.Map_name == e.Mapname)
                            {
                                vwr.SelectCell(e.Rowhandle, e.Colindex);
                                vwr.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                if (c2 != sender)
                                {
                                    MapViewer vwr2 = (MapViewer)c2;
                                    if (vwr2.Map_name == e.Mapname)
                                    {
                                        vwr2.SelectCell(e.Rowhandle, e.Colindex);
                                        vwr2.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                if (c3 != sender)
                                {
                                    MapViewer vwr3 = (MapViewer)c3;
                                    if (vwr3.Map_name == e.Mapname)
                                    {
                                        vwr3.SelectCell(e.Rowhandle, e.Colindex);
                                        vwr3.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void SetMapSliderPosition(string filename, string symbolname, int sliderposition)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        if (vwr.Map_name == symbolname)
                        {
                            vwr.SliderPosition = sliderposition;
                            vwr.Invalidate();
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                if (vwr2.Map_name == symbolname)
                                {
                                    vwr2.SliderPosition = sliderposition;
                                    vwr2.Invalidate();
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                if (vwr3.Map_name == symbolname)
                                {
                                    vwr3.SliderPosition = sliderposition;
                                    vwr3.Invalidate();
                                }
                            }
                        }
                    }
                }
            }

        }

        void tabdet_onSliderMove(object sender, MapViewer.SliderMoveEventArgs e)
        {
            SetMapSliderPosition(e.Filename, e.SymbolName, e.SliderPosition);
        }

        private void SetMapScale(string filename, string symbolname, int axismax, int lockmode)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        if (vwr.Map_name == symbolname)
                        {
                            vwr.Max_y_axis_value = axismax;
                            //vwr.ReShowTable(false);
                            vwr.LockMode = lockmode;
                            vwr.Invalidate();
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                if (vwr2.Map_name == symbolname)
                                {
                                    vwr2.Max_y_axis_value = axismax;
                                    //vwr2.ReShowTable(false);
                                    vwr2.LockMode = lockmode;
                                    vwr2.Invalidate();
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                if (vwr3.Map_name == symbolname)
                                {

                                    vwr3.Max_y_axis_value = axismax;
                                    vwr3.LockMode = lockmode;
                                    //vwr3.ReShowTable(false);
                                    vwr3.Invalidate();
                                }
                            }
                        }
                    }
                }
            }

        }

        private int FindMaxTableValue(string symbolname, int orgvalue)
        {
            int retval = orgvalue;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        if (vwr.Map_name == symbolname)
                        {
                            if (vwr.MaxValueInTable > retval) retval = vwr.MaxValueInTable;
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                if (vwr2.Map_name == symbolname)
                                {
                                    if (vwr2.MaxValueInTable > retval) retval = vwr2.MaxValueInTable;
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                if (vwr3.Map_name == symbolname)
                                {
                                    if (vwr3.MaxValueInTable > retval) retval = vwr3.MaxValueInTable;
                                }
                            }
                        }
                    }
                }
            }
            return retval;
        }

        void tabdet_onAxisLock(object sender, MapViewer.AxisLockEventArgs e)
        {
            int axismaxvalue = e.AxisMaxValue;
            if (e.LockMode == 1)
            {
                axismaxvalue = FindMaxTableValue(e.SymbolName, axismaxvalue);
            }
            SetMapScale(e.Filename, e.SymbolName, axismaxvalue, e.LockMode);
        }

        private void StartSRAMTableViewer()
        {
            if (gridViewSymbols.SelectedRowsCount > 0)
            {
                int[] selrows = gridViewSymbols.GetSelectedRows();
                if (selrows.Length > 0)
                {
                    DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                    DevExpress.XtraBars.Docking.DockPanel dockPanel;
                    bool pnlfound = false;
                    foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                    {
                        if (pnl.Text == "SRAM Symbol: " + dr.Row["SYMBOLNAME"].ToString() + " [" + Path.GetFileName(m_currentsramfile) + "]")
                        {
                            dockPanel = pnl;
                            pnlfound = true;
                            dockPanel.Show();
                        }
                    }
                    if (!pnlfound)
                    {
                        dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                        MapViewer tabdet = new MapViewer();
                        tabdet.Filename = m_currentsramfile;
                        tabdet.GraphVisible = m_appSettings.ShowGraphs;
                        //tabdet.IsHexMode = barViewInHex.Checked;
                        if (barViewInHex.Checked)
                        {
                            tabdet.Viewtype = ViewType.Hexadecimal;
                        }
                        else
                        {
                            tabdet.Viewtype = ViewType.Easy;
                        }
                        tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
                        tabdet.Map_name = dr.Row["SYMBOLNAME"].ToString();
                        tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
                        tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
                        tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
                        tabdet.Y_axisvalues = GetYaxisValues(tabdet.Map_name);
                        // z, y and z axis to do
                        string xdescr = string.Empty;
                        string ydescr = string.Empty;
                        string zdescr = string.Empty;
                        GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
                        tabdet.X_axis_name = xdescr;
                        tabdet.Y_axis_name = ydescr;
                        tabdet.Z_axis_name = zdescr;
                        int columns = 8;
                        int rows = 8;
                        int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                        int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                        int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"].ToString());
                        if (sramaddress != 0)
                        {
                            if (address > 0x40000) address -= 0x40000;
                            tabdet.Map_address = address;
                            tabdet.Map_sramaddress = sramaddress;
                            int length = Convert.ToInt32(dr.Row["LENGTHBYTES"].ToString());
                            tabdet.Map_length = length;
                            byte[] mapdata = readdatafromSRAMfile(m_currentsramfile, sramaddress, length);
                            tabdet.Map_content = mapdata;
                            tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
                            tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
                            tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
                            tabdet.ShowTable(columns, isSixteenBitTable(tabdet.Map_name));
                            tabdet.IsRAMViewer = true;
                            tabdet.Dock = DockStyle.Fill;
                            tabdet.onSymbolSave += new MapViewer.NotifySaveSymbol(tabdet_onSymbolSave);
                            tabdet.onClose += new MapViewer.ViewerClose(tabdet_onClose);
                            tabdet.onAxisLock += new MapViewer.NotifyAxisLock(tabdet_onAxisLock);
                            tabdet.onSliderMove += new MapViewer.NotifySliderMove(tabdet_onSliderMove);
                            tabdet.onSelectionChanged +=new MapViewer.SelectionChanged(tabdet_onSelectionChanged);
                            tabdet.onSplitterMoved += new MapViewer.SplitterMoved(tabdet_onSplitterMoved);
                            tabdet.onSurfaceGraphViewChanged += new MapViewer.SurfaceGraphViewChanged(tabdet_onSurfaceGraphViewChanged);
                            tabdet.onGraphSelectionChanged += new MapViewer.GraphSelectionChanged(tabdet_onGraphSelectionChanged);
                            tabdet.onViewTypeChanged += new MapViewer.ViewTypeChanged(tabdet_onViewTypeChanged);


                            dockPanel.Controls.Add(tabdet);
                            //dockPanel.DockAsTab(dockPanel1);
                            dockPanel.Text = "SRAM Symbol: " + tabdet.Map_name + " [" + Path.GetFileName(m_currentsramfile) + "]";
                            bool isDocked = false;
                            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                            {
                                if (pnl.Text.StartsWith("SRAM Symbol: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                                {
                                    dockPanel.DockAsTab(pnl, 0);
                                    isDocked = true;
                                    break;
                                }
                            }
                            if (!isDocked)
                            {
                                dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
                                if (tabdet.X_axisvalues.Length > 0)
                                {
                                    dockPanel.Width = 30 + ((tabdet.X_axisvalues.Length + 1) * 35);
                                }
                                else
                                {
                                    dockPanel.Width = this.Width - dockSymbols.Width - 10;
                                }
                                if (dockPanel.Width < 400) dockPanel.Width = 400;

                            }
                        }
                    }
                }
            }

        }


        private void gridViewSymbols_DoubleClick(object sender, EventArgs e)
        {
            StartTableViewer();
        }

        void tabdet_onClose(object sender, EventArgs e)
        {
            // close the corresponding dockpanel
            if (sender is MapViewer)
            {
                MapViewer tabdet = (MapViewer)sender;
                string dockpanelname = "Symbol: " + tabdet.Map_name + " [" + Path.GetFileName(tabdet.Filename) + "]";
                string dockpanelname2 = "SRAM Symbol: " + tabdet.Map_name + " [" + Path.GetFileName(tabdet.Filename) + "]";
                string dockpanelname3 = "Symbol difference: " + tabdet.Map_name + " [" + Path.GetFileName(tabdet.Filename) + "]";
                foreach (DevExpress.XtraBars.Docking.DockPanel dp in dockManager1.Panels)
                {
                    if (dp.Text == dockpanelname)
                    {
                        dockManager1.RemovePanel(dp);
                        break;
                    }
                    else if (dp.Text == dockpanelname2)
                    {
                        dockManager1.RemovePanel(dp);
                        break;
                    }
                    else if (dp.Text == dockpanelname3)
                    {
                        dockManager1.RemovePanel(dp);
                        break;
                    }

                }
            }
        }

        private void MarkSymbolChanged(string symbolname)
        {
            //TODO: markeer symbol in lijst als gemuteerd!
            if (gridSymbols.DataSource != null)
            {
                System.Data.DataTable dt = (System.Data.DataTable)gridSymbols.DataSource;
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["SYMBOLNAME"] != DBNull.Value)
                    {
                        if (dr["SYMBOLNAME"].ToString() == symbolname) dr["ISCHANGED"] = true;
                    }
                }
            }
        }

        void tabdet_onSymbolSave(object sender, MapViewer.SaveSymbolEventArgs e)
        {
            if (sender is MapViewer)
            {
                // juiste filename kiezen 
                
                MapViewer tabdet = (MapViewer)sender;
                if (e.Filename == m_currentfile)
                {
                    MarkSymbolChanged(e.SymbolName);
                }
                
                savedatatobinary(e.SymbolAddress, e.SymbolLength, e.SymbolDate, e.Filename);
                MapViewer mv = (MapViewer)sender;
                mv.Map_content = readdatafromfile(e.Filename, e.SymbolAddress, e.SymbolLength);
            }
        }

        private void ExportToExcelSimple(string mapname, int address, int length, byte[] mapdata, int cols, int rows, bool isSixteenbit, int[] xaxisvalues, int[] yaxisvalues)
        {
            /*CarlosAg.ExcelXmlWriter.Workbook book = new CarlosAg.ExcelXmlWriter.Workbook();
            CarlosAg.ExcelXmlWriter.Worksheet sheet = book.Worksheets.Add(mapname);
            WorksheetRow row = sheet.Table.Rows.Add();
            row.Cells.Add("Hello World");
            
            
            
            
            book.Save(@"c:\test.xls");*/

        }


        private byte[] TurnMapUpsideDown(byte[] mapdata, int numcolumns, int numrows, bool issixteenbit)
        {
            byte[] mapdatanew = new byte[mapdata.Length];
            if (issixteenbit) numcolumns *= 2;
            int internal_rows = mapdata.Length / numcolumns;
            for (int tel = 0; tel < internal_rows; tel++)
            {
                for (int ctel = 0; ctel < numcolumns; ctel++)
                {
                    int orgoffset = (((internal_rows -1) - tel) * numcolumns) + ctel;
                    mapdatanew.SetValue(mapdata.GetValue(orgoffset), (tel * numcolumns) + ctel);
                }
            }
            return mapdatanew;
        }

        private void ExportToExcel(string mapname, int address, int length, byte[] mapdata, int cols, int rows, bool isSixteenbit, int[] xaxisvalues, int[] yaxisvalues)
        {
            try
            {
                bool isupsidedown = GetMapUpsideDown(mapname);
                if (xla == null)
                {
                    xla = new Microsoft.Office.Interop.Excel.Application();
                }

                // turn mapdata upside down
                if (isupsidedown)
                {
                    mapdata = TurnMapUpsideDown(mapdata, cols, rows, isSixteenbit);
                }

                xla.Visible = true;
                Microsoft.Office.Interop.Excel.Workbook wb = xla.Workbooks.Add(XlSheetType.xlWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)xla.ActiveSheet;
                ws.Name = "symboldata";

                // Now create the chart.
                ChartObjects chartObjs = (ChartObjects)ws.ChartObjects(Type.Missing);
                ChartObject chartObj = chartObjs.Add(100, 400, 400, 300);
                Chart xlChart = chartObj.Chart;

                int nRows = rows;
                if (isSixteenbit) nRows /= 2;
                int nColumns = cols;
                string upperLeftCell = "B3";
                int endRowNumber = System.Int32.Parse(upperLeftCell.Substring(1)) + nRows - 1;
                char endColumnLetter = System.Convert.ToChar(Convert.ToInt32(upperLeftCell[0]) + nColumns - 1);
                string upperRightCell = System.String.Format("{0}{1}", endColumnLetter, System.Int32.Parse(upperLeftCell.Substring(1)));
                string lowerRightCell = System.String.Format("{0}{1}", endColumnLetter, endRowNumber);
                // Send single dimensional array to Excel:
                Range rg1 = ws.get_Range("B2", "Z2");
                double[] xarray = new double[nColumns];
                double[] yarray = new double[nRows];
                ws.Cells[1, 1] = "Data for " + mapname;
                for (int i = 0; i < xarray.Length; i++)
                {
                    if (xaxisvalues.Length > i)
                    {
                            xarray[i] = (int)xaxisvalues.GetValue(i);
                    }
                    else
                    {
                        xarray[i] = i;
                    }
                    //ws.Cells[i + 3, 1] = xarray[i];
                    ws.Cells[2, 2 + i] = xarray[i];
                }
                for (int i = 0; i < yarray.Length; i++)
                {
                    if (yaxisvalues.Length > i)
                    {
                        if (isupsidedown)
                        {
                            yarray[i] = (int)yaxisvalues.GetValue((yarray.Length - 1) - i);
                        }
                        else
                        {
                            yarray[i] = (int)yaxisvalues.GetValue(i);
                        }
                    }
                    else
                    {
                        yarray[i] = i;
                    }
                    ws.Cells[i + 3, 1] = yarray[i];
                    //ws.Cells[2, 2 + i] = yarray[i];
                }

                string xaxisdescr = "x-axis";
                string yaxisdescr = "y-axis";
                string zaxisdescr = "z-axis";
                GetAxisDescriptions(mapname, out xaxisdescr, out yaxisdescr, out zaxisdescr);
                Range rg = ws.get_Range(upperLeftCell, lowerRightCell);
                rg.Value2 = AddData(nRows, nColumns, mapdata, isSixteenbit);

                Range chartRange = ws.get_Range("A2", lowerRightCell);
                xlChart.SetSourceData(chartRange, Type.Missing);
                if (yarray.Length > 1)
                {
                    xlChart.ChartType = XlChartType.xlSurface;
                }

                // Customize axes:
                Axis xAxis = (Axis)xlChart.Axes(XlAxisType.xlCategory,
                    XlAxisGroup.xlPrimary);
                xAxis.HasTitle = true;
                xAxis.AxisTitle.Text = yaxisdescr;
                try
                {
                    Axis yAxis = (Axis)xlChart.Axes(XlAxisType.xlSeriesAxis,
                        XlAxisGroup.xlPrimary);
                    yAxis.HasTitle = true;
                    yAxis.AxisTitle.Text = xaxisdescr;
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }


                Axis zAxis = (Axis)xlChart.Axes(XlAxisType.xlValue,
                    XlAxisGroup.xlPrimary);
                zAxis.HasTitle = true;
                zAxis.AxisTitle.Text = zaxisdescr;

                // Add title:
                xlChart.HasTitle = true;

                xlChart.ChartTitle.Text = TranslateSymbolName(mapname);

                // Remove legend:
                xlChart.HasLegend = false;
                // add 3d shade
                xlChart.SurfaceGroup.Has3DShading = true;
                /*if (File.Exists(m_currentfile + "~" + mapname + ".xls"))
                {

                }*/
                wb.SaveAs(m_currentfile + "~" + mapname + ".xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, null, null, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, false, null, null, null, null);

                /* This following code is used to create Excel default color indices:
                for (int i = 0; i < 14; i++)
                {
                    string cellString = "A" + (i + 1).ToString();
                    ws.get_Range(cellString, cellString).Interior.ColorIndex = i + 1;
                    ws.get_Range(cellString, cellString).Value2 = i + 1;
                    cellString = "B" + (i + 1).ToString();
                    ws.get_Range(cellString, cellString).Interior.ColorIndex = 14 + i + 1;
                    ws.get_Range(cellString, cellString).Value2 = 14 + i + 1;
                    cellString = "C" + (i + 1).ToString();
                    ws.get_Range(cellString, cellString).Interior.ColorIndex = 2 * 14 + i + 1;
                    ws.get_Range(cellString, cellString).Value2 = 2 * 14 + i + 1;
                    cellString = "D" + (i + 1).ToString();
                    ws.get_Range(cellString, cellString).Interior.ColorIndex = 3 * 14 + i + 1;
                    ws.get_Range(cellString, cellString).Value2 = 3 * 14 + i + 1;
                }*/
            }
            catch (Exception E)
            {
                Console.WriteLine("Failed to export to excel: " + E.Message);
            }

        }

        private double[,] AddData(int nRows, int nColumns, byte[] mapdata, bool isSixteenbit)
        {
            double[,] dataArray = new double[nRows, nColumns];
            double[] xarray = new double[nColumns];
            for (int i = 0; i < xarray.Length; i++)
            {
                xarray[i] = -3.0f + i * 0.25f;
            }
            double[] yarray = xarray;
            
            int mapindex = 0;
            for (int i = 0; i < dataArray.GetLength(0); i++)
            {
                for (int j = 0; j < dataArray.GetLength(1); j++)
                {
                    if (isSixteenbit)
                    {
                        byte val1 = (byte)mapdata.GetValue(mapindex++);
                        byte val2 = (byte)mapdata.GetValue(mapindex++);
                        if (val1 == 0xff)
                        {
                            val1 = 0;
                            val2 = (byte)(0x100 - val2);
                        }
                        int ival1 = Convert.ToInt32(val1);
                        int ival2 = Convert.ToInt32(val2);
                        double value = (ival1 * 256) + ival2;
                        dataArray[i, j] = value;
                    }
                    else
                    {
                        byte val1 = (byte)mapdata.GetValue(mapindex++);
                        int ival1 = Convert.ToInt32(val1);

                        double value = ival1;
                        dataArray[i, j] = value;
                    }
                }
            }
            return dataArray;
        }



        private void savedatatobinary(int address, int length, byte[] data, string filename)
        {
            FileStream fsi1 = File.OpenWrite(filename);
            BinaryWriter bw1 = new BinaryWriter(fsi1);
            fsi1.Position = address;
            
            for (int i = 0; i < length; i++)
            {
                bw1.Write((byte)data.GetValue(i));
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();
            if (m_appSettings.AutoChecksum)
            {
                updatechecksum();
            }
            if (verifychecksum()) barButtonItem20.ImageIndex = 3;
            else barButtonItem20.ImageIndex = 2;
        }

        private void AddLogItem(string item)
        {
            /*            listBox1.Items.Add(item);
                        listBox1.SelectedIndex = listBox1.Items.Count - 1;
                        Application.DoEvents();*/
            using (StreamWriter sw = new StreamWriter(System.Windows.Forms.Application.StartupPath + "\\T5symbols.txt", true))
            {
                sw.WriteLine(item);
            }
        }

        private bool TryToAddSymbolToCollection(string hexstring, frmProgress progress, SymbolCollection curSymbolCollection)
        {
            //1A 0C 00 05 41 4D 4F 53 5F 73 74 61 74 75 73 00
            //19 3A 00 04 49 6E 74 5F 61 64 72 65 73 73
            //19 74 00 04 44 61 5F 35
            //40 B6 00 01 42 75 69 6C 64 5F 75 70 5F 74 69 6D 65 5F 73 77 69 74 63 68 21 00
            bool retval = false;
            int address = 0x00000;
            int length = 0x00;
            bool symbol_invalid = false;
            int invalid_char_count = 0;
            string name = string.Empty;
            try
            {
                address = Convert.ToInt32(hexstring.Substring(0, 5).Replace(" ", ""), 16);
                length = Convert.ToInt32(hexstring.Substring(6, 5).Replace(" ", ""), 16);
                for (int i = 12; i < hexstring.Length; i += 3)
                {
                    int val = Convert.ToInt16(hexstring.Substring(i, 3).Replace(" ", ""), 16);
                    if (val < 10) invalid_char_count++;
                    if (invalid_char_count > 2) symbol_invalid = true;
                    name += Convert.ToChar(val);
                }

                if (symbol_invalid)
                {
                    AddLogItem("Found invalid symbol: " + name + " at " + address.ToString("X4") + " len " + length.ToString("X4"));
                }
                else
                {
                    name = name.Replace("\0", "");
                    if (name.Length > 0)
                    {
                        SymbolHelper sh = new SymbolHelper();
                        sh.Varname = name;
                        sh.Start_address = address;
                        sh.Length = length;
                        curSymbolCollection.Add(sh);
                        if (name == "Tryck_mat!")
                        {
                            SymbolHelper sh2 = new SymbolHelper();
                            sh2.Varname = "Pressure map scaled for 3 bar mapsensor";
                            sh2.Start_address = address;
                            sh2.Length = length;
                            curSymbolCollection.Add(sh2);
                        }
                        if (name == "Tryck_mat_a!")
                        {
                            SymbolHelper sh2 = new SymbolHelper();
                            sh2.Varname = "Pressure map (AUT) scaled for 3 bar mapsensor";
                            sh2.Start_address = address;
                            sh2.Length = length;
                            curSymbolCollection.Add(sh2);
                        }

                        if (progress != null)
                        {
                            try
                            {
                                progress.SetProgress("Symbol " + sh.Varname + " at : " + sh.Start_address.ToString("X4"));
                            }
                            catch (Exception pE)
                            {
                                Console.WriteLine(pE.Message);
                            }
                        }
                        retval = true;
                    }
                    else
                    {
                        retval = false;
                    }
                }

            }
            catch (Exception E)
            {
                AddLogItem("Failed to convert symbol: " + E.Message);
            }
            return retval;
        }
        private void ReadAddressLookupTableFromFile(int startofsymboltable, int numberofsymbols, frmProgress progress, AddressLookupCollection curAddressLookupCollection, string filename)
        {
            // find the address lookuptable
            // this table starts with 48 79 00 04
            int readstate = 0;
            int readaddress = 0;
            int lookuptablestartaddress = 0x00;

            FileStream fs = new FileStream(filename, FileMode.Open);
            using (BinaryReader br = new BinaryReader(fs))
            {
                for (int t = 0; t < fs.Length; t++)
                {
                    byte b = br.ReadByte();

                    switch (readstate)
                    {
                        case 0:
                            // waiting for first recogintion char 48
                            if (b == 0x48)
                            {
                                lookuptablestartaddress = t;
                                readstate++;
                            }
                            break;
                        case 1:
                            // waiting for second char 79
                            if (b == 0x79)
                            {
                                readstate++;
                            }
                            else
                            {
                                lookuptablestartaddress = 0x00;
                                readstate = 0;
                            }
                            break;
                        case 2:
                            // waiting for third char 00
                            if (b == 0x00)
                            {
                                readstate++;
                            }
                            else
                            {
                                lookuptablestartaddress = 0x00;
                                readstate = 0;
                            }
                            break;
                        case 3:
                            // waiting for last char 04
                            if (b == 0x04)
                            {
                                readstate++;
                            }
                            else
                            {
                                lookuptablestartaddress = 0x00;
                                readstate = 0;
                            }
                            break;
                        default:
                            break;

                    }
                }
            }
            if (progress != null)
            {
                try
                {
                    progress.SetProgress("Found lookup table start: " + lookuptablestartaddress.ToString("X6"));
                }
                catch (Exception pE)
                {
                    Console.WriteLine(pE.Message);
                }
            }
            //fs.Flush();
            fs.Close();
            fs.Dispose();

            FileStream fs2 = new FileStream(filename, FileMode.Open);
            fs2.Seek(lookuptablestartaddress + 2, SeekOrigin.Begin);
            readaddress = lookuptablestartaddress + 2;
            using (BinaryReader br = new BinaryReader(fs2))
            {
                for (int sc = 0; sc < numberofsymbols; sc++)
                {
                    if (readaddress >= startofsymboltable) break;
                    int sramaddress = 0;
                    int flashaddress = 0;
                    byte b = br.ReadByte();
                    flashaddress = b * 256 * 256 * 256;
                    b = br.ReadByte();
                    flashaddress += (b * 256 * 256);
                    b = br.ReadByte();
                    flashaddress += (b * 256);
                    b = br.ReadByte();
                    flashaddress += (b);
                    // 8 x dummy
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    b = br.ReadByte();
                    // lees sram adres
                    b = br.ReadByte();
                    sramaddress = (b * 256);
                    b = br.ReadByte();
                    sramaddress += (b);
                    AddressLookupHelper alh = new AddressLookupHelper();
                    alh.Flash_address = flashaddress;
                    alh.Sram_adddress = sramaddress;
                    curAddressLookupCollection.Add(alh);
                    if (progress != null)
                    {
                        try
                        {
                            progress.SetProgress("Lookup entry: " + alh.Sram_adddress.ToString("X4") + " : " + alh.Flash_address.ToString("X6"));
                        }
                        catch (Exception pE)
                        {
                            Console.WriteLine(pE.Message);
                        }
                    }
                    // lees naar volgende 48 79
                    int tel = 0;
                    bool found = false;
                    int tstate = 0;
                    while (tel++ < 16 && !found)
                    {
                        byte tb = br.ReadByte();
                        switch (tstate)
                        {
                            case 0:
                                if (tb == 0x048) tstate++;
                                break;
                            case 1:
                                if (tb == 0x79) found = true;
                                else tstate = 0;
                                break;
                        }
                    }
                    // als niet gevonden.. ?
                    if (!found)
                    {
                        break;
                    }

                }
                //lees 4 bytes address
                /*
                for (int fa = 0; fa < 4; fa++)
                {

                }*/

            }
            //fs2.Flush();
            fs2.Close();
            fs2.Dispose();
            /*using (StreamWriter sw = new StreamWriter("lookupdump.txt", false))
            {
                foreach (AddressLookupHelper ah in m_addresslookup)
                {
                    sw.WriteLine("Helper: " + ah.Sram_adddress.ToString("X4") + " " + ah.Flash_address.ToString("X8"));
                }
            }*/

        }

        private void ParseFile(frmProgress progress, string filename, SymbolCollection curSymbolCollection, AddressLookupCollection curAddressLookupCollection)
        {
            // lezen tot END$ (einde symbol table)
            //toolStripProgressBar1.Visible = true;
            int m_symboltablestartaddress = 0;
            //curSymbolCollection = new SymbolCollection();
            //curAddressLookupCollection = new AddressLookupCollection();
            int state = 0;
            int charcount = 0;
            string dbgstring = string.Empty;
            string asciistring = string.Empty;


            //listBox1.Items.Clear();
            try
            {
                FileStream fs = new FileStream(filename, FileMode.Open);

                using (BinaryReader br = new BinaryReader(fs))
                {
                    for (int t = 0; t < fs.Length; t++)
                    {

                        byte b = br.ReadByte();
                        switch (state)
                        {
                            case 0:
                                if (b == 0x0d)
                                {
                                    //                                    if (br.PeekChar() == 0x0a)
                                    //                                    {
                                    state++;
                                    //                                    }
                                }
                                break;
                            case 1:
                                if (b == 0x0a)
                                {
                                    state++;
                                    charcount = 0;
                                }
                                else
                                {
                                    state = 0;
                                }
                                break;
                            case 2:
                                if (charcount < 32)
                                {
                                    if (b == 0x0d && br.PeekChar() == 0x0a) // start of next symbol
                                    {
                                        state = 1;
                                        int address = t - charcount;
                                        //AddLogItem(address.ToString("X6") + ": " + dbgstring + " - " + asciistring);
                                        TryToAddSymbolToCollection(dbgstring, progress, curSymbolCollection);

                                        if (m_symboltablestartaddress == 0 && t > 0xA000) m_symboltablestartaddress = address;
                                        dbgstring = string.Empty;
                                        asciistring = string.Empty;
                                    }
                                    else
                                    {
                                        charcount++;
                                        dbgstring += b.ToString("X2") + " ";
                                        if (b >= 0x20 && b < 0x80)
                                        {
                                            asciistring += Convert.ToChar(b);
                                        }
                                        else
                                        {
                                            asciistring += ".";
                                        }
                                    }
                                }
                                else
                                {
                                    int address = t - charcount;
                                    // AddLogItem(address.ToString("X6") + ": " + dbgstring + " - " + asciistring);
                                    TryToAddSymbolToCollection(dbgstring, progress, curSymbolCollection);

                                    if (m_symboltablestartaddress == 0 && t > 0xA000) m_symboltablestartaddress = address;
                                    //TryToAddSymbolToCollection(dbgstring);
                                    if (asciistring.StartsWith("END$"))
                                    {
                                        br.Close();
                                        fs.Close();
                                        //button1.Enabled = true;
                                        AddLogItem("Found end of symbol table, quit");
                                        return;
                                    }
                                    else
                                    {
                                        dbgstring = string.Empty;
                                        asciistring = string.Empty;
                                        state = 0;
                                    }
                                }
                                break;
                        }
                    }
                    br.Close();
                }
                fs.Flush();
                fs.Close();
                fs.Dispose();

                // now sort the symbols...
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            finally
            {
                //button1.Enabled = true;
                try
                {
                    progress.SetProgress("Loading lookup table");
                    ReadAddressLookupTableFromFile(m_symboltablestartaddress, curSymbolCollection.Count, progress, curAddressLookupCollection, filename);
                    foreach (SymbolHelper sh in curSymbolCollection)
                    {
                        foreach (AddressLookupHelper alh in curAddressLookupCollection)
                        {
                            if (sh.Start_address == alh.Sram_adddress)
                            {
                                progress.SetProgress(sh.Varname + " = " + alh.Flash_address.ToString("X6"));
                                sh.Flash_start_address = alh.Flash_address;
                                break;
                            }
                        }
                    }
                }
                catch (Exception finE)
                {
                    Console.WriteLine(finE.Message);
                }
            }

        }
        private void SetStatusText(string text)
        {
            barStaticItem2.Caption = text;
            System.Windows.Forms.Application.DoEvents();
        }

        private bool GetMapUpsideDown(string symbolname)
        {
            bool returnvalue = true;
            /*if (symbolname.StartsWith("Ign_map_0!")) returnvalue = false;
            else if (symbolname.StartsWith("Ign_map_4!")) returnvalue = false;
            else if (symbolname.StartsWith("Insp_mat!")) returnvalue = false;
            else if (symbolname.StartsWith("Del_mat!")) returnvalue = false;
            else if (symbolname.StartsWith("Tryck_mat_a!")) returnvalue = true;
            else if (symbolname.StartsWith("Tryck_mat!")) returnvalue = true;*/
            return returnvalue;
        }

        private double GetMapCorrectionOffset(string symbolname)
        {
            double returnvalue = 0;
            if (symbolname.StartsWith("Ign_map_0!")) returnvalue = 0;
            else if (symbolname.StartsWith("Ign_map_4!")) returnvalue = 0;
            else if (symbolname.StartsWith("Insp_mat!")) returnvalue = 0;
            else if (symbolname.StartsWith("Del_mat!")) returnvalue = 0;
            else if (symbolname.StartsWith("Tryck_mat_a!")) returnvalue = -1;
            else if (symbolname.StartsWith("Tryck_mat!")) returnvalue = -1;
            else if (symbolname.StartsWith("Tryck_vakt_tab!")) returnvalue = -1;
            else if (symbolname.StartsWith("Regl_tryck")) returnvalue = -1;
            else if (symbolname.StartsWith("Pressure map scaled for 3 bar mapsensor")) returnvalue = -1;
            else if (symbolname.StartsWith("Pressure map (AUT) scaled for 3 bar mapsensor")) returnvalue = -1;
            return returnvalue;

        }

        private double GetMapCorrectionFactor(string symbolname)
        {
            double returnvalue = 1;
            if (symbolname.StartsWith("Ign_map_0!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_1!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_2!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_3!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_4!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_5!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_6!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_7!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Ign_map_8!")) returnvalue = 0.1;
            else if (symbolname.StartsWith("Insp_mat!")) returnvalue = 1;
            else if (symbolname.StartsWith("Del_mat!")) returnvalue = 1;
            else if (symbolname.StartsWith("Tryck_mat_a!")) returnvalue = 0.01;
            else if (symbolname.StartsWith("Tryck_mat!")) returnvalue = 0.01;
            else if (symbolname.StartsWith("Tryck_vakt_tab!")) returnvalue = 0.01;
            else if (symbolname.StartsWith("Regl_tryck")) returnvalue = 0.01;
            else if (symbolname.StartsWith("Pressure map scaled for 3 bar mapsensor")) returnvalue = 0.012;
            else if (symbolname.StartsWith("Pressure map (AUT) scaled for 3 bar mapsensor")) returnvalue = 0.012;
            else if (symbolname.StartsWith("Rpm_max!")) returnvalue = 10;
            return returnvalue;
        }



        private string TranslateSymbolName(string symbolname)
        {
            string returnvalue = string.Empty;
            if (symbolname.StartsWith("Tryck_vakt_tab")) returnvalue = "Boost limit map";
            else if (symbolname.StartsWith("Data_namn")) returnvalue = "Software version";
            else if (symbolname.StartsWith("Ad_0")) returnvalue = "Analogue to digital channel 0";
            else if (symbolname.StartsWith("Ad_1")) returnvalue = "Analogue to digital channel 1";
            else if (symbolname.StartsWith("Ad_2")) returnvalue = "Analogue to digital channel 2";
            else if (symbolname.StartsWith("Ad_3")) returnvalue = "Analogue to digital channel 3";
            else if (symbolname.StartsWith("Ad_4")) returnvalue = "Analogue to digital channel 4";
            else if (symbolname.StartsWith("Ad_5")) returnvalue = "Analogue to digital channel 5";
            else if (symbolname.StartsWith("Ad_6")) returnvalue = "Analogue to digital channel 6";
            else if (symbolname.StartsWith("Ad_7")) returnvalue = "Analogue to digital channel 7";
            else if (symbolname.StartsWith("Da_0")) returnvalue = "Digital to analogue channel 0";
            else if (symbolname.StartsWith("Da_1")) returnvalue = "Digital to analogue channel 1";
            else if (symbolname.StartsWith("Da_2")) returnvalue = "Digital to analogue channel 2";
            else if (symbolname.StartsWith("Da_3")) returnvalue = "Digital to analogue channel 3";
            else if (symbolname.StartsWith("Da_4")) returnvalue = "Digital to analogue channel 4";
            else if (symbolname.StartsWith("Da_5")) returnvalue = "Digital to analogue channel 5";
            else if (symbolname.StartsWith("Da_6")) returnvalue = "Digital to analogue channel 6";
            else if (symbolname.StartsWith("Da_7")) returnvalue = "Digital to analogue channel 7";
            else if (symbolname.StartsWith("Max_tryck")) returnvalue = "Maximum boost pressure";
            else if (symbolname.StartsWith("Rpm_max")) returnvalue = "Maximum Revolutions Per Minute";
            else if (symbolname.StartsWith("Ign_map_0!")) returnvalue = "Ignition map 0";
            else if (symbolname.StartsWith("Ign_map_1!")) returnvalue = "Ignition for knocking";
            else if (symbolname.StartsWith("Ign_map_2!")) returnvalue = "Ignition correction table ??";
            else if (symbolname.StartsWith("Ign_map_3!")) returnvalue = "Ignition map 3";
            else if (symbolname.StartsWith("Ign_map_4!")) returnvalue = "Ignition map 4";
            else if (symbolname.StartsWith("Ign_map_5!")) returnvalue = "Ignition map 5";
            else if (symbolname.StartsWith("Ign_map_6!")) returnvalue = "Ignition map 6";
            else if (symbolname.StartsWith("Ign_map_7!")) returnvalue = "Ignition map 7";
            else if (symbolname.StartsWith("Ign_map_0_x_size")) returnvalue = "Ignition map 0 x-axis size";
            else if (symbolname.StartsWith("Ign_map_1_x_size")) returnvalue = "Ignition map 1 x-axis size";
            else if (symbolname.StartsWith("Ign_map_2_x_size")) returnvalue = "Ignition map 2 x-axis size";
            else if (symbolname.StartsWith("Ign_map_3_x_size")) returnvalue = "Ignition map 3 x-axis size";
            else if (symbolname.StartsWith("Ign_map_4_x_size")) returnvalue = "Ignition map 4 x-axis size";
            else if (symbolname.StartsWith("Ign_map_5_x_size")) returnvalue = "Ignition map 5 x-axis size";
            else if (symbolname.StartsWith("Ign_map_6_x_size")) returnvalue = "Ignition map 6 x-axis size";
            else if (symbolname.StartsWith("Ign_map_7_x_size")) returnvalue = "Ignition map 7 x-axis size";
            else if (symbolname.StartsWith("Ign_map_0_y_size")) returnvalue = "Ignition map 0 y-axis size";
            else if (symbolname.StartsWith("Ign_map_1_y_size")) returnvalue = "Ignition map 1 y-axis size";
            else if (symbolname.StartsWith("Ign_map_2_y_size")) returnvalue = "Ignition map 2 y-axis size";
            else if (symbolname.StartsWith("Ign_map_3_y_size")) returnvalue = "Ignition map 3 y-axis size";
            else if (symbolname.StartsWith("Ign_map_4_y_size")) returnvalue = "Ignition map 4 y-axis size";
            else if (symbolname.StartsWith("Ign_map_5_y_size")) returnvalue = "Ignition map 5 y-axis size";
            else if (symbolname.StartsWith("Ign_map_6_y_size")) returnvalue = "Ignition map 6 y-axis size";
            else if (symbolname.StartsWith("Ign_map_7_y_size")) returnvalue = "Ignition map 7 y-axis size";
            else if (symbolname.StartsWith("Ign_map_0_x_axis")) returnvalue = "Ignition map 0 x-axis";
            else if (symbolname.StartsWith("Ign_map_1_x_axis")) returnvalue = "Ignition map 1 x-axis";
            else if (symbolname.StartsWith("Ign_map_2_x_axis")) returnvalue = "Ignition map 2 x-axis";
            else if (symbolname.StartsWith("Ign_map_3_x_axis")) returnvalue = "Ignition map 3 x-axis";
            else if (symbolname.StartsWith("Ign_map_4_x_axis")) returnvalue = "Ignition map 4 x-axis";
            else if (symbolname.StartsWith("Ign_map_5_x_axis")) returnvalue = "Ignition map 5 x-axis";
            else if (symbolname.StartsWith("Ign_map_6_x_axis")) returnvalue = "Ignition map 6 x-axis";
            else if (symbolname.StartsWith("Ign_map_7_x_axis")) returnvalue = "Ignition map 7 x-axis";
            else if (symbolname.StartsWith("Ign_map_0_y_axis")) returnvalue = "Ignition map 0 y-axis";
            else if (symbolname.StartsWith("Ign_map_1_y_axis")) returnvalue = "Ignition map 1 y-axis";
            else if (symbolname.StartsWith("Ign_map_2_y_axis")) returnvalue = "Ignition map 2 y-axis";
            else if (symbolname.StartsWith("Ign_map_3_y_axis")) returnvalue = "Ignition map 3 y-axis";
            else if (symbolname.StartsWith("Ign_map_4_y_axis")) returnvalue = "Ignition map 4 y-axis";
            else if (symbolname.StartsWith("Ign_map_5_y_axis")) returnvalue = "Ignition map 5 y-axis";
            else if (symbolname.StartsWith("Ign_map_6_y_axis")) returnvalue = "Ignition map 6 y-axis";
            else if (symbolname.StartsWith("Ign_map_7_y_axis")) returnvalue = "Ignition map 7 y-axis";
            else if (symbolname.StartsWith("Knock_count_cyl1")) returnvalue = "Number of knocks detected in cylinder 1";
            else if (symbolname.StartsWith("Knock_count_cyl2")) returnvalue = "Number of knocks detected in cylinder 2";
            else if (symbolname.StartsWith("Knock_count_cyl3")) returnvalue = "Number of knocks detected in cylinder 3";
            else if (symbolname.StartsWith("Knock_count_cyl4")) returnvalue = "Number of knocks detected in cylinder 4";
            else if (symbolname.StartsWith("Insp_mat!")) returnvalue = "Injection matrix (16 x 16)";
            else if (symbolname.StartsWith("Del_mat!")) returnvalue = "???? matrix (16 x 16)";
            else if (symbolname.StartsWith("Tryck_mat_a!")) returnvalue = "Boost table for automatic transmission (8x)";
            else if (symbolname.StartsWith("Tryck_mat!")) returnvalue = "Boost table for manual transmission (8x)";
            else if (symbolname.StartsWith("Pressure map scaled for 3 bar mapsensor")) returnvalue = "Boost table (3 bar) for manual transmission (8x)";
            else if (symbolname.StartsWith("Pressure map (AUT) scaled for 3 bar mapsensor")) returnvalue = "Boost table (3 bar) for automatic transmission (8x)";
            else if (symbolname.StartsWith("Lret_konst!")) returnvalue = "Deceleration delta matrix (8x)";
            else if (symbolname.StartsWith("Lacc_konst!")) returnvalue = "Acceleration delta matrix (8x)";
            else if (symbolname.StartsWith("Dash_tab!")) returnvalue = "???? matrix (8x)";
            else if (symbolname.StartsWith("Accel_konst!")) returnvalue = "(Acceleration) ???? matrix (8x)";
            else if (symbolname.StartsWith("Retard_konst!")) returnvalue = "(Decceleration) ???? matrix (8x)";
            else if (symbolname.StartsWith("Pwm_ind_trot!")) returnvalue = "???? matrix (8x)";
            else if (symbolname.StartsWith("Fuel_knock_mat!")) returnvalue = "Fuel enrichment table when knocking occurs (12x)";
            else if (symbolname.StartsWith("Iv_min_tab_ac!")) returnvalue = "???? matrix (2x)";
            else if (symbolname.StartsWith("Iv_min_tab!")) returnvalue = "???? matrix (6x)";
            else if (symbolname.StartsWith("Lambdamatris_diag!")) returnvalue = "Lambda sonde diagnostic matrix (6x)";
            else if (symbolname.StartsWith("Lambdamatris!")) returnvalue = "Lambda sonde matrix (3x)";
            else if (symbolname.StartsWith("Idle_fuel_korr!")) returnvalue = "Idle fuel correction matrix (12x)";
            else if (symbolname.StartsWith("Open_loop_adapt!")) returnvalue = "Open loop adaption";
            else if (symbolname.StartsWith("Open_loop!")) returnvalue = "Open loop";
            else if (symbolname.StartsWith("Open_loop_knock!")) returnvalue = "Open loop knock";
            else if (symbolname.StartsWith("P_fors!")) returnvalue = "P of PID table";
            else if (symbolname.StartsWith("I_fors!")) returnvalue = "I of PID table";
            else if (symbolname.StartsWith("D_fors!")) returnvalue = "D of PID table";
            else if (symbolname.StartsWith("P_fors_a!")) returnvalue = "P of PID table (automatic)";
            else if (symbolname.StartsWith("I_fors_a!")) returnvalue = "I of PID table (automatic)";
            else if (symbolname.StartsWith("D_fors_a!")) returnvalue = "D of PID table (automatic)";
            else if (symbolname.StartsWith("Regl_tryck_fgm!")) returnvalue = "Maximum boost in first gear (limiter)";
            else if (symbolname.StartsWith("Regl_tryck_sgm!")) returnvalue = "Maximum boost in second gear (limiter)";
            else if (symbolname.StartsWith("Regl_tryck_fgaut!")) returnvalue = "Maximum boost in first gear (automatic)";
            else if (symbolname.StartsWith("Temp_reduce_mat!")) returnvalue = "Temperature reduction map";
            else if (symbolname.StartsWith("Temp_reduce_mat_2!")) returnvalue = "Temperature reduction 2 map";
            else if (symbolname.StartsWith("Adapt_korr!")) returnvalue = "Fuel adaption map";
            else if (symbolname.StartsWith("Idle_start_extra_sp!")) returnvalue = "Extra fuel for idle WOT?";
            else if (symbolname.StartsWith("Rxbuf")) returnvalue = "Receive buffer";
            else if (symbolname.StartsWith("Txbuf")) returnvalue = "Transmit buffer";
            else if (symbolname.StartsWith("Immotimer")) returnvalue = "Immobilizer timer";
            else if (symbolname.StartsWith("Acc_fak")) returnvalue = "Acceleration factor";
            else if (symbolname.StartsWith("Acc_temp")) returnvalue = "Acceleration temperature";
            else if (symbolname.StartsWith("Acc_mangd")) returnvalue = "Acceleration amount";
            else if (symbolname.StartsWith("Last_delta")) returnvalue = "Load change";
            else if (symbolname.StartsWith("Lacc_mangd")) returnvalue = "Lower/Load acceleration amount";
            else if (symbolname.StartsWith("Lret_mangd")) returnvalue = "Lower/Load deceleration amount";
            else if (symbolname.StartsWith("Ad_bat")) returnvalue = "Analogue/Digital value battery";
            else if (symbolname.StartsWith("Ad_knock")) returnvalue = "Analogue/Digital value knock";
            else if (symbolname.StartsWith("Ad_kylv")) returnvalue = "Analogue/Digital value coolant temperature";
            else if (symbolname.StartsWith("Ad_egr")) returnvalue = "Analogue/Digital value EGR";
            else if (symbolname.StartsWith("Ad_sond")) returnvalue = "Analogue/Digital value lambda probe";
            else if (symbolname.StartsWith("P_manifold")) returnvalue = "Manifold pressure";
            else if (symbolname.StartsWith("Ad_lufttemp")) returnvalue = "Analogue/Digital value intake temperature";
            else if (symbolname.StartsWith("Ad_trot")) returnvalue = "Analogue/Digital value throttle position sensor";
            else if (symbolname.StartsWith("Ad_cat")) returnvalue = "Analogue/Digital value catalyst";
            else if (symbolname.StartsWith("Antal_steg")) returnvalue = "Number of steps";
            else if (symbolname.StartsWith("Cyl_nr")) returnvalue = "Cylinder number";
            else if (symbolname.StartsWith("Start_tid")) returnvalue = "Start time";
            if (returnvalue == string.Empty)
            {
                // try the fallback excel sheet
                if (_symbolnameHelper != null)
                {
                    foreach (System.Data.DataRow hdr in _symbolnameHelper.Rows)
                    {
                        if (hdr[0] != DBNull.Value)
                        {
                            if (hdr[0].ToString() == symbolname)
                            {
                                if (hdr[1] != DBNull.Value)
                                {
                                    returnvalue = hdr[1].ToString();
                                }
                            }
                        }
                    }
                }
            }
            return returnvalue;
        }

        private XDFCategories TranslateSymbolNameToCategory(string symbolname)
        {
            XDFCategories returnvalue = XDFCategories.None;
            if (symbolname.StartsWith("Tryck_vakt_tab")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Data_namn")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Ad_0")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_1")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_2")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_3")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_4")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_5")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_6")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Ad_7")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_0")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_1")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_2")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_3")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_4")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_5")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_6")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Da_7")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Max_tryck")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Rpm_max")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Ign_map_0!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_1!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_2!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_3!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_4!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_5!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_6!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_7!")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_0_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_1_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_2_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_3_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_4_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_5_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_6_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_7_x_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_0_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_1_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_2_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_3_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_4_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_5_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_6_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_7_y_size")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_0_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_1_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_2_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_3_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_4_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_5_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_6_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_7_x_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_0_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_1_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_2_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_3_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_4_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_5_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_6_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Ign_map_7_y_axis")) returnvalue = XDFCategories.Ignition;
            else if (symbolname.StartsWith("Knock_count_cyl1")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Knock_count_cyl2")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Knock_count_cyl3")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Knock_count_cyl4")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Insp_mat!")) returnvalue = XDFCategories.Fuel;
            else if (symbolname.StartsWith("Del_mat!")) returnvalue = XDFCategories.Fuel;
            else if (symbolname.StartsWith("Tryck_mat_a!")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Tryck_mat!")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Pressure map")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Lret_konst!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Lacc_konst!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Dash_tab!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Accel_konst!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Retard_konst!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Pwm_ind_trot!")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Fuel_knock_mat!")) returnvalue = XDFCategories.Fuel;
            else if (symbolname.StartsWith("Iv_min_tab_ac!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Iv_min_tab!")) returnvalue = XDFCategories.Misc;
            else if (symbolname.StartsWith("Lambdamatris_diag!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Lambdamatris!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Idle_fuel_korr!")) returnvalue = XDFCategories.Correction;
            else if (symbolname.StartsWith("Open_loop_adapt!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Open_loop!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Open_loop_knock!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("P_fors")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("I_fors")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("D_fors")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Regl_tryck_fgm!")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Regl_tryck_sgm!")) returnvalue = XDFCategories.Turbo;
            else if (symbolname.StartsWith("Temp_reduce_mat!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Temp_reduce_mat_2!")) returnvalue = XDFCategories.Sensor;
            else if (symbolname.StartsWith("Adapt_korr!")) returnvalue = XDFCategories.Fuel;
            return returnvalue;
        }


        private void GetAxisDescriptions(string symbolname, out string x, out string y, out string z)
        {
            x = "x-axis";
            y = "y-axis";
            z = "z-axis";
            if (symbolname.StartsWith("Ign_map_0!") || symbolname.StartsWith("Ign_map_2!") || symbolname.StartsWith("Ign_map_3!") || symbolname.StartsWith("Ign_map_4!") || symbolname.StartsWith("Ign_map_6!") || symbolname.StartsWith("Ign_map_7!"))
            {
                x = "MAP";
                y = "RPM";
                z = "Degrees";
            }
            else if (symbolname.StartsWith("Ign_map_1!"))
            {
                x = "Ign.knocking.corr";
                y = "RPM difference";
                z = "Degrees";
            }
            else if (symbolname.StartsWith("Ign_map_5!"))
            {
                y = "RPM";
                z = "Degrees";
            }
            else if (symbolname.StartsWith("Ign_map_8!"))
            {
                x = "MAP";
                z = "Degrees";
            }
            else if (symbolname.StartsWith("Iv_min_tab!"))
            {
                z = "RPM";
            }
            else if (symbolname.StartsWith("Iv_min_tab_ac!"))
            {
                z = "RPM";
            }
            else if (symbolname.StartsWith("Tryck_vakt_tab"))
            {
                x = "MAP";
                y = "RPM";
            }
            else if (symbolname.StartsWith("Tryck_mat!") || symbolname.StartsWith("Tryck_mat_a!") || symbolname.StartsWith("Pressure map"))
            {
                x = "Throttle position";
                y = "RPM";
                z = "MAP";
            }
            else if (symbolname.StartsWith("Retard_konst!"))
            {
                x = "Throttle position";
                y = "RPM";
            }
            else if (symbolname.StartsWith("Insp_mat!"))
            {
                x = "MAP";
                y = "RPM";
                z = "Injection time";
            }
            else if (symbolname.StartsWith("Kyltemp_tab!"))
            {
                y = "Temperature";
            }
            else if (symbolname.StartsWith("P_fors"))
            {
                y = "RPM";
            }
            else if (symbolname.StartsWith("I_fors"))
            {
                y = "RPM";
            }
            else if (symbolname.StartsWith("D_fors"))
            {
                y = "RPM";
            }
            else if (symbolname.StartsWith("Del_mat!"))
            {
                x = "RPM";
                y = "MAP";
            }
            else if (symbolname.StartsWith("Fuel_knock_mat!"))
            {
                x = "MAP";
                y = "RPM";
            }
            else if (symbolname.StartsWith("Temp_reduce_mat!"))
            {
                x = "Engine load";
                y = "RPM";
            }
            else if (symbolname.StartsWith("Temp_reduce_mat_2!"))
            {
                x = "Engine load";
                y = "RPM";

            }

        }

        private int GetSymbolLength(SymbolCollection curSymbolCollection, string symbolname)
        {
            foreach (SymbolHelper sh in curSymbolCollection)
            {
                if (sh.Varname.StartsWith(symbolname))
                {
                    return sh.Length;
                }
            }
            return 1;
        }

        private int GetTableMatrixWitdhByName(string symbolname, out int columns, out int rows)
        {
            columns = 0;
            rows = 0;
            if (symbolname.StartsWith("Insp_mat!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_map_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!") / 2;
                return 16;
            }
            else if (symbolname.StartsWith("Del_mat!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_map_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!") / 2;
                return 16;
            }
            else if (symbolname.StartsWith("Fuel_knock_mat!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_knock_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!") / 2;
                return 12;
            }
            else if (symbolname.StartsWith("Iv_min_tab_ac!"))
            {
                columns = 1;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 2;
            }
            else if (symbolname.StartsWith("Iv_min_tab!"))
            {
                columns = 1;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 1;
            }
            else if (symbolname.StartsWith("Lambdamatris_diag!"))
            {
                columns = 6;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 6;
            }
            else if (symbolname.StartsWith("Lambdamatris!"))
            {
                columns = 3;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 3;
            }
            else if (symbolname.StartsWith("Idle_fuel_korr!"))
            {
                columns = GetSymbolLength(m_symbols, "Idle_st_last!");
                rows = GetSymbolLength(m_symbols, "Idle_rpm_tab!");//2
                return 12;
            }
            else if (symbolname.StartsWith("Ign_map_0!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_0_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_0_y_axis!");//2
                return 0x12;
            }
            else if (symbolname.StartsWith("Ign_map_1!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_1_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_1_y_axis!");//2
                return 0x1;
            }
            else if (symbolname.StartsWith("Ign_map_2!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_2_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_2_y_axis!");//2
                return 0x08;
            }
            else if (symbolname.StartsWith("Ign_map_3!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_3_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_3_y_axis!") / 2;
                return 0x08;
            }
            else if (symbolname.StartsWith("Ign_map_4!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_0_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_0_y_axis!");//2
                return 0x12;
            }
            else if (symbolname.StartsWith("Ign_map_5!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_5_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_5_y_axis!");//2
                return 0x08;
            }
            else if (symbolname.StartsWith("Ign_map_6!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_6_x_axis!");//2
                rows = GetSymbolLength(m_symbols, "Ign_map_6_y_axis!");//2
                return 0x08;
            }
            else if (symbolname.StartsWith("Ign_map_7!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_7_x_axis!");//2
                rows = GetSymbolLength(m_symbols, "Ign_map_7_y_axis!");//2
                return 0x08;
            }
            else if (symbolname.StartsWith("Ign_map_8!"))
            {
                columns = GetSymbolLength(m_symbols, "Ign_map_8_x_axis!") / 2;
                rows = GetSymbolLength(m_symbols, "Ign_map_8_y_axis!");//2
                return 0x08;
            }
            else if (symbolname.StartsWith("Open_loop_adapt!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_map_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!") / 2;
                return 1;
            }
            else if (symbolname.StartsWith("Open_loop!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_map_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!") / 2;
                return 1;
            }
            else if (symbolname.StartsWith("Open_loop_knock!"))
            {
                columns = GetSymbolLength(m_symbols, "Fuel_map_xaxis!");
                rows = GetSymbolLength(m_symbols, "Fuel_map_yaxis!");//2
                return 1;
            }
            else if (symbolname.StartsWith("AC_Control!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Tryck_vakt_tab"))
            {
                //Fuel_map_yaxis! langs de y as
                columns = 1;// op aanvraag hessu
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x10;
            }
            else if (symbolname.StartsWith("Regl_tryck"))
            {
                columns = 1;// op aanvraag hessu
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x10;
            }
            else if (symbolname.StartsWith("Reg_kon_mat"))
            {
                columns = 1;// op aanvraag hessu
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x10;
            }

            else if (symbolname.StartsWith("Tryck_mat_a!"))
            {
                columns = GetSymbolLength(m_symbols, "Trans_x_st!");
                //rows = GetSymbolLength(m_symbols, "Trans_y_st!");//2
                rows = GetSymbolLength(m_symbols, "Pwm_ind_rpm!")/2;
                return 8;
            }
            else if (symbolname.StartsWith("Tryck_mat!") || symbolname.StartsWith("Pressure map"))
            {
                columns = GetSymbolLength(m_symbols, "Trans_x_st!");
                //rows = GetSymbolLength(m_symbols, "Trans_y_st!");
                rows = GetSymbolLength(m_symbols, "Pwm_ind_rpm!")/2;

                return 8;
            }
            /*else if (symbolname.StartsWith("Detect_map!"))
            {
                columns = GetSymbolLength(m_symbols, "Detect_map_x_axis!"); // 2;
                rows = GetSymbolLength(m_symbols, "Detect_map_y_axis!"); // 2;
                return 0x12;
            }*/
            else if (symbolname.StartsWith("Dash_tab!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Retard_konst!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Accel_konst!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Temp_reduce_mat!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Temp_reduce_mat_2!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Lacc_konst!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Lret_konst!"))
            {
                columns = 8;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x08;
            }
            else if (symbolname.StartsWith("Adapt_korr!"))
            {
                columns = 0x10;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x10;
            }
            else if (symbolname.StartsWith("Purge_tab!"))
            {
                columns = 0x10;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x10;
            }
            else if (symbolname.StartsWith("Knock_ref_matrix!"))
            {
                columns = 0x12;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x12;
            }
            else if (symbolname.StartsWith("Detect_map!"))
            {
                columns = 0x12;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x12;
            }
            else if (symbolname.StartsWith("Mis200_map!"))
            {
                columns = 0x12;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x12;
            }
            else if (symbolname.StartsWith("Mis1000_map!"))
            {
                columns = 0x12;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x12;
            }
            else if (symbolname.StartsWith("P_fors!") || symbolname.StartsWith("I_fors!") || symbolname.StartsWith("D_fors!"))
            {
                columns = 0x4;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x4;
            }
            else if (symbolname.StartsWith("P_fors_a!") || symbolname.StartsWith("I_fors_a!") || symbolname.StartsWith("D_fors_a!"))
            {
                columns = 0x4;
                rows = GetSymbolLength(m_symbols, symbolname) / columns;
                return 0x4;
            }

            columns = 1;
            rows = GetSymbolLength(m_symbols, symbolname) / columns;
            return 1;
        }

        private void ExtractSymbolTable()
        {
            if (m_currentfile != string.Empty)
            {
                frmProgress progress = new frmProgress();
                progress.Show();
                progress.SetProgress("Initializing");

                //listView1.Items.Clear();
                SetStatusText("Start symbol parsing");
                barButtonItem14.Enabled = false;
                m_symbols = new SymbolCollection();
                m_addresslookup = new AddressLookupCollection();
                ParseFile(progress, m_currentfile, m_symbols, m_addresslookup);
                // AddLogItem("Start symbol export...");
                m_symbols.SortColumn = "Start_address";
                m_symbols.SortingOrder = GenericComparer.SortOrder.Ascending;
                m_symbols.Sort();
                progress.SetProgress("Filling list");
                //listView1.SuspendLayout();
                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("SYMBOLNAME");
                dt.Columns.Add("SRAMADDRESS", Type.GetType("System.Int32"));
                dt.Columns.Add("FLASHADDRESS", Type.GetType("System.Int32"));
                dt.Columns.Add("LENGTHBYTES", Type.GetType("System.Int32"));
                dt.Columns.Add("LENGTHVALUES", Type.GetType("System.Int32"));
                dt.Columns.Add("DESCRIPTION");
                dt.Columns.Add("ISCHANGED", Type.GetType("System.Boolean"));
                dt.Columns.Add("CATEGORY", Type.GetType("System.Int32"));
                foreach (SymbolHelper sh in m_symbols)
                {
                    //AddLogItem("Symbol found: " + sh.Varname + " at " + sh.Start_address.ToString("X4") + " len: " + sh.Length.ToString("X4"));
                    /*ListViewItem lvi = new ListViewItem("");
                    lvi.Text = sh.Start_address.ToString("X4");
                    lvi.SubItems.Add(sh.Flash_start_address.ToString("X8"));
                    lvi.SubItems.Add(sh.Length.ToString("X4"));
                    lvi.SubItems.Add(sh.Varname);
                    string tabletranslation = TranslateSymbolName(sh.Varname);
                    lvi.SubItems.Add(tabletranslation);
                    listView1.Items.Add(lvi);*/

                    dt.Rows.Add(sh.Varname, sh.Start_address, sh.Flash_start_address, sh.Length, sh.Length, TranslateSymbolName(sh.Varname), false, (int)TranslateSymbolNameToCategory(sh.Varname));
                }
                gridSymbols.DataSource = dt;

                repositoryItemLookUpEdit1.DataSource = dt;
                repositoryItemLookUpEdit1.DisplayMember = "SYMBOLNAME";

                // always?
                gridViewSymbols.BestFitColumns();
                //listView1.ResumeLayout();
                SetVSSStatus();
                SetStatusText("Idle.");
                barButtonItem14.Enabled = true;
                progress.Close();
                // create repository item
                CreateRepositoryItem();
            }
            else
            {
                MessageBox.Show("No file selected, please select one first");
            }

        }
        private bool VerifyFile()
        {
            bool retval = true;
            if (m_currentfile == string.Empty)
            {
                MessageBox.Show("No file selected, please select one first");
                retval = false;
            }
            else if (!File.Exists(m_currentfile))
            {
                MessageBox.Show("Selected file does not exist!");
                retval = false;
            }
            else
            {
                FileInfo fi = new FileInfo(m_currentfile);
                if (fi.Length != 0x00040000)
                {
                    MessageBox.Show("Selected file has incorrect length");
                    retval = false;
                }
            }
            if (retval)
            {
                if (verifychecksum()) barButtonItem20.ImageIndex = 3;
                else barButtonItem20.ImageIndex = 2;
                System.Windows.Forms.Application.DoEvents();
            }
            return retval;
        }

        private string readchecksum()
        {
            string retval = string.Empty;
            byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };
            //uint checksum = 0;
            byte[] filebytes = File.ReadAllBytes(m_currentfile);
            // nu nog de eindmarkering vinden!
            // 4EFAFBCC = eindmarkering
            // 13FC00FF = eindmarkering data
            int indexoffirstmarking = ReadEndMarker(0xFE) - 3;//IndexOf(filebytes, firstpattern);
            //int indexofsecondmarking = IndexOf(filebytes, secondpattern);
            if (indexoffirstmarking > 0)
            {
                FileStream fsi1 = File.OpenRead(m_currentfile);
                BinaryReader br1 = new BinaryReader(fsi1);
                /*                for (int tel = 0; tel < indexoffirstmarking + 4; tel++)
                                {
                                    Byte ib1 = br1.ReadByte();
                                    checksum += ib1;
                                }*/
                fsi1.Position = 0x0003FFFC;
                uint readchecksum = (uint)br1.ReadByte() * 0x01000000;
                readchecksum += (uint)br1.ReadByte() * 0x00010000;
                readchecksum += (uint)br1.ReadByte() * 0x00000100;
                readchecksum += (uint)br1.ReadByte();
                //MessageBox.Show("File checksum is : "+ readchecksum.ToString("X8"));
                retval = readchecksum.ToString("X8");
                fsi1.Flush();
                br1.Close();
                fsi1.Close();
                fsi1.Dispose();
            }
            return retval;
        }

        private int ReadEndMarker(int value)
        {
            int retval = 0;
            if (m_currentfile != string.Empty)
            {
                if (File.Exists(m_currentfile))
                {
                    // read the file footer
                    //3ff00 - 0x3ffff
                    FileStream fs = new FileStream(m_currentfile, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);

                    fs.Seek(0x3FF00, SeekOrigin.Begin);
                    byte[] inb = br.ReadBytes(0xFF);
                    int offset = 0;
                    for (int t = 0; t < 0xFF; t++)
                    {
                        if ((byte)inb.GetValue(t) == (byte)value)
                        {
                            // marker gevonden
                            // lees 6 terug
                            offset = t;
                            break;
                        }
                    }
                    string hexstr = string.Empty;
                    if (offset > 6)
                    {
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 1));
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 2));
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 3));
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 4));
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 5));
                        hexstr += Convert.ToChar((byte)inb.GetValue(offset - 6));
                    }
                    try
                    {
                        retval = Convert.ToInt32(hexstr, 16);
                        retval -= 0x40000;
                    }
                    catch (Exception E)
                    {
                        Console.WriteLine(E.Message);
                    }
                    fs.Flush();
                    br.Close();
                    fs.Close();
                    fs.Dispose();
                }
            }
            return retval;
        }

        private int ReadMarkerAddress(int value, out int length, out string val)
        {
            int retval = 0;
            length = 0;
            val = string.Empty;
            if (m_currentfile != string.Empty)
            {
                if (File.Exists(m_currentfile))
                {
                    // read the file footer
                    //3ff00 - 0x3ffff
                    FileStream fs = new FileStream(m_currentfile, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);

                    fs.Seek(0x3FF00, SeekOrigin.Begin);
                    byte[] inb = br.ReadBytes(0xFF);
                    //int offset = 0;
                    for (int t = 0; t < 0xFF; t++)
                    {
                        if (((byte)inb.GetValue(t) == (byte)value) && ((byte)inb.GetValue(t+1)<0x30))
                        {
                            // marker gevonden
                            // lees 6 terug
                            retval = 0x3FF00 + t;
                            length = (byte)inb.GetValue(t + 1);
                            break;
                        }
                    }
                    fs.Seek((retval - length) , SeekOrigin.Begin);
                    byte[] info = br.ReadBytes(length);
                    for(int bc = info.Length - 1; bc >=0 ; bc --)
                    {
                        val += Convert.ToChar(info.GetValue(bc));
                    }
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();

                }
            }
            
            return retval;
        }



        /// <summary>
        /// New version, adjusted to new information about the end of data marker
        /// </summary>
        /// <returns></returns>
        private int getendofdataindexEx()
        {
            //0xFE - Calc CRC END offset
            int retval = 0;
            retval = ReadEndMarker(0xFE);
            return retval;
        }

        private int getendofdataindex()
        {
            int retval = 0;
            byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };
            byte[] filebytes = File.ReadAllBytes(m_currentfile);
            // nu nog de eindmarkering vinden!
            // 4EFAFBCC = eindmarkering
            // 13FC00FF = eindmarkering data
            int indexoffirstmarking = IndexOf(filebytes, firstpattern);
            //int indexofsecondmarking = IndexOf(filebytes, secondpattern);
            if (indexoffirstmarking > 0)
            {
                retval = indexoffirstmarking + 4;
            }
            return retval;
        }

        private string calculatechecksum()
        {
            string retval = string.Empty;
            byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };
            uint checksum = 0;
            byte[] filebytes = File.ReadAllBytes(m_currentfile);
            // nu nog de eindmarkering vinden!
            // 4EFAFBCC = eindmarkering
            // 13FC00FF = eindmarkering data
            int indexoffirstmarking = ReadEndMarker(0xFE) - 3;//IndexOf(filebytes, firstpattern);
            //int indexofsecondmarking = IndexOf(filebytes, secondpattern);
            if (indexoffirstmarking > 0)
            {
                //MessageBox.Show(ReadEndMarker(0xFE).ToString() + " vs " + indexoffirstmarking.ToString());
                FileStream fsi1 = File.OpenRead(m_currentfile);
                BinaryReader br1 = new BinaryReader(fsi1);
                for (int tel = 0; tel < indexoffirstmarking + 4; tel++)
                {
                    Byte ib1 = br1.ReadByte();
                    checksum += ib1;
                }
                fsi1.Position = 0x0003FFFC;
                uint readchecksum = (uint)br1.ReadByte() * 0x01000000;
                readchecksum += (uint)br1.ReadByte() * 0x00010000;
                readchecksum += (uint)br1.ReadByte() * 0x00000100;
                readchecksum += (uint)br1.ReadByte();
                //MessageBox.Show("File checksum is : "+ readchecksum.ToString("X8"));
                retval = checksum.ToString("X8");
                fsi1.Flush();
                br1.Close();
                fsi1.Close();
                fsi1.Dispose();

            }
            return retval;
        }

        private bool verifychecksum()
        {
            bool retval = false;
            barButtonItem20.ImageIndex = 0;
            System.Windows.Forms.Application.DoEvents();
            byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };
            uint checksum = 0;
            byte[] filebytes = File.ReadAllBytes(m_currentfile);
            // nu nog de eindmarkering vinden!
            // 4EFAFBCC = eindmarkering
            // 13FC00FF = eindmarkering data
            int indexoffirstmarking = ReadEndMarker(0xFE) - 3;// IndexOf(filebytes, firstpattern);
            //int indexofsecondmarking = IndexOf(filebytes, secondpattern);
            if (indexoffirstmarking > 0)
            {
                FileStream fsi1 = File.OpenRead(m_currentfile);
                BinaryReader br1 = new BinaryReader(fsi1);
                for (int tel = 0; tel < indexoffirstmarking + 4; tel++)
                {
                    Byte ib1 = br1.ReadByte();
                    checksum += ib1;
                }
                fsi1.Position = 0x0003FFFC;
                uint readchecksum = (uint)br1.ReadByte() * 0x01000000;
                readchecksum += (uint)br1.ReadByte() * 0x00010000;
                readchecksum += (uint)br1.ReadByte() * 0x00000100;
                readchecksum += (uint)br1.ReadByte();
                //MessageBox.Show("File checksum is : "+ readchecksum.ToString("X8"));
                if (checksum == readchecksum) retval = true;
                fsi1.Flush();
                br1.Close();
                fsi1.Close();
                fsi1.Dispose();

            }
            if (retval)
            {
                barButtonItem20.ImageIndex = 3;
            }
            else
            {
                barButtonItem20.ImageIndex = 2;
            }
            return retval;
        }

        private bool updatechecksum()
        {
            bool retval = false;
            byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };
            uint checksum = 0;
            byte[] filebytes = File.ReadAllBytes(m_currentfile);
            // nu nog de eindmarkering vinden!
            // 4EFAFBCC = eindmarkering
            // 13FC00FF = eindmarkering data
            int indexoffirstmarking = ReadEndMarker(0xFE) - 3;//IndexOf(filebytes, firstpattern);
            //int indexofsecondmarking = IndexOf(filebytes, secondpattern);
            if (indexoffirstmarking > 0)
            {
                FileStream fsi1 = File.OpenRead(m_currentfile);
                BinaryReader br1 = new BinaryReader(fsi1);
                for (int tel = 0; tel < indexoffirstmarking + 4; tel++)
                {
                    Byte ib1 = br1.ReadByte();
                    checksum += ib1;
                }
                fsi1.Position = 0x0003FFFC;
                uint readchecksum = (uint)br1.ReadByte() * 0x01000000;
                readchecksum += (uint)br1.ReadByte() * 0x00010000;
                readchecksum += (uint)br1.ReadByte() * 0x00000100;
                readchecksum += (uint)br1.ReadByte();
                //MessageBox.Show("File checksum is : "+ readchecksum.ToString("X8"));
                fsi1.Flush();
                br1.Close();
                fsi1.Close();
                fsi1.Dispose();

                if (checksum != readchecksum)
                {
                    retval = true;
                    FileStream fsi2 = File.OpenWrite(m_currentfile);
                    //BinaryReader bw1 = new BinaryReader(fsi2);
                    AddLogItem("Writing file " + m_currentfile + "-modified.bin with modified checksum/parameters");
                    fsi2.Position = 0x0003FFFC;
                    //FileStream fs2 = new FileStream(m_currentfile + "-modified.bin", FileMode.Create);
                    BinaryWriter bw1 = new BinaryWriter(fsi2);
                    /*for (int t = 0; t < 0x0003FFFC; t++)
                    {
                        bw1.Write(br1.ReadByte());
                    }*/
                    bw1.Write((byte)((checksum & 0xFF000000) >> 24));
                    bw1.Write((byte)((checksum & 0x00FF0000) >> 16));
                    bw1.Write((byte)((checksum & 0x0000FF00) >> 8));
                    bw1.Write((byte)((checksum & 0x000000FF)));
                    fsi2.Flush();
                    bw1.Close();
                    fsi2.Close();
                    fsi2.Dispose();

                }
            }
            if (verifychecksum()) barButtonItem20.ImageIndex = 3;
            else barButtonItem20.ImageIndex = 2;
            System.Windows.Forms.Application.DoEvents();
            return retval;
        }


        private void DoChecksum()
        {

            /*byte[] firstpattern = new byte[4] { 0x4E, 0xFA, 0xFB, 0xCC };
            byte[] secondpattern = new byte[4] { 0x13, 0xFC, 0x00, 0xFF };

            uint checksum = 0;
            AddLogItem("Checking file for validity: " + m_currentfile);
            if (File.Exists(m_currentfile))
            {
                AddLogItem("File exists, checking length");
                FileInfo fi = new FileInfo(m_currentfile);
                if (fi.Length == 0x00040000)
                {
                    AddLogItem("File has correct length: 0x00040000 bytes, start parsing");
                    // lees eerst de gehele file in
                    byte[] filebytes = File.ReadAllBytes(m_currentfile);
                    // nu nog de eindmarkering vinden!
                    // 4EFAFBCC = eindmarkering
                    // 13FC00FF = eindmarkering data
                    int indexoffirstmarking = IndexOf(filebytes, firstpattern);
                    int indexofsecondmarking = IndexOf(filebytes, secondpattern);
                    if (indexoffirstmarking > 0)
                    {
                        AddLogItem("Marker (4EFAFBCC) found on: " + indexoffirstmarking.ToString("X08"));
                        FileStream fsi1 = File.OpenRead(m_currentfile);
                        BinaryReader br1 = new BinaryReader(fsi1);
                        AddLogItem("Start checksum (32 bit) calculation");
                        for (int tel = 0; tel < indexoffirstmarking + 4; tel++)
                        {
                            Byte ib1 = br1.ReadByte();
                            checksum += ib1;
                        }
                        // checksum is now complete
                        // verify against value in file
                        AddLogItem("Reading current file checksum");
                        fsi1.Position = 0x0003FFFC;
                        uint readchecksum = (uint)br1.ReadByte() * 0x01000000;
                        readchecksum += (uint)br1.ReadByte() * 0x00010000;
                        readchecksum += (uint)br1.ReadByte() * 0x00000100;
                        readchecksum += (uint)br1.ReadByte();
                        if (readchecksum == checksum)
                        {
                            AddLogItem("Checksum matches! checksum = " + readchecksum.ToString("X08"));
                            if (checkBox2.Checked || checkBox3.Checked || checkBox4.Checked)
                            {
                                AddLogItem("Writing file " + m_currentfile+ "-modified.bin with modified parameters");
                                fsi1.Position = 0;
                                FileStream fs2 = new FileStream(m_currentfile + "-modified.bin", FileMode.Create);
                                BinaryWriter bw1 = new BinaryWriter(fs2);
                                for (int t = 0; t <= 0x0003FFFF; t++)
                                {
                                    bw1.Write(br1.ReadByte());
                                }
                                if (checkBox2.Checked && textBox2.Text.Length == 6)
                                {
                                    fs2.Position = 0x3FFB4; // IMMO ID, backwards
                                    for (int i = 0; i < textBox2.Text.Length; i++)
                                    {
                                        // backwards!!!
                                        bw1.Write((byte)textBox2.Text[textBox2.Text.Length - (i + 1)]);
                                    }
                                }

                                if (checkBox3.Checked && textBox3.Text.Length == 12)
                                {
                                    fs2.Position = 0x3FFDC; // software ID
                                    for (int i = 0; i < textBox3.Text.Length; i++)
                                    {
                                        // backwards!!!
                                        bw1.Write((byte)textBox3.Text[textBox3.Text.Length - (i + 1)]);
                                    }
                                }
                                if (checkBox4.Checked && textBox4.Text.Length == 7)
                                {
                                    fs2.Position = 0x3FFF3; // Boxnumber
                                    for (int i = 0; i < textBox4.Text.Length; i++)
                                    {
                                        // backwards!!!
                                        bw1.Write((byte)textBox4.Text[textBox4.Text.Length - (i + 1)]);
                                    }
                                }

                                bw1.Close();
                                fs2.Close();
                            }
                        }
                        else
                        {
                            AddLogItem("Checksum failed! read = " + readchecksum.ToString("X08") + " versus calculated = " + checksum.ToString("X08"));
                            if (checkBox1.Checked || checkBox2.Checked || checkBox3.Checked || checkBox4.Checked)
                            {
                                AddLogItem("Writing file " + m_currentfile + "-modified.bin with modified checksum/parameters");
                                fsi1.Position = 0;
                                FileStream fs2 = new FileStream(m_currentfile + "-modified.bin", FileMode.Create);
                                BinaryWriter bw1 = new BinaryWriter(fs2);
                                for (int t = 0; t < 0x0003FFFC; t++)
                                {
                                    bw1.Write(br1.ReadByte());
                                }
                                bw1.Write((byte)((checksum & 0xFF000000) >> 24));
                                bw1.Write((byte)((checksum & 0x00FF0000) >> 16));
                                bw1.Write((byte)((checksum & 0x0000FF00) >> 8));
                                bw1.Write((byte)((checksum & 0x000000FF)));
                                if (checkBox2.Checked && textBox2.Text.Length == 12)
                                {
                                    fs2.Position = 0x3FFB4; // IMMO ID, backwards
                                    for (int i = 0; i < textBox2.Text.Length; i++)
                                    {
                                        // backwards!!!
                                        bw1.Write((byte)textBox2.Text[textBox2.Text.Length - (i + 1)]);
                                    }
                                    if (checkBox3.Checked && textBox3.Text.Length == 12)
                                    {
                                        fs2.Position = 0x3FFDC; // software ID
                                        for (int i = 0; i < textBox3.Text.Length; i++)
                                        {
                                            // backwards!!!
                                            bw1.Write((byte)textBox3.Text[textBox3.Text.Length - (i + 1)]);
                                        }
                                    }
                                    if (checkBox4.Checked && textBox4.Text.Length == 7)
                                    {
                                        fs2.Position = 0x3FFF3; // Boxnumber
                                        for (int i = 0; i < textBox4.Text.Length; i++)
                                        {
                                            // backwards!!!
                                            bw1.Write((byte)textBox4.Text[textBox4.Text.Length - (i + 1)]);
                                        }
                                    }
                                }

                                bw1.Close();
                                fs2.Close();
                            }
                        }
                        br1.Close();
                        fsi1.Close();
                    }
                    else
                    {
                        AddLogItem("End of data marker not found in file! Is this really a Trionic 5 file?");
                    }
                }
                else
                {
                    AddLogItem("File has incorrect length (<> 0x00040000)");
                }
            }
            else
            {
                AddLogItem("File doesn't seem to exist, please select a valid filename");
            }
            AddLogItem("Finished.");*/
        }

        private void ribbonControl1_Click(object sender, EventArgs e)
        {

        }

        private void LoadXMLFromRepository(string xmlfile, string filename, DateTime creationtime)
        {
            System.Data.DataTable dt = new System.Data.DataTable(Path.GetFileNameWithoutExtension(filename));
            dt.Columns.Add("SYMBOLNAME");
            dt.Columns.Add("SRAMADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("FLASHADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHBYTES", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHVALUES", Type.GetType("System.Int32"));
            dt.Columns.Add("DESCRIPTION");
            dt.Columns.Add("ISCHANGED", Type.GetType("System.Boolean"));
            dt.Columns.Add("CATEGORY", Type.GetType("System.Int32"));
            dt.ReadXml(xmlfile);
            // we have to fill the collections too
            m_symbols = new SymbolCollection();
            m_addresslookup = new AddressLookupCollection();
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    string symbolname = dr["SYMBOLNAME"].ToString();
                    int sramaddress = Convert.ToInt32(dr["SRAMADDRESS"]);
                    int flashaddress = Convert.ToInt32(dr["FLASHADDRESS"]);
                    int lengthbytes = Convert.ToInt32(dr["LENGTHBYTES"]);
                    SymbolHelper sh = new SymbolHelper();
                    sh.Varname = symbolname;
                    sh.Start_address = sramaddress;
                    sh.Flash_start_address = flashaddress;
                    sh.Length = lengthbytes;
                    m_symbols.Add(sh);
                    AddressLookupHelper alh = new AddressLookupHelper();
                    alh.Flash_address = flashaddress;
                    alh.Sram_adddress = sramaddress;
                    m_addresslookup.Add(alh);
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }
            

            gridSymbols.DataSource = dt;
            // always?
            repositoryItemLookUpEdit1.DataSource = dt;
            repositoryItemLookUpEdit1.DisplayMember = "SYMBOLNAME";


            gridViewSymbols.BestFitColumns();
            SetVSSStatus();

        }

        private void SetVSSStatus()
        {
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    if (sh.Length == 6)
                    {
                        byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);
                        byte sign = Convert.ToByte(vssdata.GetValue(5));

                        if ((sign & 0x80) > 0)
                        {
                            from_prog_change = true;
                            checkVSSEnable.Checked = true;
                            from_prog_change = false;
                        }
                        else checkVSSEnable.Checked = false;
                    }
                    else
                    {
                        checkVSSEnable.Checked = false;
                    }
                }
            }
        }

        private void LoadXMLFromRepositoryForCompare(string xmlfile, string filename, DateTime creationtime, SymbolCollection curSymbolCollection, AddressLookupCollection curAddresslookupCollection)
        {
            System.Data.DataTable dt = new System.Data.DataTable(Path.GetFileNameWithoutExtension(filename));
            dt.Columns.Add("SYMBOLNAME");
            dt.Columns.Add("SRAMADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("FLASHADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHBYTES", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHVALUES", Type.GetType("System.Int32"));
            dt.Columns.Add("DESCRIPTION");
            dt.Columns.Add("ISCHANGED", Type.GetType("System.Boolean"));
            dt.Columns.Add("CATEGORY", Type.GetType("System.Int32"));
            dt.ReadXml(xmlfile);
            // we have to fill the collections too
            //curSymbolCollection = new SymbolCollection();
            //curAddresslookupCollection = new AddressLookupCollection();
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    string symbolname = dr["SYMBOLNAME"].ToString();
                    int sramaddress = Convert.ToInt32(dr["SRAMADDRESS"]);
                    int flashaddress = Convert.ToInt32(dr["FLASHADDRESS"]);
                    int lengthbytes = Convert.ToInt32(dr["LENGTHBYTES"]);
                    SymbolHelper sh = new SymbolHelper();
                    sh.Varname = symbolname;
                    sh.Start_address = sramaddress;
                    sh.Flash_start_address = flashaddress;
                    sh.Length = lengthbytes;
                    curSymbolCollection.Add(sh);
                    AddressLookupHelper alh = new AddressLookupHelper();
                    alh.Flash_address = flashaddress;
                    alh.Sram_adddress = sramaddress;
                    curAddresslookupCollection.Add(alh);
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }
        }



        private void OpenFile(string filename)
        {
            if (File.Exists(filename))
            {
                m_currentsramfile = string.Empty; // geen sramfile erbij
                barStaticItem3.Caption = string.Empty;
                if (Path.GetExtension(filename).ToUpper() == ".BIN")
                {
                    m_fileiss19 = false;
                    m_currentfile = filename;
                    barStaticItem1.Caption = System.IO.Path.GetFileName(m_currentfile);
                    this.Text = "T5 tool suite - " + System.IO.Path.GetFileName(m_currentfile);
                }
                else if (Path.GetExtension(filename).ToUpper() == ".S19")
                {
                    m_fileiss19 = true;
                    srec2bin convert = new srec2bin();
                    string convertedfile = string.Empty;
                    if (convert.ConvertSrecToBin(filename, out convertedfile))
                    {
                        m_currentfile = convertedfile;
                        barStaticItem1.Caption = System.IO.Path.GetFileName(m_currentfile);
                        this.Text = "T5 tool suite - " + System.IO.Path.GetFileName(m_currentfile);
                    }
                    else
                    {
                        MessageBox.Show("Failed to convert S19 file to binary");
                    }
                }
                gridSymbols.DataSource = null;
                repositoryItemLookUpEdit1.DataSource = null;
                AddFileToMRUList(m_currentfile);
                SetTuningMenuEnabled(true);

                string xmlfilename = System.Windows.Forms.Application.StartupPath + "\\repository\\" + Path.GetFileNameWithoutExtension(filename) + File.GetCreationTime(filename).ToString("yyyyMMddHHmmss") + ".xml";
                if (File.Exists(xmlfilename))
                {
                    // controleer nog datum & tijd
                    LoadXMLFromRepository(xmlfilename, filename, File.GetCreationTime(filename));
                }
                else if (m_appSettings.AutoExtractSymbols)
                {
                    ExtractSymbolTable();
                }
                if (!verifychecksum())
                {
                    if (m_appSettings.AutoChecksum)
                    {
                        updatechecksum();
                        if (m_fileiss19)
                        {
                            // automatisch terugschrijven
                            srec2bin cnvrt = new srec2bin();
                            cnvrt.ConvertBinToSrec(m_currentfile);
                        }
                    }
                    else if (MessageBox.Show("Checksum invalid, auto correct?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        updatechecksum();
                        if (m_fileiss19)
                        {
                            // automatisch terugschrijven
                            srec2bin cnvrt = new srec2bin();
                            cnvrt.ConvertBinToSrec(m_currentfile);
                        }
                    }
                }
            }
            if (dockSymbols.Visibility != DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockSymbols.Show();
            }
            if (verifychecksum()) barButtonItem20.ImageIndex = 3;
            else barButtonItem20.ImageIndex = 2;
            SetVSSStatus();
            try
            {
                string ramfile = Path.GetDirectoryName(m_currentfile) + "\\" + Path.GetFileNameWithoutExtension(m_currentfile) + ".ram";
                if (File.Exists(ramfile))
                {
                    OpenSRAMFile(ramfile);
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
        }

        private void InitMruSystem()
        {
            mrudt = new System.Data.DataTable();
            mrudt.Columns.Add("FILENAME");
            mrudt.Columns.Add("FULLPATH");
            // haal uit het register!
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software\\T5SuitePro");
            //m_mappath = "";
            using (RegistryKey Settings = TempKey.CreateSubKey("MRUList"))
            {
                if (Settings != null)
                {
                    string[] vals = Settings.GetValueNames();
                    foreach (string a in vals)
                    {
                        try
                        {
                            string fullpath = Settings.GetValue(a).ToString();
                            mrudt.Rows.Add(a, fullpath);
                        }
                        catch (Exception E)
                        {
                            Console.WriteLine(E.Message);
                        }
                    }

                }
            }

            
        }

        private void AddFileToMRUList(string m_currentfile)
        {
            bool fnd = false;
            foreach (DataRow dr in mrudt.Rows)
            {
                if (dr["FULLPATH"].ToString() == m_currentfile)
                {
                    fnd = true;
                }
            }
            if (!fnd)
            {
                mrudt.Rows.Add(Path.GetFileName(m_currentfile), m_currentfile);
            }
        }

        private void SaveMRUList()
        {
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software\\T5SuitePro");
            using (RegistryKey saveSettings = TempKey.CreateSubKey("MRUList"))
            {
                foreach (DataRow dr in mrudt.Rows)
                {
                    saveSettings.SetValue(dr["FILENAME"].ToString(), dr["FULLPATH"].ToString());
                }
            }
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                OpenFile(openFileDialog1.FileName);
            }
            
        }

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (m_currentfile != string.Empty)
            {
                if (saveFileDialog3.ShowDialog() == DialogResult.OK)
                {
                    if (!verifychecksum())
                    {
                        if (m_appSettings.AutoChecksum)
                        {
                            updatechecksum();
                            if (m_fileiss19)
                            {
                                // automatisch terugschrijven
                                srec2bin cnvrt = new srec2bin();
                                cnvrt.ConvertBinToSrec(m_currentfile);
                            }
                        }
                        else if (MessageBox.Show("Checksum invalid, auto correct?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            updatechecksum();
                            if (m_fileiss19)
                            {
                                // automatisch terugschrijven
                                srec2bin cnvrt = new srec2bin();
                                cnvrt.ConvertBinToSrec(m_currentfile);
                            }

                        }
                    }

                    srec2bin convert = new srec2bin();
                    if (m_appSettings.DebugMode)
                    {
                        if (!convert.ConvertBinToSrecS2Format(m_currentfile))
                        {
                            MessageBox.Show("Failed to convert file to S19 format");
                        }
                    }
                    else
                    {
                        if (!convert.ConvertBinToSrec(m_currentfile, saveFileDialog3.FileName))
                        {
                            MessageBox.Show("Failed to convert file to S19 format");
                        }

                    }
                }
            }
        }

        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void barButtonItem14_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExtractSymbolTable();
        }

        public static int IndexOf(byte[] arrayToSearchThrough, byte[] patternToFind)
        {
            if (patternToFind.Length > arrayToSearchThrough.Length)
                return -1;
            for (int i = 0; i < arrayToSearchThrough.Length - patternToFind.Length; i++)
            {
                bool found = true;
                for (int j = 0; j < patternToFind.Length; j++)
                {
                    if (arrayToSearchThrough[i + j] != patternToFind[j])
                    {
                        found = false;
                        break;
                    }
                }
                if (found)
                {
                    return i;
                }
            }
            return -1;
        }

        private void barButtonItem22_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                string checksumasstring = readchecksum();
                if (checksumasstring != string.Empty)
                {
                    MessageBox.Show("File checksum is : " + checksumasstring);
                }
                else
                {
                    MessageBox.Show("Unable to determine file checksum");
                }
            }
        }

        private void barButtonItem20_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                frmChecksumVerification checkverify = new frmChecksumVerification();
                checkverify.Calcchecksum = calculatechecksum();
                checkverify.Filechecksum = readchecksum();
                if (checkverify.Calcchecksum != checkverify.Filechecksum)
                {
                    checkverify.Message = "Checksum failed!";
                }
                if (checkverify.ShowDialog() == DialogResult.OK)
                {
                    updatechecksum();
                }
                else
                {
                    verifychecksum();
                }
                //if(
                /*if (verifychecksum())
                {
                    MessageBox.Show("Checksum verified, ok");
                }
                else
                {
                    MessageBox.Show("Checksum failed");
                }*/
            }
        }

        private void barButtonItem21_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                if (!updatechecksum())
                {
                    MessageBox.Show("Checksum already matched!");
                }
                else
                {
                    MessageBox.Show("Checksum updated in file!");
                }
            }
        }

        private void barButtonItem19_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                MessageBox.Show("Immo code in file: " + readimmocode());
            }
        }

        private void barButtonItem23_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                frmImmoCode immocode = new frmImmoCode();
                immocode.ImmoCode = readimmocode();
                if (immocode.ShowDialog() == DialogResult.OK)
                {
                    writeimmocode(immocode.ImmoCode);
                }
            }
        }

        private void barButtonItem17_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                MessageBox.Show("Software ID in file: " + readsoftwareid());
            }
        }

        private void barButtonItem24_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                frmSoftwareID softwareid = new frmSoftwareID();
                softwareid.SoftwareID = readsoftwareid();
                if (softwareid.ShowDialog() == DialogResult.OK)
                {
                    writesoftwareid(softwareid.SoftwareID);
                }
            }
        }

        private void barButtonItem15_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                MessageBox.Show("File comment: " + readfilecomment());
            }
        }

        private void barButtonItem25_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                frmComment comment = new frmComment();
                comment.Comment = readfilecomment();
                if (comment.ShowDialog() == DialogResult.OK)
                {
                    writecomment(comment.Comment);
                }
            }
        }

        private string readcarmodel()
        {
            string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = 0x03FFD0;
            string temp = string.Empty;
            for (int i = 0; i < 4; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < 4; i2++)
            {
                retval += temp[3 - i2];
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();

            return retval;
        }

        private void writecarmodel(string model)
        {
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);
            fsi1.Position = 0x03FFD0;
            for (int i = 0; i < model.Length; i++)
            {
                // backwards!!!
                bw1.Write((byte)model[model.Length - (i + 1)]);
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();

        }

        private string readenginetype()
        {
          /*  string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = 0x03FFD5;
            string temp = string.Empty;
            for (int i = 0; i < 5; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < 5; i2++)
            {
                retval += temp[4 - i2];
            }
            br1.Close();
            fsi1.Close();
            return retval;*/
            int length = 0;
            string value = string.Empty;
            int offset = ReadMarkerAddress(0x04, out length, out value);
            return value;
        }

        private void writeenginetype(string model)
        {
            int length = 0;
            string value = string.Empty;
            int offset = ReadMarkerAddress(0x04, out length, out value);
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);

            fsi1.Position = offset-length;
            for (int i = 0; i < length; i++)
            {
                // backwards!!!
                if (model.Length > length - (i + 1))
                {
                    bw1.Write((byte)model[length - (i + 1)]);
                }
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();

        }



        private string readimmocode()
        {
            string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = 0x03FFB4;
            string temp = string.Empty;
            for (int i = 0; i < 6; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < 6; i2++)
            {
                retval += temp[5 - i2];
            }
            fsi1.Flush();

            br1.Close();
            fsi1.Close();
            fsi1.Dispose();

            return retval;
        }

        private void writeimmocode(string immocode)
        {
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);
            fsi1.Position = 0x03FFB4;
            for (int i = 0; i < immocode.Length; i++)
            {
                // backwards!!!
                bw1.Write((byte)immocode[immocode.Length - (i + 1)]);
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();

        }

         /*private string readboxnumber()
         {
             string retval = string.Empty;
             FileStream fsi1 = File.OpenRead(m_currentfile);
             BinaryReader br1 = new BinaryReader(fsi1);
             fsi1.Position = 0x03FFB4;
             string temp = string.Empty;
             for (int i = 0; i < 6; i++)
             {
                 temp += (char)br1.ReadByte();
             }
             for (int i2 = 0; i2 < 6; i2++)
             {
                 retval += temp[5 - i2];
             }
             br1.Close();
             fsi1.Close();
             return retval;
         }

         private void writeboxnumber(string boxnumber)
         {
             FileStream fsi1 = File.OpenWrite(m_currentfile);
             BinaryWriter bw1 = new BinaryWriter(fsi1);
             fsi1.Position = 0x03FFB4;
             for (int i = 0; i < boxnumber.Length; i++)
             {
                 // backwards!!!
                 bw1.Write((byte)boxnumber[immocode.Length - (i + 1)]);
             }
             bw1.Close();
             fsi1.Close();
         }*/


        private string readpartnumber()
        {
            int length = 0;
            string value = string.Empty;
            int offset = ReadMarkerAddress(0x01, out length, out value);
            string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = offset - length;
            string temp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < length; i2++)
            {
                retval += temp[(length-1) - i2];
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();

            return retval;
        }

        private void writepartnumber(string boxnumber)
        {
            int length = 0;
            string value = string.Empty;
            int offset = ReadMarkerAddress(0x01, out length, out value);
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);

            fsi1.Position = offset - length;
            for (int i = 0; i < length; i++)
            {
                // backwards!!!
                if (boxnumber.Length > length - (i + 1))
                {
                    bw1.Write((byte)boxnumber[length - (i + 1)]);
                }
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();

        }

        private string readsoftwareid()
        {
            int length = 0;
            string value = string.Empty;
            int offset = ReadMarkerAddress(0x02, out length, out value);
            string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = offset - length;
            string temp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < length; i2++)
            {
                retval += temp[(length-1) - i2];
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();

            return retval;
        }

        private void writesoftwareid(string softwareid)
        {
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);
            fsi1.Position = 0x3FFDC;
            for (int i = 0; i < softwareid.Length; i++)
            {
                // backwards!!!
                bw1.Write((byte)softwareid[softwareid.Length - (i + 1)]);
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();

        }


        private string readfilecomment()
        {
            string retval = string.Empty;
            FileStream fsi1 = File.OpenRead(m_currentfile);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = 0x3FFBC;
            string temp = string.Empty;
            for (int i = 0; i < 30; i++)
            {
                temp += (char)br1.ReadByte();
            }
            for (int i2 = 0; i2 < 30; i2++)
            {
                retval += temp[29 - i2];
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();

            return retval;
        }

        private byte readbytefromfile(string filename, int address)
        {
            byte retval = 0;
            FileStream fsi1 = File.OpenRead(filename);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = address;
            retval = br1.ReadByte();
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();
            /*            System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(5);
                        System.Windows.Forms.Application.DoEvents();*/
            return retval;
        }

        private void writebyteinfile(string filename, int address, byte value)
        {
            FileStream fsi1 = File.OpenWrite(filename);
            BinaryWriter br1 = new BinaryWriter(fsi1);
            fsi1.Position = address;
            br1.Write(value);
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();
            /*System.Windows.Forms.Application.DoEvents();
            System.Threading.Thread.Sleep(5);
            System.Windows.Forms.Application.DoEvents();*/
        }

        private byte[] readdatafromfile(string filename, int address, int length)
        {
            byte[] retval = new byte[length];
            FileStream fsi1 = File.OpenRead(filename);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = address;
            string temp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                retval.SetValue(br1.ReadByte(), i);
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();
            return retval;
        }

        private byte[] readdatafromSRAMfile(string filename, int address, int length)
        {
            byte[] retval = new byte[length];
            FileStream fsi1 = File.OpenRead(filename);
            BinaryReader br1 = new BinaryReader(fsi1);
            fsi1.Position = address;
            string temp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                retval.SetValue(br1.ReadByte(), i);
            }
            fsi1.Flush();
            br1.Close();
            fsi1.Close();
            fsi1.Dispose();
            return retval;
        }


        private void writecomment(string comment)
        {
            FileStream fsi1 = File.OpenWrite(m_currentfile);
            BinaryWriter bw1 = new BinaryWriter(fsi1);
            fsi1.Position = 0x3FFBC;
            for (int i = 0; i < comment.Length; i++)
            {
                // backwards!!!
                bw1.Write((byte)comment[comment.Length - (i + 1)]);
            }
            fsi1.Flush();
            bw1.Close();
            fsi1.Close();
            fsi1.Dispose();
        }


        private bool isSixteenBitTable(string symbolname)
        {
            if (symbolname.StartsWith("Ign_map_0")) return true;
            else if (symbolname.StartsWith("Ign_map_1")) return true;
            else if (symbolname.StartsWith("Ign_map_2")) return true;
            else if (symbolname.StartsWith("Ign_map_4")) return true;
            else if (symbolname.StartsWith("Ign_map_5")) return true;
            else if (symbolname.StartsWith("Ign_map_7")) return true;
            else if (symbolname.StartsWith("Ign_map_8")) return true;
            else if (symbolname.StartsWith("Iv_min_tab!")) return true;
            else if (symbolname.StartsWith("Iv_min_tab_ac!")) return true;
            else if (symbolname.StartsWith("Misfire_map_x_axis!")) return true;
            else if (symbolname.StartsWith("Max_regl_temp_1!")) return true;
            else if (symbolname.StartsWith("Mis200_map!")) return true;
            else if (symbolname.StartsWith("Reg_kon_mat")) return true;
            else if (symbolname.StartsWith("Max_regl_temp_1")) return true;
            else if (symbolname.StartsWith("Max_regl_temp_2")) return true;
            else if (symbolname.StartsWith("Mis1000_map!")) return true;
            else if (symbolname.StartsWith("Knock_ref_matrix!")) return true;
            else if (symbolname.StartsWith("Detect_map!")) return true; //??
            else if (symbolname.StartsWith("Knock_wind_on_tab!")) return true;
            else if (symbolname.StartsWith("Lknock_oref_tab!")) return true;
            else if (symbolname.StartsWith("Knock_lim_tab!")) return true;
            else if (symbolname.StartsWith("Knock_wind_off_tab!")) return true;
            else if (symbolname.StartsWith("Turbo_knock_tab!")) return true;
            else if (symbolname.StartsWith("Knock_press_tab!")) return true;
            else if (symbolname.StartsWith("Idle_drift_tab!")) return true;
            else if (symbolname.StartsWith("Last_reg_kon!")) return true;
            else if (symbolname.StartsWith("Shift_rpm! (automaat?)")) return true;
            else if (symbolname.StartsWith("Ign_map_6_x_axis!")) return true;
            else if (symbolname.StartsWith("Ign_map_6_y_axis!")) return true;
            else if (symbolname.StartsWith("Gear_st!")) return true;
            else if (symbolname.StartsWith("Reg_varv!")) return true;
            else if (symbolname.StartsWith("Trans_y_st!")) return true;
            else if (symbolname.StartsWith("Idle_st_rpm!")) return true;
            else if (symbolname.StartsWith("Dash_rpm_axis!")) return true;
            else if (symbolname.StartsWith("Ramp_down_ram!")) return true;
            else if (symbolname.StartsWith("Ramp_up_ram!")) return true;
            else if (symbolname.StartsWith("Idle_start_extra!")) return true;
            else if (symbolname.StartsWith("Idle_start_extra_ramp!")) return true;
            else if (symbolname.StartsWith("Idle_temp_off!")) return true;
            else if (symbolname.StartsWith("Idle_rpm_tab!")) return true;
            else if (symbolname.StartsWith("Derivata_br_sp!")) return true;
            else if (symbolname.StartsWith("Derivata_br_tab_pos!")) return true;
            else if (symbolname.StartsWith("Derivata_br_tab_neg!")) return true;
            else if (symbolname.StartsWith("Br_plus_tab!")) return true;
            else if (symbolname.StartsWith("Br_minus_tab!")) return true;
            else if (symbolname.StartsWith("Start_tab!")) return true;
            else if (symbolname.StartsWith("Temp_reduce_y_st!")) return true;
            else if (symbolname.StartsWith("Idle_tryck!")) return true;
            else if (symbolname.StartsWith("Iv_start_time_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox1_filt_coef_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox2_filt_coef_tab!")) return true;
            else if (symbolname.StartsWith("Cat_air_flow_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox1_per_hi_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox1_per_lo_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox1_err_max_tab!")) return true;
            else if (symbolname.StartsWith("Cat_ox1_dev_max_tab!")) return true;
            else if (symbolname.StartsWith("Batt_korr_tab!")) return true;
            else if (symbolname.StartsWith("Kadapt_max_ref!")) return true;
            else if (symbolname.StartsWith("Ign_map_3_x_axis!")) return true;
            else if (symbolname.StartsWith("Last_varv_st!")) return true;
            else if (symbolname.StartsWith("Fuel_map_yaxis!")) return true;
            else if (symbolname.StartsWith("Ign_map_3_y_axis!")) return true;
            else if (symbolname.StartsWith("Pwm_ind_rpm!")) return true;
            else if (symbolname.StartsWith("Max_regl_sp!")) return true;
            else if (symbolname.StartsWith("Idle_ac_tab!")) return true;
            else if (symbolname.StartsWith("Wait_count_tab!")) return true;
            else if (symbolname.StartsWith("Knock_average_tab!")) return true;
            else if (symbolname.StartsWith("Knock_wind_rpm!")) return true;
            else if (symbolname.StartsWith("Detect_map_y_axis!")) return true;
            else if (symbolname.StartsWith("Misfire_map_y_axis!")) return true;
            else if (symbolname.StartsWith("Detect_map_x_axis!")) return true;
            else if (symbolname.StartsWith("Rpm_max!")) return true;
            else if (symbolname.StartsWith("Tid_Konst!")) return true;
            else if (symbolname.StartsWith("min_tid!")) return true;
            else if (symbolname.StartsWith("Kadapt_rpm_high!")) return true;
            else if (symbolname.StartsWith("Kadapt_rpm_low!")) return true;
            else if (symbolname.StartsWith("Knock_start!")) return true;
            else if (symbolname.StartsWith("Min_rpm_closed_loop!")) return true;
            else if (symbolname.StartsWith("Min_rpm_gadapt!")) return true;
            else if (symbolname.StartsWith("Ign_offset!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl1!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl2!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl3!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl4!")) return true;
            else if (symbolname.StartsWith("Ign_offset_adapt!")) return true;
            else if (symbolname.StartsWith("Max_rpm_gadapt!")) return true;
            else if (symbolname.StartsWith("Temp_ramp_value!")) return true;
            else if (symbolname.StartsWith("Global_adapt_nr!")) return true;
            else if (symbolname.StartsWith("Ign_idle_angle!")) return true;
            else if (symbolname.StartsWith("Knock_ang_dec")) return true;
            else if (symbolname.StartsWith("Knock_wind_rpm")) return true;
            else if (symbolname.StartsWith("Knock_matrix_time")) return true;
            else if (symbolname.StartsWith("Radius_of_roll!")) return true;
            return false;
        }

        private bool isSixteenBitConstant(string symbolname)
        {
            if (symbolname.StartsWith("Rpm_max!")) return true;
            else if (symbolname.StartsWith("Tid_Konst!")) return true;
            else if (symbolname.StartsWith("min_tid!")) return true;
            else if (symbolname.StartsWith("Kadapt_rpm_high!")) return true;
            else if (symbolname.StartsWith("Kadapt_rpm_low!")) return true;
            else if (symbolname.StartsWith("Knock_start!")) return true;
            else if (symbolname.StartsWith("Min_rpm_closed_loop!")) return true;
            else if (symbolname.StartsWith("Min_rpm_gadapt!")) return true;
            else if (symbolname.StartsWith("Ign_offset!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl1!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl2!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl3!")) return true;
            else if (symbolname.StartsWith("Ign_offset_cyl4!")) return true;
            else if (symbolname.StartsWith("Ign_offset_adapt!")) return true;
            else if (symbolname.StartsWith("Max_rpm_gadapt!")) return true;
            else if (symbolname.StartsWith("Temp_ramp_value!")) return true;
            else if (symbolname.StartsWith("Global_adapt_nr!")) return true;
            else if (symbolname.StartsWith("Ign_idle_angle!")) return true;
            else if (symbolname.StartsWith("Knock_ang_dec")) return true;
            else if (symbolname.StartsWith("Knock_wind_rpm")) return true;
            else if (symbolname.StartsWith("Knock_matrix_time")) return true;
            return false;
        }

        private bool varIsTable(string symbolname)
        {
            if (symbolname.StartsWith("Ign_map_0")) return true;
            else if (symbolname.StartsWith("Ign_map_1")) return true;
            else if (symbolname.StartsWith("Ign_map_2")) return true;
            else if (symbolname.StartsWith("Ign_map_3")) return true;
            else if (symbolname.StartsWith("Ign_map_4")) return true;
            else if (symbolname.StartsWith("Ign_map_5")) return true;
            else if (symbolname.StartsWith("Ign_map_6")) return true;
            else if (symbolname.StartsWith("Ign_map_7")) return true;
            else if (symbolname.StartsWith("Ign_map_8")) return true;
            else if (symbolname.StartsWith("Knock_press_tab!")) return true;
            else if (symbolname.StartsWith("Turbo_knock_tab")) return true;
            else if (symbolname.StartsWith("Knock_wind_off_tab")) return true;
            else if (symbolname.StartsWith("Knock_lim_tab")) return true;
            else if (symbolname.StartsWith("LKnock_oref_tab")) return true;
            else if (symbolname.StartsWith("Knock_wind_on_tab")) return true;
            else if (symbolname.StartsWith("Idle_st_last")) return true;
            else if (symbolname.StartsWith("Temp_reduce_mat_2!")) return true;
            else if (symbolname.StartsWith("Temp_reduce_mat!")) return true;
            else if (symbolname.StartsWith("Detect_map!")) return true;
            else if (symbolname.StartsWith("Knock_ref_matrix!")) return true;
            else if (symbolname.StartsWith("Mis1000_map!")) return true;
            else if (symbolname.StartsWith("Overstid_tab")) return true;
            else if (symbolname.StartsWith("Max_regl_temp_2")) return true;
            else if (symbolname.StartsWith("Max_regl_temp_1")) return true;
            else if (symbolname.StartsWith("Reg_kon_mat")) return true;
            else if (symbolname.StartsWith("Regl_tryck_sgm!")) return true;
            else if (symbolname.StartsWith("Regl_tryck_fgm!")) return true;
            else if (symbolname.StartsWith("Mis200_map!")) return true;
            else if (symbolname.StartsWith("Del_mat!")) return true;
            else if (symbolname.StartsWith("Lufttemp_tab!")) return true;
            else if (symbolname.StartsWith("Lacc_clear_tab!")) return true;
            else if (symbolname.StartsWith("P_fors!")) return true;
            else if (symbolname.StartsWith("I_fors!")) return true;
            else if (symbolname.StartsWith("D_fors!")) return true;
            else if (symbolname.StartsWith("Kyltemp_tab!")) return true;
            else if (symbolname.StartsWith("Accel_konst!")) return true;
            else if (symbolname.StartsWith("Retard_konst!")) return true;
            else if (symbolname.StartsWith("Lret_konst!")) return true;
            else if (symbolname.StartsWith("Tempkomp_konst!")) return true;
            else if (symbolname.StartsWith("Fuel_knock_mat!")) return true;
            else if (symbolname.StartsWith("Lacc_konst!")) return true;
            else if (symbolname.StartsWith("Rich_step_map!")) return true;
            else if (symbolname.StartsWith("Data_namn!")) return true;
            else if (symbolname.StartsWith("Idle_fuel_korr!")) return true;
            else if (symbolname.StartsWith("Accel_konst!")) return true;
            //else if (symbolname.StartsWith("Fuel_knock_yaxis!")) return true;
            else if (symbolname.StartsWith("Fuel_knock_xaxis!")) return true;
            else if (symbolname.StartsWith("Fuel_map_yaxis!")) return true;
            else if (symbolname.StartsWith("Fuel_map_xaxis!")) return true;
            else if (symbolname.StartsWith("Insp_mat!")) return true;
            else if (symbolname.StartsWith("Tryck_mat!")) return true;
            else if (symbolname.StartsWith("Tryck_mat_a!")) return true;
            else if (symbolname.StartsWith("Pressure map")) return true;
            else if (symbolname.StartsWith("Retard_konst!")) return true;
            else if (symbolname.StartsWith("Tryck_vakt_tab!")) return true;
            else if (symbolname.StartsWith("Reg_last!")) return true;
            else if (symbolname.StartsWith("I_luft_st!")) return true;
            else if (symbolname.StartsWith("AC_wait_off!")) return true;
            else if (symbolname.StartsWith("Before_start!")) return true;
            else if (symbolname.StartsWith("AC_control!")) return true;
            else if (symbolname.StartsWith("AC_wait_on!")) return true;
            else if (symbolname.StartsWith("Eftersta_fak2!")) return true;
            else if (symbolname.StartsWith("Overstid_tab")) return true;
            else if (symbolname.StartsWith("Eftersta_fak!")) return true;
            else if (symbolname.StartsWith("Misfire_map_x_axis!")) return true;
            else if (symbolname.StartsWith("Lean_step_map!")) return true;
            else if (symbolname.StartsWith("Idle_fuel_korr")) return true;
            else if (symbolname.StartsWith("Open_loop_adapt!")) return true;
            else if (symbolname.StartsWith("Open_loop!")) return true;
            else if (symbolname.StartsWith("Open_loop_knock!")) return true;
            else if (symbolname.StartsWith("Iv_min_tab!")) return true;
            else if (symbolname.StartsWith("Iv_min_tab_ac!")) return true;
            return false;
        }

        private int GetSymbolAddress(SymbolCollection curSymbolCollection, string symbolname)
        {
            int retval = 0;
            foreach (SymbolHelper sh in curSymbolCollection)
            {
                if (sh.Varname.StartsWith(symbolname))
                {
                    retval = sh.Flash_start_address - 0x40000;
                    /*if (symbolname == "Ign_map_0_x_axis!" || symbolname == "Ign_map_0_y_axis!")
                    {
                        Console.WriteLine("Found " + symbolname + " at: " + retval.ToString("X6"));
                    }*/
                }
            }
            return retval;
        }

        private int GetSymbolAddressSRAM(SymbolCollection curSymbolCollection, string symbolname)
        {
            int retval = 0;
            foreach (SymbolHelper sh in curSymbolCollection)
            {
                if (sh.Varname.StartsWith(symbolname))
                {
                    retval = sh.Start_address;
                }
            }
            return retval;
        }


        
        private int[] GetXaxisValues(string symbolname)
        {
            int[] retval = new int[0];
            //retval.SetValue(0, 0);
            int xaxisaddress = 0;
            int xaxislength = 0;
            bool issixteenbit = false;
            int multiplier = 1;
            if (symbolname.StartsWith("Ign_map_0!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_0_x_axis!");
                // MAP value
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_1!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_1_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_1_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_2!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_2_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_2_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_3!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_3_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_3_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_4!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_0_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_5!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_5_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_5_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_6!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_6_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_6_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_7!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_7_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_7_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_8!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_8_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_8_x_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Tryck_mat!") || symbolname.StartsWith("Pressure map"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                xaxislength = GetSymbolLength(m_symbols,"Trans_x_st!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Tryck_mat_a!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                xaxislength = GetSymbolLength(m_symbols,"Trans_x_st!");
                issixteenbit = false;
            }

            else if (symbolname.StartsWith("Insp_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_xaxis!");
                xaxislength = GetSymbolLength(m_symbols,"Fuel_map_xaxis!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Idle_fuel_korr!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Idle_st_last!");
                xaxislength = GetSymbolLength(m_symbols,"Idle_st_last!");
                issixteenbit = false;
            }
            //retard_konst
            else if (symbolname.StartsWith("Lacc_konst!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                xaxislength = GetSymbolLength(m_symbols,"Trans_x_st!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Accel_konst!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                xaxislength = GetSymbolLength(m_symbols,"Trans_x_st!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("P_fors!") || symbolname.StartsWith("I_fors!") || symbolname.StartsWith("D_fors!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Reg_last!");
                xaxislength = GetSymbolLength(m_symbols,"Reg_last!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("P_fors_a!") || symbolname.StartsWith("I_fors_a!") || symbolname.StartsWith("D_fors_a!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols, "Reg_last!");
                xaxislength = GetSymbolLength(m_symbols, "Reg_last!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Del_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_xaxis!");
                xaxislength = GetSymbolLength(m_symbols,"Fuel_map_xaxis!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Fuel_knock_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_knock_xaxis!");
                xaxislength = GetSymbolLength(m_symbols,"Fuel_knock_xaxis!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Mis200_map!") || symbolname.StartsWith("Mis1000_map!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Misfire_map_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Misfire_map_x_axis!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Temp_reduce_mat!") || symbolname.StartsWith("Temp_reduce_mat_2!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Temp_reduce_x_st!");
                xaxislength = GetSymbolLength(m_symbols,"Temp_reduce_x_st!");
                issixteenbit = false;
            }
            else if (symbolname.StartsWith("Knock_ref_matrix!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Ign_map_0_x_axis!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Detect_map!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Detect_map_x_axis!");
                xaxislength = GetSymbolLength(m_symbols,"Detect_map_x_axis!");
                issixteenbit = true;
            }
            else 
            {
                xaxislength = 0;
                int rows = 0;
                int cols = 0;
                GetTableMatrixWitdhByName(symbolname, out cols, out rows);
                retval = new int[cols];
                for (int t = 0; t < cols; t++)
                {
                    retval.SetValue(t, t);
                }
            }

            int number = xaxislength;
            if (xaxislength > 0)
            {
                byte[] axisdata = readdatafromfile(m_currentfile,xaxisaddress, xaxislength);
                if (issixteenbit) number /= 2;
                retval = new int[number];
                int offset = 0;
                for (int i = 0; i < xaxislength; i++)
                {

                    if (issixteenbit)
                    {
                        byte val1 = (byte)axisdata.GetValue(i);
                        byte val2 = (byte)axisdata.GetValue(++i);
                        int ival1 = Convert.ToInt32(val1);
                        int ival2 = Convert.ToInt32(val2);
                        int value = (ival1 * 256) + ival2;
                        value *= multiplier;
                        retval.SetValue(value, offset++);
                    }
                    else
                    {
                        byte val1 = (byte)axisdata.GetValue(i);
                        int ival1 = Convert.ToInt32(val1);
                        ival1 *= multiplier;
                        retval.SetValue(ival1, offset++);
                    }
                }
            }
            return retval;
        }

        private int[] GetYaxisValues(string symbolname)
        {
            int[] retval = new int[0];
            //retval.SetValue(0, 0);
            int yaxisaddress = 0;
            int yaxislength = 0;
            bool issixteenbit = false;
            int multiplier = 1;
            if (symbolname.StartsWith("Ign_map_0!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_0_y_axis!");
                // 16 bits
                //multiplier = 10; // RPM = 10 times
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_1!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_1_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_1_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_2!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_2_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_2_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_3!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_3_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_3_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_4!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_0_y_axis!");
                // 16 bits
                //multiplier = 10; // RPM = 10 times
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_5!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_5_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_5_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_6!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_6_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_6_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_7!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_7_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_7_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Ign_map_8!"))
            {
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_8_y_axis!");
                yaxislength = GetSymbolLength(m_symbols,"Ign_map_8_y_axis!");
                // 16 bits
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Tryck_mat!") || symbolname.StartsWith("Pressure map"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Pwm_ind_rpm!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Pwm_ind_rpm!");
                multiplier = 10;
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Tryck_mat_a!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Pwm_ind_rpm!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Pwm_ind_rpm!");
                multiplier = 10;
                issixteenbit = true;
            }

            else if (symbolname.StartsWith("Insp_mat!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Fuel_map_yaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_yaxis!");
                issixteenbit = true;
                multiplier = 10;
            }
            else if (symbolname.StartsWith("Idle_fuel_korr!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Idle_rpm_tab!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Idle_rpm_tab!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Lacc_konst!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Trans_y_st!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Trans_y_st!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Accel_konst!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Trans_y_st!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Trans_y_st!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("P_fors!") || symbolname.StartsWith("I_fors!") || symbolname.StartsWith("D_fors!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Reg_varv!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Reg_varv!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("P_fors_a!") || symbolname.StartsWith("I_fors_a!") || symbolname.StartsWith("D_fors_a!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Reg_varv!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Reg_varv!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Del_mat!"))
            {
                yaxislength = GetSymbolLength(m_symbols,"Fuel_map_yaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_yaxis!");
                multiplier = 10;
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Tryck_vakt_tab!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Fuel_map_yaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Fuel_map_yaxis!");
                multiplier = 10;
                issixteenbit = true;
                //Fuel_map_yaxis!
            }
            else if (symbolname.StartsWith("Regl_tryck_sgm!") || symbolname.StartsWith("Regl_tryck_fgm!") || symbolname.StartsWith("Regl_tryck_fgaut!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Fuel_map_yaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Fuel_map_yaxis!");
                multiplier = 10;
                issixteenbit = true;
                //Fuel_map_yaxis!
            }
            else if (symbolname.StartsWith("Fuel_knock_mat!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Fuel_map_yaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Fuel_map_yaxis!");
                multiplier = 10;
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Mis200_map!") || symbolname.StartsWith("Mis1000_map!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Misfire_map_y_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Misfire_map_y_axis!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Temp_reduce_mat!") || symbolname.StartsWith("Temp_reduce_mat_2!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Temp_reduce_y_st!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Temp_reduce_y_st!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Knock_ref_matrix!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Ign_map_0_y_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Ign_map_0_y_axis!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Detect_map!"))
            {
                yaxislength = GetSymbolLength(m_symbols, "Detect_map_y_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Detect_map_y_axis!");
                issixteenbit = true;
            }
            else if (symbolname.StartsWith("Reg_kon_mat!") || symbolname.StartsWith("Reg_kon_mat_a!"))
            {
                retval = new int[31];
                int v = 0;
                for (int ti = 2500; ti <= 5500; ti += 100)
                {
                    retval.SetValue(ti, v++);
                }
            }
            int number = yaxislength;
            if (yaxislength > 0)
            {
                byte[] axisdata = readdatafromfile(m_currentfile,yaxisaddress, yaxislength);
                if (issixteenbit) number /= 2;
                retval = new int[number];
                int offset = 0;
                for (int i = 0; i < yaxislength; i++)
                {

                    if (issixteenbit)
                    {
                        byte val1 = (byte)axisdata.GetValue(i);
                        byte val2 = (byte)axisdata.GetValue(++i);
                        int ival1 = Convert.ToInt32(val1);
                        int ival2 = Convert.ToInt32(val2);
                        int value = (ival1 * 256) + ival2;
                        value *= multiplier;
                        retval.SetValue(value, offset++);
                    }
                    else
                    {
                        byte val1 = (byte)axisdata.GetValue(i);
                        int ival1 = Convert.ToInt32(val1);
                        ival1 *= multiplier;
                        retval.SetValue(ival1, offset++);
                    }
                }
            }
            return retval;
        }



        private void GetXYAxisAddresses(string symbolname, out int xaxisaddress, out int yaxisaddress, out bool isxaxis16bit, out bool isyaxis16bit)
        {
            xaxisaddress = 0;
            yaxisaddress = 0;
            isxaxis16bit = false;
            isyaxis16bit = false;
            if (symbolname.StartsWith("Ign_map_0!"))
            {
                //Console.WriteLine("Searching : " + symbolname);
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_1!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_1_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_1_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_2!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_2_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_2_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_3!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_3_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_3_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_4!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_5!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_5_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_5_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_6!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_6_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_6_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_7!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_7_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_7_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Ign_map_8!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_8_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_8_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Tryck_mat") || symbolname.StartsWith("Pressure map"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols, "Trans_x_st!");
                yaxisaddress = GetSymbolAddress(m_symbols, "Pwm_ind_rpm!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Insp_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_xaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_yaxis!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Idle_fuel_korr!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Idle_st_last!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Idle_rpm_tab!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            //retard_konst
            else if (symbolname.StartsWith("Lacc_konst!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Trans_y_st!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Accel_konst!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Trans_x_st!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Trans_y_st!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("P_fors!") || symbolname.StartsWith("I_fors!") || symbolname.StartsWith("D_fors!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Reg_last!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Reg_varv!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Del_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_xaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_yaxis!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Fuel_knock_mat!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Fuel_knock_xaxis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Fuel_map_yaxis!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Mis200_map!") || symbolname.StartsWith("Mis1000_map!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Misfire_map_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Misfire_map_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Temp_reduce_mat!") || symbolname.StartsWith("Temp_reduce_mat_2!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Temp_reduce_x_st!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Temp_reduce_y_st!");
                isxaxis16bit = false;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Knock_ref_matrix!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Ign_map_0_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
            else if (symbolname.StartsWith("Detect_map!"))
            {
                xaxisaddress = GetSymbolAddress(m_symbols,"Detect_map_x_axis!");
                yaxisaddress = GetSymbolAddress(m_symbols,"Detect_map_y_axis!");
                isxaxis16bit = true;
                isyaxis16bit = true;
            }
        }

        private void barButtonItem26_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartExcelExport();
        }

        private void StartExcelExport()
        {
            if (gridViewSymbols.SelectedRowsCount > 0)
            {
                int[] selrows = gridViewSymbols.GetSelectedRows();
                if (selrows.Length > 0)
                {
                    DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                    //frmTableDetail tabdet = new frmTableDetail();
                    string Map_name = dr.Row["SYMBOLNAME"].ToString();
                    int columns = 8;
                    int rows = 8;
                    int tablewidth = GetTableMatrixWitdhByName(Map_name, out columns, out rows);
                    int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                    if (address != 0)
                    {
                        if (address > 0x40000) address -= 0x40000;
                        int length = Convert.ToInt32(dr.Row["LENGTHBYTES"].ToString());
                        byte[] mapdata = readdatafromfile(m_currentfile, address, length);
                        int[] xaxis = GetXaxisValues(Map_name);
                        int[] yaxis = GetYaxisValues(Map_name);
                        ExportToExcel(Map_name, address, length, mapdata, columns, rows, isSixteenBitTable(Map_name), xaxis, yaxis);
                    }
                }
            }
            else
            {
                MessageBox.Show("No symbol selected in the primary symbol list");
            }
        }

        private bool CompareSymbolToCurrentFile(string symbolname, int address, int length, string filename, out float diffperc, out int diffabs, out float diffavg)
        {
            diffavg = 0;
            diffabs = 0;
            diffperc = 0;
            double totalvalue1 = 0;
            double totalvalue2 = 0;
            bool retval = true;
            if (address > 0)
            {
                if (address > 0x40000) address -= 0x40000;
                int curaddress = GetSymbolAddress(m_symbols, symbolname);
                int curlength = GetSymbolLength(m_symbols, symbolname);
                byte[] curdata = readdatafromfile(m_currentfile, curaddress, curlength);
                byte[] compdata = readdatafromfile(filename, address, length);
                if (curdata.Length != compdata.Length) return false;
                for (int offset = 0; offset < curdata.Length; offset++)
                {
                    if ((byte)curdata.GetValue(offset) != (byte)compdata.GetValue(offset))
                    {
                        diffabs++;
                        retval = false;
                    }
                    totalvalue1 += (byte)curdata.GetValue(offset);
                    totalvalue2 += (byte)compdata.GetValue(offset);
                }
                if (curdata.Length > 0)
                {
                    totalvalue1 /= curdata.Length;
                    totalvalue2 /= compdata.Length;
                    diffavg = (float)Math.Abs(totalvalue1 - totalvalue2);
                    diffperc = (diffabs * 100)/curdata.Length;
                }
            }
            
            return retval;
        }


        private void CompareSymbolTable(string filename, SymbolCollection curSymbolCollection, AddressLookupCollection curAddressLookupCollection, DevExpress.XtraGrid.GridControl curGridControl)
        {
            if (filename != string.Empty)
            {
                bool m_fileparsed = false;
                frmProgress progress = new frmProgress();
                progress.Show();
                progress.SetProgress("Initializing");

                //listView1.Items.Clear();
                SetStatusText("Start symbol parsing");
                barButtonItem14.Enabled = false;
                // available in repository?
                string xmlfilename = System.Windows.Forms.Application.StartupPath + "\\repository\\" + Path.GetFileNameWithoutExtension(filename) + File.GetCreationTime(filename).ToString("yyyyMMddHHmmss") + ".xml";
                if (File.Exists(xmlfilename))
                {
                    // controleer nog datum & tijd
                    LoadXMLFromRepositoryForCompare(xmlfilename, filename, File.GetCreationTime(filename), curSymbolCollection, curAddressLookupCollection);
                }
                else
                {
                    ParseFile(progress, filename, curSymbolCollection, curAddressLookupCollection);
                    m_fileparsed = true;
                }
                // AddLogItem("Start symbol export...");
                curSymbolCollection.SortColumn = "Start_address";
                curSymbolCollection.SortingOrder = GenericComparer.SortOrder.Ascending;
                curSymbolCollection.Sort();
                progress.SetProgress("Filling list");
                //listView1.SuspendLayout();
                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("SYMBOLNAME");
                dt.Columns.Add("SRAMADDRESS", Type.GetType("System.Int32"));
                dt.Columns.Add("FLASHADDRESS", Type.GetType("System.Int32"));
                dt.Columns.Add("LENGTHBYTES", Type.GetType("System.Int32"));
                dt.Columns.Add("LENGTHVALUES", Type.GetType("System.Int32"));
                dt.Columns.Add("DESCRIPTION");
                dt.Columns.Add("ISCHANGED", Type.GetType("System.Boolean"));
                dt.Columns.Add("CATEGORY", Type.GetType("System.Int32"));
                dt.Columns.Add("DIFFPERCENTAGE", Type.GetType("System.Double"));
                dt.Columns.Add("DIFFABSOLUTE", Type.GetType("System.Int32"));
                dt.Columns.Add("DIFFAVERAGE", Type.GetType("System.Double"));

                foreach (SymbolHelper sh in curSymbolCollection)
                {
                    float diffperc = 0;
                    int diffabs = 0;
                    float diffavg = 0;
                    if (!CompareSymbolToCurrentFile(sh.Varname, sh.Flash_start_address, sh.Length, filename, out diffperc, out diffabs, out diffavg))
                    {
                        dt.Rows.Add(sh.Varname, sh.Start_address, sh.Flash_start_address, sh.Length, sh.Length, TranslateSymbolName(sh.Varname),false,  (int)TranslateSymbolNameToCategory(sh.Varname),diffperc, diffabs, diffavg);
                    }
                }
                curGridControl.DataSource = dt;
                if (m_fileparsed)
                {
                    CreateRepositoryItem(filename, curSymbolCollection);
                }
                //listView1.ResumeLayout();
                SetStatusText("Idle.");
                barButtonItem14.Enabled = true;
                progress.Close();

            }
            else
            {
                MessageBox.Show("No file selected, please select one first");
            }

        }


        private void barButtonItem10_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // deze reeds geopende binary vergelijken (symbol voor symbol) met een andere binary
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SymbolCollection compSymbols = new SymbolCollection();
                AddressLookupCollection compAddressLookup = new AddressLookupCollection();

                DevExpress.XtraBars.Docking.DockPanel dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                CompareResults tabdet = new CompareResults();
                tabdet.Dock = DockStyle.Fill;
                tabdet.Filename = openFileDialog1.FileName;
                tabdet.onSymbolSelect += new CompareResults.NotifySelectSymbol(tabdet_onSymbolSelect);
                dockPanel.Controls.Add(tabdet);
                //dockPanel.DockAsTab(dockPanel1);
                dockPanel.Text = "Compare results: " + Path.GetFileName(openFileDialog1.FileName);
                bool isDocked = false;
                foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                {
                    if (pnl.Text.StartsWith("Compare results: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                    {
                        dockPanel.DockAsTab(pnl,0);
                        isDocked = true;
                        break;
                    }
                }
                if (!isDocked)
                {
                    dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Left, 1);
                    dockPanel.Width = 400;
                }
                CompareSymbolTable(openFileDialog1.FileName, compSymbols, compAddressLookup, tabdet.gridControl1);
                tabdet.SetGridWidth();
                // nu alle symbolen aflopen en evt. weghalen uit de 
            }
        }

        private void StartCompareMapViewer(string SymbolName, string Filename, int SymbolAddress, int SymbolLength)
        {
            DevExpress.XtraBars.Docking.DockPanel dockPanel;
            bool pnlfound = false;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {

                if (pnl.Text == "Symbol: " + SymbolName + " [" + Path.GetFileName(Filename) + "]")
                {
                    dockPanel = pnl;
                    pnlfound = true;
                    dockPanel.Show();
                    // nog data verversen?
                    foreach (Control c in dockPanel.Controls)
                    {
                        /* if (c is MapViewer)
                         {
                             MapViewer tempviewer = (MapViewer)c;
                             tempviewer.Map_content
                         }*/
                    }
                }
            }
            if (!pnlfound)
            {
                dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                MapViewer tabdet = new MapViewer();
                //tabdet.IsHexMode = barViewInHex.Checked;
                if (barViewInHex.Checked)
                {
                    tabdet.Viewtype = ViewType.Hexadecimal;
                }
                else
                {
                    tabdet.Viewtype = ViewType.Easy;
                }
                tabdet.GraphVisible = m_appSettings.ShowGraphs;
                tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
                tabdet.Filename = Filename;
                tabdet.Map_name = SymbolName;
                tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
                tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
                tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
                tabdet.Y_axisvalues = GetYaxisValues(tabdet.Map_name);
                string xdescr = string.Empty;
                string ydescr = string.Empty;
                string zdescr = string.Empty;
                GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
                tabdet.X_axis_name = xdescr;
                tabdet.Y_axis_name = ydescr;
                tabdet.Z_axis_name = zdescr;

                //tabdet.Map_sramaddress = GetSymbolAddressSRAM(SymbolName);
                int columns = 8;
                int rows = 8;
                int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                int address = Convert.ToInt32(SymbolAddress);
                if (address != 0)
                {
                    if (address > 0x40000) address -= 0x40000;
                    tabdet.Map_address = address;
                    int length = SymbolLength;
                    tabdet.Map_length = length;
                    byte[] mapdata = readdatafromfile(Filename, address, length);
                    tabdet.Map_content = mapdata;
                    tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
                    tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
                    tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
                    tabdet.ShowTable(columns, isSixteenBitTable(SymbolName));
                    tabdet.Dock = DockStyle.Fill;
                    tabdet.onSymbolSave += new MapViewer.NotifySaveSymbol(tabdet_onSymbolSave);
                    tabdet.onClose += new MapViewer.ViewerClose(tabdet_onClose);
                    tabdet.onAxisLock += new MapViewer.NotifyAxisLock(tabdet_onAxisLock);
                    tabdet.onSliderMove += new MapViewer.NotifySliderMove(tabdet_onSliderMove);
                    tabdet.onSelectionChanged += new MapViewer.SelectionChanged(tabdet_onSelectionChanged);
                    tabdet.onSplitterMoved += new MapViewer.SplitterMoved(tabdet_onSplitterMoved);
                    tabdet.onSurfaceGraphViewChanged += new MapViewer.SurfaceGraphViewChanged(tabdet_onSurfaceGraphViewChanged);
                    tabdet.onGraphSelectionChanged += new MapViewer.GraphSelectionChanged(tabdet_onGraphSelectionChanged);
                    tabdet.onViewTypeChanged += new MapViewer.ViewTypeChanged(tabdet_onViewTypeChanged);

                    dockPanel.Controls.Add(tabdet);
                    //dockPanel.DockAsTab(dockPanel1);
                    dockPanel.Text = "Symbol: " + SymbolName + " [" + Path.GetFileName(Filename) + "]";
                    bool isDocked = false;
                    /*foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                    {
                        if (pnl.Text.StartsWith("Symbol: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                        {
                            dockPanel.DockAsTab(pnl, 0);
                            isDocked = true;
                            break;
                        }
                    }*/
                    if (!isDocked)
                    {
                        dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
                        if (tabdet.X_axisvalues.Length > 0)
                        {
                            dockPanel.Width = 30 + ((tabdet.X_axisvalues.Length + 1) * 35);
                        }
                        else
                        {
                            dockPanel.Width = this.Width - dockSymbols.Width - 10;

                        }
                        if (dockPanel.Width < 400) dockPanel.Width = 400;
                        //                    dockPanel.Width = 400;
                    }
                }
            }

        }

        void tabdet_onGraphSelectionChanged(object sender, MapViewer.GraphSelectionChangedEventArgs e)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        if (c != sender)
                        {
                            MapViewer vwr = (MapViewer)c;
                            if (vwr.Map_name == e.Mapname)
                            {
                                vwr.SetSelectedTabPageIndex(e.Tabpageindex);
                                vwr.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                if (c2 != sender)
                                {
                                    MapViewer vwr2 = (MapViewer)c2;
                                    if (vwr2.Map_name == e.Mapname)
                                    {
                                        vwr2.SetSelectedTabPageIndex(e.Tabpageindex);
                                        vwr2.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                if (c3 != sender)
                                {
                                    MapViewer vwr3 = (MapViewer)c3;
                                    if (vwr3.Map_name == e.Mapname)
                                    {
                                        vwr3.SetSelectedTabPageIndex(e.Tabpageindex);
                                        vwr3.Invalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void StartCompareDifferenceViewer(string SymbolName, string Filename, int SymbolAddress, int SymbolLength)
        {
            DevExpress.XtraBars.Docking.DockPanel dockPanel;
            bool pnlfound = false;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {

                if (pnl.Text == "Symbol difference: " + SymbolName + " [" + Path.GetFileName(Filename) + "]")
                {
                    dockPanel = pnl;
                    pnlfound = true;
                    dockPanel.Show();
                    // nog data verversen?
                    foreach (Control c in dockPanel.Controls)
                    {
                        /* if (c is MapViewer)
                         {
                             MapViewer tempviewer = (MapViewer)c;
                             tempviewer.Map_content
                         }*/
                    }
                }
            }
            if (!pnlfound)
            {
                dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                MapViewer tabdet = new MapViewer();
                //tabdet.IsHexMode = true; // always in hexmode!
                tabdet.Viewtype = ViewType.Hexadecimal;
                tabdet.GraphVisible = m_appSettings.ShowGraphs;
                tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
                tabdet.Filename = Filename;
                tabdet.Map_name = SymbolName;
                tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
                tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
                tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
                tabdet.Y_axisvalues = GetYaxisValues(tabdet.Map_name);
                string xdescr = string.Empty;
                string ydescr = string.Empty;
                string zdescr = string.Empty;
                GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
                tabdet.X_axis_name = xdescr;
                tabdet.Y_axis_name = ydescr;
                tabdet.Z_axis_name = zdescr;

                //tabdet.Map_sramaddress = GetSymbolAddressSRAM(SymbolName);
                int columns = 8;
                int rows = 8;
                int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                int address = Convert.ToInt32(SymbolAddress);
                if (address != 0)
                {
                    if (address > 0x40000) address -= 0x40000;
                    tabdet.Map_address = address;
                    int length = SymbolLength;
                    tabdet.Map_length = length;
                    byte[] mapdata = readdatafromfile(Filename, address, length);
                    byte[] mapdata2 = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols,SymbolName), GetSymbolLength(m_symbols, SymbolName));
                    if (mapdata.Length == mapdata2.Length)
                    {
                        if (isSixteenBitTable(SymbolName))
                        {
                            for (int bt = 0; bt < mapdata2.Length; bt+=2)
                            {
                                int value1 = Convert.ToInt16(mapdata.GetValue(bt)) * 256 + Convert.ToInt16(mapdata.GetValue(bt+1));
                                int value2 =  Convert.ToInt16(mapdata2.GetValue(bt)) * 256 +  Convert.ToInt16(mapdata2.GetValue(bt + 1));

                                value1 = (int)Math.Abs(value1-value2);
                                byte v1 = (byte)(value1/256);
                                byte v2 = (byte)(value1 - (int)v1 * 256);
                                mapdata.SetValue(v1, bt);
                                mapdata.SetValue(v2, bt+1);
                            }
                        }
                        else
                        {
                            for (int bt = 0; bt < mapdata2.Length; bt++)
                            {
                                Console.WriteLine("Byte diff: " + mapdata.GetValue(bt).ToString() + " - " + mapdata2.GetValue(bt).ToString() + " = " + (byte)Math.Abs(((byte)mapdata.GetValue(bt) - (byte)mapdata2.GetValue(bt))));
                                mapdata.SetValue((byte)Math.Abs(((byte)mapdata.GetValue(bt) - (byte)mapdata2.GetValue(bt))), bt);
                            }
                        }

                        tabdet.Map_content = mapdata;
                        tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
                        tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
                        tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
                        tabdet.ShowTable(columns, isSixteenBitTable(SymbolName));
                        tabdet.Dock = DockStyle.Fill;
                        tabdet.onSymbolSave += new MapViewer.NotifySaveSymbol(tabdet_onSymbolSave);
                        tabdet.onClose += new MapViewer.ViewerClose(tabdet_onClose);
                        tabdet.onAxisLock += new MapViewer.NotifyAxisLock(tabdet_onAxisLock);
                        tabdet.onSliderMove += new MapViewer.NotifySliderMove(tabdet_onSliderMove);
                        tabdet.onSelectionChanged += new MapViewer.SelectionChanged(tabdet_onSelectionChanged);
                        tabdet.onSplitterMoved += new MapViewer.SplitterMoved(tabdet_onSplitterMoved);
                        tabdet.onSurfaceGraphViewChanged += new MapViewer.SurfaceGraphViewChanged(tabdet_onSurfaceGraphViewChanged);
                        tabdet.onGraphSelectionChanged += new MapViewer.GraphSelectionChanged(tabdet_onGraphSelectionChanged);
                        tabdet.onViewTypeChanged += new MapViewer.ViewTypeChanged(tabdet_onViewTypeChanged);


                        dockPanel.Controls.Add(tabdet);
                        //dockPanel.DockAsTab(dockPanel1);
                        dockPanel.Text = "Symbol difference: " + SymbolName + " [" + Path.GetFileName(Filename) + "]";
                        bool isDocked = false;
                        foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                        {
                            if (pnl.Text.StartsWith("Symbol difference: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                            {
                                dockPanel.DockAsTab(pnl, 0);
                                isDocked = true;
                                break;
                            }
                        }
                        if (!isDocked)
                        {
                            dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
                            if (tabdet.X_axisvalues.Length > 0)
                            {
                                dockPanel.Width = 30 + ((tabdet.X_axisvalues.Length + 1) * 35);
                            }
                            else
                            {
                                dockPanel.Width = this.Width - dockSymbols.Width - 10;

                            }
                            if (dockPanel.Width < 400) dockPanel.Width = 400;

                            //                    dockPanel.Width = 400;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Map lengths don't match...");
                    }
                }
            }

        }


        void tabdet_onSymbolSelect(object sender, CompareResults.SelectSymbolEventArgs e)
        {
            if (!e.ShowDiffMap)
            {
                StartTableViewer(e.SymbolName);
                StartCompareMapViewer(e.SymbolName, e.Filename, e.SymbolAddress, e.SymbolLength);
            }
            else
            {
                StartCompareDifferenceViewer(e.SymbolName, e.Filename, e.SymbolAddress, e.SymbolLength);
            }
        }

  

        private void gridViewSymbols_CustomDrawCell(object sender, DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs e)
        {
            if (e.Column.Name == gcSymbolsChanged.Name)
            {
                if (e.CellValue != null)
                {
                    if (e.CellValue != DBNull.Value)
                    {
                        if (Convert.ToBoolean(e.CellValue) == true)
                        {
                            e.Graphics.FillRectangle(Brushes.Orange, e.Bounds);
                        }
                    }
                }
            }
            else if (e.Column.Name == gcSymbolsName.Name)
            {
                object o = gridViewSymbols.GetRowCellValue(e.RowHandle, "CATEGORY");
                Color c = Color.White;
                if (o != DBNull.Value)
                {
                    if (Convert.ToInt32(o) == (int)XDFCategories.Fuel)
                    {
                        c = Color.LightSteelBlue;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Ignition)
                    {
                        c = Color.LightGreen;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Turbo)
                    {
                        c = Color.OrangeRed;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Misc)
                    {
                        c = Color.LightGray;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Sensor)
                    {
                        c = Color.Yellow;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Correction)
                    {
                        c = Color.LightPink;
                    }
                    else if (Convert.ToInt32(o) == (int)XDFCategories.Idle)
                    {
                        c = Color.BurlyWood;
                    }
                }
                if (c != Color.White)
                {
                    System.Drawing.Drawing2D.LinearGradientBrush gb = new System.Drawing.Drawing2D.LinearGradientBrush(e.Bounds, c, Color.White, System.Drawing.Drawing2D.LinearGradientMode.Horizontal);
                    e.Graphics.FillRectangle(gb, e.Bounds);
                }

            }
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //review all open editors and save the data still pending
            bool _datasaved = false;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        if (vwr.SaveData()) _datasaved = true;
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                if (vwr2.SaveData()) _datasaved = true;
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                if (vwr3.SaveData()) _datasaved = true;
                            }
                        }
                    }
                }
            }
            if (_datasaved)
            {
                MessageBox.Show("All pending changes saved to binary");
            }
            else
            {
                MessageBox.Show("Binary was already up to date!");
            }

        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            saveFileDialog1.CheckFileExists = false;
            saveFileDialog1.CheckPathExists = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File.Copy(m_currentfile, saveFileDialog1.FileName, true);
                if (MessageBox.Show("Do you want to open the newly saved file?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    OpenFile(saveFileDialog1.FileName);
                }
            }
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gridSymbols.DataSource != null)
            {
                XDFWriter xdf = new XDFWriter();
                string filename = System.Windows.Forms.Application.StartupPath + "\\" + Path.GetFileNameWithoutExtension(m_currentfile);
                saveFileDialog2.FileName = filename;
                if (saveFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    //filename += ".xdf";
                    filename = saveFileDialog2.FileName;

                    xdf.CreateXDF(filename, m_currentfile, getendofdataindexEx());
                    foreach (SymbolHelper sh in m_symbols)
                    {
                        if (sh.Flash_start_address != 0)
                        {
                            if (sh.Varname == "Pgm_mod!") // VSS vlag
                            {
                                xdf.AddFlag("VSS", sh.Flash_start_address, 0x07);
                            }

                            else if (varIsTable(sh.Varname))
                            {
                                string xaxis = "x-axis";
                                string yaxis = "y-axis";
                                string zaxis = "z-axis";
                                GetAxisDescriptions(sh.Varname, out xaxis, out yaxis, out zaxis);
                                bool m_issixteenbit = isSixteenBitTable(sh.Varname);
                                // special maps are:
                                int xaxisaddress = 0;
                                int yaxisaddress = 0;
                                bool isxaxissixteenbit = false;
                                bool isyaxissixteenbit = false;
                                GetXYAxisAddresses(sh.Varname, out xaxisaddress, out yaxisaddress, out isxaxissixteenbit, out isyaxissixteenbit);
                                int columns = 8;
                                int rows = 8;
                                int tablewidth = GetTableMatrixWitdhByName(sh.Varname, out columns, out rows);
                                xdf.AddTable(sh.Varname, TranslateSymbolName(sh.Varname), XDFCategories.Fuel, xaxis, yaxis, zaxis, rows, columns, sh.Flash_start_address - 0x40000, m_issixteenbit, xaxisaddress, yaxisaddress, isxaxissixteenbit, isyaxissixteenbit, 1.0F, 1.0F, 1.0F);
                                if (sh.Varname.StartsWith("Ign_map_0!") || sh.Varname.StartsWith("Insp_mat!") || sh.Varname.StartsWith("Fuel_knock_mat!"))
                                {
                                    xdf.AddTable(sh.Varname + " (3bar)", TranslateSymbolName(sh.Varname) + " (3bar)", XDFCategories.Fuel, xaxis, yaxis, zaxis, rows, columns, sh.Flash_start_address - 0x40000, m_issixteenbit, xaxisaddress, yaxisaddress, isxaxissixteenbit, isyaxissixteenbit, 1.2F, 1, 1);
                                }
                                else if (sh.Varname.StartsWith("Tryck_mat!"))
                                {
                                    xdf.AddTable(sh.Varname + " (3bar)", TranslateSymbolName(sh.Varname) + " (3bar)", XDFCategories.Fuel, xaxis, yaxis, zaxis, rows, columns, sh.Flash_start_address - 0x40000, m_issixteenbit, xaxisaddress, yaxisaddress, isxaxissixteenbit, isyaxissixteenbit, 1, 1, 1.2F);
                                }

                            }
                            else
                            {
                                bool m_issixteenbit = isSixteenBitTable(sh.Varname);
                                xdf.AddConstant(55, sh.Varname, XDFCategories.Idle, "Aantal", sh.Length, sh.Flash_start_address - 0x40000, m_issixteenbit);
                            }
                        }
                    }
                    // add some specific stuff
                    xdf.AddTable("Vehice Security Code", "VSS code", XDFCategories.Idle, "", "", "", 1, 6, 0x3FFB4, false, 0, 0, false, false, 1.0F, 1.0F, 1.0F);

                    xdf.CloseFile();
                }
            }

        }

        private void barButtonItem7_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem8_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (m_currentfile != string.Empty)
            {
                if (!verifychecksum())
                {
                    if (m_appSettings.AutoChecksum)
                    {
                        updatechecksum();
                        if (m_fileiss19)
                        {
                            // automatisch terugschrijven
                            srec2bin cnvrt = new srec2bin();
                            cnvrt.ConvertBinToSrec(m_currentfile);
                        }
                    }
                    else if (MessageBox.Show("Checksum invalid, auto correct?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        updatechecksum();
                        if (m_fileiss19)
                        {
                            // automatisch terugschrijven
                            srec2bin cnvrt = new srec2bin();
                            cnvrt.ConvertBinToSrec(m_currentfile);
                        }

                    }
                }

                if (File.Exists(m_currentfile))
                {
                    File.Copy(m_currentfile, Path.GetDirectoryName(m_currentfile) + "\\" + Path.GetFileNameWithoutExtension(m_currentfile) + DateTime.Now.ToString("yyyyMMddHHmmss") + ".binarybackup", true);
                    MessageBox.Show("Backup created: " + Path.GetDirectoryName(m_currentfile) + "\\" + Path.GetFileNameWithoutExtension(m_currentfile) + DateTime.Now.ToString("yyyyMMddHHmmss") + ".binarybackup");
                }
            }
        }

        private void barButtonItem18_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // toggle VSS
        }

        private void barButtonItem16_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            MessageBox.Show("Boxnumber: " + readpartnumber());
        }

        private void barButtonItem11_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem12_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // show dialog box which asks for 2 binaries 128kB in size to  be merged to 1 file
            frmBinmerger frmmerger = new frmBinmerger();
            frmmerger.ShowDialog();
        }

        private void barButtonItem13_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (m_currentfile != "")
            {
                if (File.Exists(m_currentfile))
                {
                    string path = Path.GetDirectoryName(m_currentfile);
                    FileInfo fi = new FileInfo(m_currentfile);
                    FileStream fs = File.Create(path + "\\chip2.bin");
                    BinaryWriter bw = new BinaryWriter(fs);
                    FileStream fs2 = File.Create(path + "\\chip1.bin");
                    BinaryWriter bw2 = new BinaryWriter(fs2);
                    FileStream fsi1 = File.OpenRead(m_currentfile);
                    BinaryReader br1 = new BinaryReader(fsi1);
                    bool toggle = false;
                    for (int tel = 0; tel < fi.Length; tel++)
                    {
                        Byte ib1 = br1.ReadByte();
                        if (!toggle)
                        {
                            toggle = true;
                            bw.Write(ib1);
                        }
                        else
                        {
                            toggle = false;
                            bw2.Write(ib1);
                        }

                        //Byte ib2 = br2.ReadByte();
                        //bw.Write(ib2);
                        //bw.Write(ib1);
                    }

                    bw.Close();
                    bw2.Close();
                    fs.Close();
                    fs2.Close();
                    fsi1.Close();
                    br1.Close();
                    //fsi2.Close();
                    //br2.Close();
                    MessageBox.Show("File split to chip1.bin and chip2.bin");
                }
            }

        }

        private void CreateRepositoryItem(string filename, SymbolCollection curSymbolCollection)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("SYMBOLNAME");
            dt.Columns.Add("SRAMADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("FLASHADDRESS", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHBYTES", Type.GetType("System.Int32"));
            dt.Columns.Add("LENGTHVALUES", Type.GetType("System.Int32"));
            dt.Columns.Add("DESCRIPTION");
            dt.Columns.Add("ISCHANGED", Type.GetType("System.Boolean"));
            dt.Columns.Add("CATEGORY", Type.GetType("System.Int32"));

            foreach (SymbolHelper sh in curSymbolCollection)
            {
                dt.Rows.Add(sh.Varname, sh.Start_address, sh.Flash_start_address, sh.Length, sh.Length, TranslateSymbolName(sh.Varname), false, (int)TranslateSymbolNameToCategory(sh.Varname));
            }
            dt.TableName = Path.GetFileNameWithoutExtension(filename);
            DateTime cdt = File.GetCreationTime(filename);
            if (!Directory.Exists(System.Windows.Forms.Application.StartupPath + "\\repository"))
            {
                Directory.CreateDirectory(System.Windows.Forms.Application.StartupPath + "\\repository");
            }
            dt.WriteXml(System.Windows.Forms.Application.StartupPath + "\\repository\\" + Path.GetFileNameWithoutExtension(filename) + cdt.ToString("yyyyMMddHHmmss") + ".xml");
        }



        private void CreateRepositoryItem()
        {
            if (gridSymbols.DataSource != null && m_currentfile != string.Empty)
            {
                System.Data.DataTable dt = (System.Data.DataTable)gridSymbols.DataSource;
                dt.TableName = Path.GetFileNameWithoutExtension(m_currentfile);
                DateTime cdt = File.GetCreationTime(m_currentfile);
                if (!Directory.Exists(System.Windows.Forms.Application.StartupPath + "\\repository"))
                {
                    Directory.CreateDirectory(System.Windows.Forms.Application.StartupPath + "\\repository");
                }
                dt.WriteXml(System.Windows.Forms.Application.StartupPath + "\\repository\\" + Path.GetFileNameWithoutExtension(m_currentfile) + cdt.ToString("yyyyMMddHHmmss") + ".xml");
            }

        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_appSettings.Lastfilename = m_currentfile;
            m_appSettings.AutoExtractSymbols = true;
            m_appSettings.Viewinhex = barViewInHex.Checked;
            m_appSettings.SaveSettings();
            SaveMRUList();
            CreateRepositoryItem();
            SaveLayoutFiles();
        }

        private void SaveLayoutFiles()
        {
            gridViewSymbols.SaveLayoutToXml(System.Windows.Forms.Application.StartupPath + "\\SymbolViewLayout.xml");
        }

        private void LoadLayoutFiles()
        {
            if (File.Exists(System.Windows.Forms.Application.StartupPath + "\\SymbolViewLayout.xml"))
            {
                try
                {
                    gridViewSymbols.RestoreLayoutFromXml(System.Windows.Forms.Application.StartupPath + "\\SymbolViewLayout.xml");
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }
        }

        private void barButtonItem31_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmPeMicroParameters frmpe = new frmPeMicroParameters();
            frmpe.ECUReadFile = m_appSettings.Read_ecubatchfile;
            frmpe.ECUWriteFile = m_appSettings.Write_ecubatchfile;
            frmpe.TargetECUReadFile = m_appSettings.TargetECUReadFile;
            if (frmpe.ShowDialog() == DialogResult.OK)
            {
                m_appSettings.Read_ecubatchfile = frmpe.ECUReadFile;
                m_appSettings.Write_ecubatchfile = frmpe.ECUWriteFile;
                m_appSettings.TargetECUReadFile = frmpe.TargetECUReadFile;
            }
        }

        private void barButtonItem32_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // write the required file for flashing the ECU
            // this is the current file, exported to S19 format in the directory that contains
            // the selected batchfile
            if (m_appSettings.Write_ecubatchfile != string.Empty)
            {
                try
                {
                    if (File.Exists(m_appSettings.Write_ecubatchfile))
                    {
                        if (!verifychecksum())
                        {
                            if (m_appSettings.AutoChecksum)
                            {
                                updatechecksum();
                                if (m_fileiss19)
                                {
                                    // automatisch terugschrijven
                                    srec2bin cnvrt = new srec2bin();
                                    cnvrt.ConvertBinToSrec(m_currentfile);
                                }

                            }
                            else if (MessageBox.Show("Checksum invalid, auto correct?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                updatechecksum();
                                if (m_fileiss19)
                                {
                                    // automatisch terugschrijven
                                    srec2bin cnvrt = new srec2bin();
                                    cnvrt.ConvertBinToSrec(m_currentfile);
                                }
                            }
                        }

                        srec2bin sr = new srec2bin();
                        sr.ConvertBinToSrec(m_currentfile);
                        // and copy it to the target directory
                        string fromfile = Path.GetDirectoryName(m_currentfile) + "\\" + Path.GetFileNameWithoutExtension(m_currentfile) + ".S19";
                        string destfile = Path.GetDirectoryName(m_appSettings.Write_ecubatchfile) + "\\TO_ECU.S19";
                        File.Copy(fromfile, destfile, true);
                        System.Diagnostics.Process.Start(m_appSettings.Write_ecubatchfile);
                    }
                    else
                    {
                        MessageBox.Show("Batch file not found. Check parameters");
                    }
                }
                catch (Exception E)
                {
                    MessageBox.Show(E.Message);
                }
            }
        }

        private void barButtonItem33_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (m_appSettings.Read_ecubatchfile != string.Empty)
            {
                try
                {
                    if (File.Exists(m_appSettings.Read_ecubatchfile))
                    {
                        System.Diagnostics.Process process = new System.Diagnostics.Process();
                        process.StartInfo = new System.Diagnostics.ProcessStartInfo(m_appSettings.Read_ecubatchfile);
                        process.Start();
                        process.WaitForExit();
                        // now, import the resulting S19 file
                        string fromfile = Path.GetDirectoryName(m_appSettings.Read_ecubatchfile) + "\\FROM_ECU.S19";
                        string destfile = Path.GetDirectoryName(m_currentfile) + "\\FROM_ECU" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".S19";
                        File.Copy(fromfile, destfile, true);
                        if (m_appSettings.TargetECUReadFile != string.Empty)
                        {
                            File.Copy(fromfile, m_appSettings.TargetECUReadFile, true);
                            OpenFile(m_appSettings.TargetECUReadFile);
                        }
                        else
                        {
                            OpenFile(destfile);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Batch file not found. Check parameters");
                    }
                }
                catch (Exception E)
                {
                    MessageBox.Show(E.Message);
                }
            }
        }

        private void barViewInHex_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            m_appSettings.Viewinhex = barViewInHex.Checked;
            // alle andere schermen aanpassen
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        if (m_appSettings.Viewinhex)
                        {
                            vwr.Viewtype = ViewType.Hexadecimal;
                        }
                        else
                        {
                            vwr.Viewtype = ViewType.Easy;
                        }
                        //vwr.IsHexMode = m_appSettings.Viewinhex;
                        vwr.ReShowTable();
                        vwr.Invalidate();
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                //vwr2.IsHexMode = m_appSettings.Viewinhex;
                                if (m_appSettings.Viewinhex)
                                {
                                    vwr2.Viewtype = ViewType.Hexadecimal;
                                }
                                else
                                {
                                    vwr2.Viewtype = ViewType.Easy;
                                }
                                vwr2.ReShowTable();
                                vwr2.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                //vwr3.IsHexMode = m_appSettings.Viewinhex;
                                if (m_appSettings.Viewinhex)
                                {
                                    vwr3.Viewtype = ViewType.Hexadecimal;
                                }
                                else
                                {
                                    vwr3.Viewtype = ViewType.Easy;
                                }
                                vwr3.ReShowTable();
                                vwr3.Invalidate();
                            }
                        }
                    }
                }
            }

        }

        private void barOnlyRed_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            m_appSettings.ShowRedWhite = barOnlyRed.Checked;
            // alle andere schermen aanpassen
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is MapViewer)
                    {
                        MapViewer vwr = (MapViewer)c;
                        vwr.IsRedWhite = m_appSettings.ShowRedWhite;
                        vwr.ReShowTable();
                        vwr.Invalidate();
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is MapViewer)
                            {
                                MapViewer vwr2 = (MapViewer)c2;
                                vwr2.IsRedWhite = m_appSettings.ShowRedWhite;
                                vwr2.ReShowTable();
                                vwr2.Invalidate();
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is MapViewer)
                            {
                                MapViewer vwr3 = (MapViewer)c3;
                                vwr3.IsRedWhite = m_appSettings.ShowRedWhite;
                                vwr3.ReShowTable();
                                vwr3.Invalidate();
                            }
                        }
                    }
                }
            }

        }

        private System.Data.DataTable getDataFromXLS(string strFilePath)
        {
            try
            {
                string strConnectionString = string.Empty;
                strConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilePath + @";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""";
                //MessageBox.Show(strConnectionString);
                OleDbConnection cnCSV = new OleDbConnection(strConnectionString);
                cnCSV.Open();
                OleDbCommand cmdSelect = new OleDbCommand(@"SELECT * FROM [symboldata$]", cnCSV);
                OleDbDataAdapter daCSV = new OleDbDataAdapter();
                daCSV.SelectCommand = cmdSelect;
                System.Data.DataTable dtCSV = new System.Data.DataTable();
                daCSV.Fill(dtCSV);
                cnCSV.Close();
                daCSV = null;
                return dtCSV;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                return null;
            }
            finally { }
        }

        private void ImportExcelSymbol(string symbolname, string filename)
        {
            bool issixteenbit = false;
            System.Data.DataTable dt = getDataFromXLS(openFileDialog2.FileName);
            if (isSixteenBitTable(symbolname)) issixteenbit = true;
            int symbollength = GetSymbolLength(m_symbols,symbolname);
            int datalength = symbollength;
            if(issixteenbit) datalength /= 2;
            int[] buffer = new int[datalength];
            int bcount = 0;
            for(int rtel = 1; rtel < dt.Rows.Count; rtel ++)
            {
                try
                {
                    int idx = 0;
                    foreach (object o in dt.Rows[rtel].ItemArray)
                    {
                        if (idx > 0)
                        {
                            if (o != null)
                            {
                                if (o != DBNull.Value)
                                {
                                    if (bcount < buffer.Length)
                                    {
                                        buffer.SetValue(Convert.ToInt32(o), bcount++);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Too much information in file, abort");
                                        return;
                                    }
                                }
                            }
                        }
                        idx++;
                    }
                }
                catch (Exception E)
                {
                    Console.WriteLine("ImportExcelSymbol: " + E.Message);
                }
                
            }
            if (bcount >= symbollength)
            {
                byte[] data = new byte[symbollength];
                int cellcount = 0;
                if (issixteenbit)
                {
                    for (int dcnt = 0; dcnt < buffer.Length; dcnt++)
                    {
                        string bstr1 = "0";
                        string bstr2 = "0";
                        int cellvalue = Convert.ToInt32(buffer.GetValue(dcnt));
                        bstr1 = cellvalue.ToString("X4").Substring(0, 2);
                        bstr2 = cellvalue.ToString("X4").Substring(2, 2);
                        data.SetValue(Convert.ToByte(bstr1, 16), cellcount++);
                        data.SetValue(Convert.ToByte(bstr2, 16), cellcount++);
                    }
                }
                else
                {
                    for (int dcnt = 0; dcnt < buffer.Length; dcnt++)
                    {
                        int cellvalue = Convert.ToInt32(buffer.GetValue(dcnt));
                        data.SetValue(Convert.ToByte(cellvalue.ToString()), cellcount++);
                    }
                }
                savedatatobinary(GetSymbolAddress(m_symbols, symbolname), symbollength, data, m_currentfile);
                
            }

        }


        private void barButtonItem34_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string mapname = string.Empty;
                    int tildeindex = openFileDialog2.FileName.LastIndexOf("~");
                    bool symbolfound = false;
                    if (tildeindex > 0)
                    {
                        tildeindex++;
                        mapname = openFileDialog2.FileName.Substring(tildeindex, openFileDialog2.FileName.Length - tildeindex);
                        mapname = mapname.Replace(".xls", "");
                        mapname = mapname.Replace(".XLS", "");
                        mapname = mapname.Replace(".Xls", "");
                        // look if it is a valid symbolname
                        foreach (SymbolHelper sh in m_symbols)
                        {
                            if (sh.Varname == mapname)
                            {
                                symbolfound = true;
                                if (MessageBox.Show("Found valid symbol for import: " + mapname + ". Are you sure you want to overwrite the map in the binary?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    // ok, overwrite info in binary
                                }
                                else
                                {
                                    mapname = string.Empty; // do nothing
                                }
                            }
                        }
                        if (!symbolfound)
                        {
                            // ask user for symbol designation
                            frmSymbolSelect frmselect = new frmSymbolSelect(m_symbols);
                            if(frmselect.ShowDialog() == DialogResult.OK)
                            {
                                mapname = frmselect.SelectedSymbol;
                            }
                        }
                     
                    }
                    else
                    {
                        // ask user for symbol designation
                            frmSymbolSelect frmselect = new frmSymbolSelect(m_symbols);
                            if(frmselect.ShowDialog() == DialogResult.OK)
                            {
                                mapname = frmselect.SelectedSymbol;
                            }

                    }
                    if(mapname != string.Empty)
                    {
                        ImportExcelSymbol(mapname, openFileDialog2.FileName);
                    }
                    
                }
                catch (Exception E)
                {
                    MessageBox.Show("Failed to import map from excel: " + E.Message);
                }
            }
        }

        private void checkVSSEnable_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (!from_prog_change)
            {

                foreach (SymbolHelper sh in m_symbols)
                {
                    if (sh.Varname == "Pgm_mod!")
                    {
                        if (sh.Length == 6)
                        {


                            byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                            byte sign = Convert.ToByte(vssdata.GetValue(5));
                            if (checkVSSEnable.Checked)
                            {
                                sign |= 0x80; // set vss flag
                            }
                            else
                            {
                                sign &= 0x7F; // clear vss flag
                            }
                            vssdata.SetValue(sign, 5);
                            savedatatobinary(sh.Flash_start_address - 0x40000, sh.Length, vssdata, m_currentfile);
                        }
                        else
                        {
                            MessageBox.Show("VSS symbol had incorrect length: " + sh.Length.ToString() + ", unable to apply settings!");
                        }
                    }
                }
            }
            else
            {
                from_prog_change = false;
            }
        }

        private void panelContainer1_Click(object sender, EventArgs e)
        {

        }

        private void gridViewSymbols_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                StartTableViewer();
                e.Handled = true;
            }
            
        }

        private void SetTuningMenuEnabled(bool enabled)
        {
            barButtonItem15.Enabled = enabled;
            barButtonItem17.Enabled = enabled;
            barButtonItem30.Enabled = enabled;
            barButtonItem45.Enabled = enabled;
            barButtonItem27.Enabled = enabled;
            barButtonItem19.Enabled = enabled;
            barButtonItem28.Enabled = enabled;
            barButtonItem29.Enabled = enabled;
            barButtonItem38.Enabled = enabled;
            barButtonItem40.Enabled = enabled;
            barButtonItem35.Enabled = enabled;
            barButtonItem36.Enabled = enabled;
            barButtonItem37.Enabled = enabled;
            barButtonItem41.Enabled = enabled;
            barButtonItem42.Enabled = enabled;
            barButtonItem43.Enabled = enabled;
            barButtonItem39.Enabled = enabled;
            barButtonItem46.Enabled = enabled;
        }

        private System.Data.DataTable getDataFromXLSSymbolHelper(string strFilePath)
        {
            try
            {
                string strConnectionString = string.Empty;
                strConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilePath + @";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""";
                OleDbConnection cnCSV = new OleDbConnection(strConnectionString);
                cnCSV.Open();
                OleDbCommand cmdSelect = new OleDbCommand(@"SELECT * FROM [Symbols$]", cnCSV);
                OleDbDataAdapter daCSV = new OleDbDataAdapter();
                daCSV.SelectCommand = cmdSelect;
                System.Data.DataTable dtCSV = new System.Data.DataTable();
                daCSV.Fill(dtCSV);
                cnCSV.Close();
                daCSV = null;
                return dtCSV;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            finally { }
        }


        private void InitSymbolHelperSystem()
        {
            if (File.Exists(System.Windows.Forms.Application.StartupPath + "\\T5Symbols_ImportList.xls"))
            {
                _symbolnameHelper = getDataFromXLSSymbolHelper(System.Windows.Forms.Application.StartupPath + "\\T5Symbols_ImportList.xls");
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            ribbonControl1.SelectedPage = ribbonPageFile;
            this.WindowState = FormWindowState.Maximized;
            SetTuningMenuEnabled(false);
            // set barViewInHex status
            //barViewInHex.Checked = m_appSettings.Viewinhex;
            // load last known file
            LoadLayoutFiles();
            SetDefaultFilters();
            barViewInHex.Checked = m_appSettings.Viewinhex;
            barOnlyRed.Checked = m_appSettings.ShowRedWhite;
            barAutoChecksum.Checked = m_appSettings.AutoChecksum;
            barShowGraphs.Checked = m_appSettings.ShowGraphs;
            barCheckSymbolWindow.Checked = m_appSettings.HideSymbolTable;
            System.Windows.Forms.Application.DoEvents();
            InitMruSystem();

            InitSymbolHelperSystem();


            if (m_appSettings.Lastfilename != "")
            {
                if (File.Exists(m_appSettings.Lastfilename))
                {
                    TryToLoadFile(m_appSettings.Lastfilename);
                    if (verifychecksum()) barButtonItem20.ImageIndex = 3;
                    else barButtonItem20.ImageIndex = 2;
                }
            }
            if (m_appSettings.DebugMode)
            {
                ribbonPage3.Visible = true;
                barButtonItem48.Enabled = true;
                barButtonItem49.Enabled = true;
                barButtonItem50.Enabled = true;
            }
        }

        private void StartGraphViewer()
        {
            if (gridViewSymbols.SelectedRowsCount > 0)
            {
                int[] selrows = gridViewSymbols.GetSelectedRows();
                if (selrows.Length > 0)
                {
                    DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                    DevExpress.XtraBars.Docking.DockPanel dockPanel;
                    bool pnlfound = false;
                    foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                    {
                        if (pnl.Text == "Graph: " + dr.Row["SYMBOLNAME"].ToString() + " [" + Path.GetFileName(m_currentfile) + "]")
                        {
                            dockPanel = pnl;
                            pnlfound = true;
                            dockPanel.Show();
                            // nog data verversen?
                            foreach (Control c in dockPanel.Controls)
                            {
                                /* if (c is MapViewer)
                                 {
                                     MapViewer tempviewer = (MapViewer)c;
                                     tempviewer.Map_content
                                 }*/
                            }
                        }
                    }

                    if (!pnlfound)
                    {
                        dockPanel = dockManager1.AddPanel(new System.Drawing.Point(-500, -500));
                        SurfaceGraphViewer tabdet = new SurfaceGraphViewer();
                        
                        //sv.Filename = m_currentfile;
                        //tabdet.IsHexMode = barViewInHex.Checked;
                        //tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
                        tabdet.Map_name = dr.Row["SYMBOLNAME"].ToString();
                        tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name); ;
                        //tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
                        //tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
                        //tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
                        tabdet.X_axis = GetXaxisValues(tabdet.Map_name);
                        tabdet.Y_axis = GetYaxisValues(tabdet.Map_name);
                        // z, y and z axis to do
                        string xdescr = string.Empty;
                        string ydescr = string.Empty;
                        string zdescr = string.Empty;
                        GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
                        tabdet.X_axis_descr = xdescr;
                        tabdet.Y_axis_descr = ydescr;
                        tabdet.Z_axis_descr = zdescr;
                        int columns = 8;
                        int rows = 8;
                        int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
                        int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                        int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"].ToString());
                        if (address != 0)
                        {
                            if (address > 0x40000) address -= 0x40000;
                            //tabdet.Map_address = address;
                            //tabdet.Map_sramaddress = sramaddress;
                            int length = Convert.ToInt32(dr.Row["LENGTHBYTES"].ToString());
                            tabdet.Map_length = length;
                            byte[] mapdata = readdatafromfile(m_currentfile, address, length);
                            tabdet.NumberOfColumns = tablewidth;
                            tabdet.IsSixteenbit = isSixteenBitTable(tabdet.Map_name);
                            tabdet.Map_content = mapdata;
                            
                            tabdet.NormalizeData();
                            
                            //tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
                            //tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
                            //tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
                            //tabdet.ShowTable(columns, isSixteenBitTable(tabdet.Map_name));
                            tabdet.Dock = DockStyle.Fill;
                            //tabdet.onSymbolSave += new MapViewer.NotifySaveSymbol(tabdet_onSymbolSave);
                            //tabdet.onClose += new MapViewer.ViewerClose(tabdet_onClose);
                            dockPanel.Controls.Add(tabdet);
                            //dockPanel.DockAsTab(dockPanel1);
                            dockPanel.Text = "Graph: " + tabdet.Map_name + " [" + Path.GetFileName(m_currentfile) + "]";
                            bool isDocked = false;
                            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                            {
                                if (pnl.Text.StartsWith("Graph: ") && pnl != dockPanel && (pnl.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible))
                                {
                                    dockPanel.DockAsTab(pnl, 0);
                                    isDocked = true;
                                    break;
                                }
                            }
                            if (!isDocked)
                            {
                                dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
                                /*if (tabdet.X_axisvalues.Length > 0)
                                {
                                    dockPanel.Width = 30 + ((tabdet.X_axisvalues.Length + 1) * 35);
                                }
                                else
                                {*/
                                dockPanel.Width = this.Width - dockSymbols.Width - 10;

                                //                            }

                            }

                        }
                    }
                }
            }

        }


        private void barShowGraph_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartGraphViewer();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            gridViewSymbols.ExportToXls(System.Windows.Forms.Application.StartupPath + "\\SymbolList.xls");
            MessageBox.Show("List saved to : " + System.Windows.Forms.Application.StartupPath + "\\SymbolList.xls");
        }

        private void mnuShowTable_Click(object sender, EventArgs e)
        {
            StartTableViewer();
        }

        private void mnuExportExcel_Click(object sender, EventArgs e)
        {
            StartExcelExport();
        }

        private void mnuShowGraph_Click(object sender, EventArgs e)
        {
            StartGraphViewer();
        }

        private void barAutoChecksum_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            m_appSettings.AutoChecksum = barAutoChecksum.Checked;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            gridViewSymbols.ColumnsCustomization();
        }

        private void OpenSRAMFile(string filename)
        {
            // opens the sram dump file and displays the maps inside the dump file
            // after verifying that this ramdump matches the selected binary.
            // this can result in a compare between flash maps and the sram map values
            m_currentsramfile = filename;
            barStaticItem3.Caption = "SRAM file: " + Path.GetFileName(m_currentsramfile);

        }

        private void barSRAMDumpImport_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //openFileDialog3.FileName = Path.GetFileNameWithoutExtension(m_currentfile) + ".RAM";
            if (openFileDialog3.ShowDialog() == DialogResult.OK)
            {
                if(File.Exists(openFileDialog3.FileName))
                {
                    OpenSRAMFile(openFileDialog3.FileName);
                }
            }
        }

        private void mnuSymbols_Opening(object sender, CancelEventArgs e)
        {
            showSRAMMapToolStripMenuItem.Enabled = false;
            if (m_currentsramfile != string.Empty)
            {
                if (gridViewSymbols.SelectedRowsCount > 0)
                {
                    int[] selrows = gridViewSymbols.GetSelectedRows();
                    if (selrows.Length > 0)
                    {
                        DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                        if (dr.Row["SRAMADDRESS"] != DBNull.Value)
                        {
                            int sramaddress = 0;
                            try
                            {
                                sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"]);
                                if (sramaddress > 0)
                                {
                                    showSRAMMapToolStripMenuItem.Enabled = true;
                                }
                            }
                            catch (Exception E)
                            {
                                Console.WriteLine(E.Message);
                            }
                        }

                    }
                }
            }

        }

        private bool HexViewerActive(bool ShowIfActive)
        {
            bool retval = false;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                if (pnl.Text.StartsWith("Hexviewer: " + Path.GetFileName(m_currentfile)))
                {
                    retval = true;
                    if (ShowIfActive)
                    {
                        pnl.Show();
                        dockManager1.ActivePanel = pnl;
                    }
                }
                else
                {
                    foreach (Control c in pnl.Controls)
                    {
                        if (c is DevExpress.XtraBars.Docking.DockPanel)
                        {
                            DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                            if (tpnl.Text.StartsWith("Hexviewer: " + Path.GetFileName(m_currentfile)))
                            {
                                retval = true;
                                if (ShowIfActive)
                                {
                                    tpnl.Show();
                                    dockManager1.ActivePanel = tpnl;
                                }
                            }
                        }
                    }
                }
            }
            return retval;

        }

        private bool SRAMHexViewerActive(bool ShowIfActive)
        {
            bool retval = false;
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                if (pnl.Text.StartsWith("SRAM Hexviewer: " + Path.GetFileName(m_currentsramfile)))
                {
                    retval = true;
                    if (ShowIfActive)
                    {
                        pnl.Show();
                        dockManager1.ActivePanel = pnl;
                    }
                }
                else
                {
                    foreach (Control c in pnl.Controls)
                    {
                        if (c is DevExpress.XtraBars.Docking.DockPanel)
                        {
                            DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                            if (tpnl.Text.StartsWith("Hexviewer: " + Path.GetFileName(m_currentsramfile)))
                            {
                                retval = true;
                                if (ShowIfActive)
                                {
                                    tpnl.Show();
                                    dockManager1.ActivePanel = tpnl;
                                }
                            }
                        }
                    }
                }
            }
            return retval;

        }


        private void showSRAMMapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // show sram equivalent for the current symbol
            try
            {
                if (gridViewSymbols.SelectedRowsCount > 0)
                {
                    int[] selrows = gridViewSymbols.GetSelectedRows();
                    if (selrows.Length > 0)
                    {
                        DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                        if (dr.Row["SRAMADDRESS"] != DBNull.Value)
                        {
                            int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"]);
                            int length = Convert.ToInt32(dr.Row["LENGTHBYTES"]);
                            StartSRAMTableViewer();
                        }

                    }
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
        }

        private void barEngineEmulator_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            EngineEmulator emulator = new EngineEmulator();
            DevExpress.XtraBars.Docking.DockPanel dockPanel = dockManager1.AddPanel(new System.Drawing.Point(emulator.Width, this.Height));
            dockPanel.Controls.Add(emulator);
            emulator.Dock = DockStyle.Fill;
            dockPanel.DockTo(dockManager1, DevExpress.XtraBars.Docking.DockingStyle.Right, 0);
            dockPanel.Show();
        }

        private void barT5Docu_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
           
            try
            {
                if (File.Exists(System.Windows.Forms.Application.StartupPath + "//Trionic 5.pdf"))
                {
                    System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath + "//Trionic 5.pdf");
                }
                else
                {
                    MessageBox.Show("Trionic 5 documentation could not be found or opened!");
                }
            }
            catch (Exception E2)
            {
                Console.WriteLine(E2.Message);
            }

        }

        private void ShowManual()
        {
            try
            {
                if (File.Exists(System.Windows.Forms.Application.StartupPath + "//user_manual.pdf"))
                {
                    System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath + "//user_manual.pdf");
                }
                else
                {
                    MessageBox.Show("User manual could not be found or opened!");
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }

        }

        private void barUserManual_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ShowManual();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            gridViewSymbols.ExportToPdf(System.Windows.Forms.Application.StartupPath + "\\SymbolList.pdf");
            MessageBox.Show("List saved to : " + System.Windows.Forms.Application.StartupPath + "\\SymbolList.pdf");

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            gridSymbols.ShowPrintPreview();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            gridSymbols.Print();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            ShowManual();
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            gridViewSymbols.OptionsView.ShowGroupPanel = !gridViewSymbols.OptionsView.ShowGroupPanel;
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            gridViewSymbols.OptionsView.ShowAutoFilterRow = !gridViewSymbols.OptionsView.ShowAutoFilterRow;
        }

        private void barShowGraphs_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            m_appSettings.ShowGraphs = barShowGraphs.Checked;
            // alles omzetten?
        }

        private void ShowTableAndGraph(bool tablevisible, DevExpress.XtraBars.Docking.DockPanel pnl)
        {
            foreach (Control c in pnl.Controls)
            {
                if (c is MapViewer)
                {
                    MapViewer vwr = (MapViewer)c;
                    vwr.TableVisible = tablevisible;
                    vwr.Invalidate();
                }
                else if (c is DevExpress.XtraBars.Docking.DockPanel)
                {
                    DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                    foreach (Control c2 in tpnl.Controls)
                    {
                        if (c2 is MapViewer)
                        {
                            MapViewer vwr2 = (MapViewer)c2;
                            vwr2.TableVisible = tablevisible;
                            vwr2.Invalidate();
                        }
                    }
                }
                else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                {
                    DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                    foreach (Control c3 in cntr.Controls)
                    {
                        if (c3 is MapViewer)
                        {
                            MapViewer vwr3 = (MapViewer)c3;
                            vwr3.TableVisible = tablevisible;
                            vwr3.Invalidate();
                        }
                    }
                }
            }
        }

        private void barMaximise_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                if (dockManager1.ActivePanel.FloatForm != null)
                {
                    dockManager1.ActivePanel.Restore();
                    // en tabel en grafiek tonen (splitcontainer goed zetten)
                    ShowTableAndGraph(true,  dockManager1.ActivePanel);
                }
                else
                {
                    dockManager1.ActivePanel.FloatSize = new Size(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
                    dockManager1.ActivePanel.FloatLocation = new System.Drawing.Point(1, 1);
                    dockManager1.ActivePanel.MakeFloat();
                    // en alleen de grafiek tonen (splitcontainer goed zetten)
                    ShowTableAndGraph(false, dockManager1.ActivePanel);

                }
            }
            catch (Exception E)
            {
                AddLogItem("barMaximise_ItemClick: " + E.Message);
            }

        }

        private bool GetVSSEnabled()
        {
            bool retval = false;
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    if (sh.Length == 6)
                    {
                        byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                        byte sign = Convert.ToByte(vssdata.GetValue(5));
                        if((sign & 0x80) > 0)
                        {
                            retval = true;
                        }
                    }
                }
            }
            return retval;
        }

        private bool GetAutoGearbox()
        {
            bool retval = false;
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                    byte sign = Convert.ToByte(vssdata.GetValue(3));
                    if ((sign & 0x02) > 0)
                    {
                        retval = true;
                    }
                }
            }
            return retval;
        }

        private void SetAutoGearboxEnabled(bool enable)
        {
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                    byte sign = Convert.ToByte(vssdata.GetValue(3));
                    if (enable)
                    {
                        sign |= 0x02; // set autogearbox flag
                    }
                    else
                    {
                        sign &= 0xFD; // clear autogearbox flag
                    }
                    vssdata.SetValue(sign, 3);
                    savedatatobinary(sh.Flash_start_address - 0x40000, sh.Length, vssdata, m_currentfile);
                }

            }
        }

         private bool GetHeatplates()
        {
            bool retval = false;
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                    byte sign = Convert.ToByte(vssdata.GetValue(3));
                    if ((sign & 0x01) > 0)
                    {
                        retval = true;
                    }
                }
            }
            return retval;
        }

        private void SetHeatplatesEnabled(bool enable)
        {
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                    byte sign = Convert.ToByte(vssdata.GetValue(3));
                    if (enable)
                    {
                        sign |= 0x01; // set autogearbox flag
                    }
                    else
                    {
                        sign &= 0xFE; // clear autogearbox flag
                    }
                    vssdata.SetValue(sign, 3);
                    savedatatobinary(sh.Flash_start_address - 0x40000, sh.Length, vssdata, m_currentfile);
                }

            }
        }
        
        private void SetVSSEnabled(bool enable)
        {
            foreach (SymbolHelper sh in m_symbols)
            {
                if (sh.Varname == "Pgm_mod!")
                {
                    if (sh.Length == 6)
                    {


                        byte[] vssdata = readdatafromfile(m_currentfile, sh.Flash_start_address - 0x40000, sh.Length);

                        byte sign = Convert.ToByte(vssdata.GetValue(5));
                        if (enable)
                        {
                            sign |= 0x80; // set vss flag
                        }
                        else
                        {
                            sign &= 0x7F; // clear vss flag
                        }
                        vssdata.SetValue(sign, 5);
                        savedatatobinary(sh.Flash_start_address - 0x40000, sh.Length, vssdata, m_currentfile);
                    }
                }
            }
        }

        private void barButtonItem18_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // show generic screen with alle software information in one (editable)
            //In column 03: D4hex is manual gearbox and no heatplate, D5hex is manual gearbox and heatplate, D6hex is automatic transmission and no heatplate, D7hex is automatic transmission and heatplate.

            frmFirmwareInfo info = new frmFirmwareInfo();
            info.CarModel = readcarmodel();
            info.EngineType = readenginetype();
            info.PartNumber = readpartnumber();
            info.SoftwareID = readsoftwareid();
            info.VSSCode = readimmocode();
            try
            {
                info.Checksum = Convert.ToInt32(readchecksum(), 16);
            }
            catch (Exception E)
            {
                Console.WriteLine("Failed to set checksum in info screen: " + E.Message);
            }
            info.VSSEnabled = GetVSSEnabled();
            info.AutoGearBox = GetAutoGearbox();
            info.HeatplatesPresent = GetHeatplates();
            //int offset = 0;
            //int length = 0;
            //string value = string.Empty;
/*         

  

            Console.WriteLine("Dataname: ");
            offset = ReadMarkerAddress(0x03, out length, out value);
            Console.WriteLine(offset.ToString("X6") + " len: " + length.ToString("X2") + " val: " + value);

            Console.WriteLine("Engine: ");
            offset = ReadMarkerAddress(0x04, out length, out value);
            Console.WriteLine(offset.ToString("X6") + " len: " + length.ToString("X2") + " val: " + value);

            Console.WriteLine("Immo code: ");
            offset = ReadMarkerAddress(0x05, out length, out value);
            Console.WriteLine(offset.ToString("X6") + " len: " + length.ToString("X2") + " val: " + value);
            */
            if (info.ShowDialog() == DialogResult.OK)
            {
                // alles wegschrijven
                writecarmodel(info.CarModel);
                writeenginetype(info.EngineType);
                writepartnumber(info.PartNumber);
                writesoftwareid(info.SoftwareID);
                writeimmocode(info.VSSCode);
                SetVSSEnabled(info.VSSEnabled);
                SetAutoGearboxEnabled(info.AutoGearBox);
                SetHeatplatesEnabled(info.HeatplatesPresent);
                if(m_appSettings.AutoChecksum) 
                {
                    if(!verifychecksum())
                    {
                    updatechecksum();
                    }
                }
            }
            SetVSSStatus();
/*            if (data == 0x01) { make_dump = 1; name = "_ECU_PARTNO"; }
            if (data == 0x02) { make_dump = 1; name = "_ECU_SWNO"; }
            if (data == 0x03) { make_dump = 1; name = "_ECU_DATANAME"; }
            if (data == 0x04) { make_dump = 1; name = "_ECU_ENGINE"; }
            if (data == 0x05) { make_dump = 1; name = "_ECU_IMMOCODE"; }*/


        }
        
        private void barButtonItem21_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            
                
        }

        private void barCheckSymbolWindow_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (barCheckSymbolWindow.Checked) dockSymbols.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            else dockSymbols.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            m_appSettings.HideSymbolTable = barCheckSymbolWindow.Checked;
        }

        private void repositoryItemLookUpEdit1_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            if (e.Button.Kind == DevExpress.XtraEditors.Controls.ButtonPredefines.Right)
            {
                if (barEditSymbollist.EditValue != null)
                {
                    StartTableViewer((string)barEditSymbollist.EditValue);
                }
                // selecteer juiste symbol in de symbolgridview!
                /*System.Data.DataTable dt = (System.Data.DataTable)gridSymbols.DataSource;
                int rtel = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["SYMBOLNAME"] != DBNull.Value && barEditSymbollist.EditValue != null)
                    {
                        if (dr["SYMBOLNAME"].ToString() == (string)barEditSymbollist.EditValue)
                        {
                            int rhandle = gridViewSymbols.GetRowHandle(rtel);
                            gridViewSymbols.OptionsSelection.MultiSelect = true;
                            gridViewSymbols.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.RowSelect;
                            gridViewSymbols.ClearSelection();
                            gridViewSymbols.SelectRow(rhandle);
                            //gridViewSymbols.SelectRows(rhandle, rhandle);
                            gridViewSymbols.MakeRowVisible(rhandle, true);
                            //gridViewSymbols.SelectRange(rhandle, rhandle);
                            StartTableViewer();
                            break;
                        }
                    }
                    rtel++;
                }*/
            }
        }

      

        private void barEditItem1_ShowingEditor(object sender, DevExpress.XtraBars.ItemCancelEventArgs e)
        {
            repositoryItemLookUpEdit2.DataSource = mrudt;
        }

        private void barEditItem1_EditValueChanged(object sender, EventArgs e)
        {
            if (barEditItem1.EditValue != null)
            {
                if (barEditItem1.EditValue != DBNull.Value)
                {
                    TryToLoadFile(barEditItem1.EditValue.ToString());
                }
            }
        }

        private void StartTableViewer(string symbolname)
        {
            System.Data.DataTable dt = (System.Data.DataTable)gridSymbols.DataSource;
            int rtel = 0;
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["SYMBOLNAME"] != DBNull.Value && symbolname != null)
                {
                    if (dr["SYMBOLNAME"].ToString() == symbolname)
                    {
                        try
                        {
                            int rhandle = gridViewSymbols.GetRowHandle(rtel);
                            gridViewSymbols.OptionsSelection.MultiSelect = true;
                            gridViewSymbols.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.RowSelect;
                            gridViewSymbols.ClearSelection();
                            gridViewSymbols.SelectRow(rhandle);
                            //gridViewSymbols.SelectRows(rhandle, rhandle);
                            gridViewSymbols.MakeRowVisible(rhandle, true);
                            //gridViewSymbols.SelectRange(rhandle, rhandle);
                            StartTableViewer();
                            break;
                        }
                        catch (Exception E)
                        {
                            MessageBox.Show(E.Message);
                        }
                    }
                }
                rtel++;
            }
        }

        private void barButtonItem19_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            // select "Tryck_mat!" in symbol viewer and start the viewer
            StartTableViewer("Tryck_mat!");
        }

        private void barButtonItem27_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Tryck_vakt_tab!");
        }

        private void barButtonItem28_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Regl_tryck_fgm!");
        }

        private void barButtonItem29_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Regl_tryck_sgm!");
        }

        private void barButtonItem35_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("P_fors!");
        }

        private void barButtonItem36_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("I_fors!");
        }

        private void barButtonItem37_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("D_fors!");
        }

        private void barButtonItem38_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Tryck_mat_a!");

        }

        private void barButtonItem39_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Tryck_vakt_tab!"); //?
        }

        private void barButtonItem40_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Regl_tryck_fgaut!");
        }

        private void barButtonItem41_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("P_fors_a!");
        }

        private void barButtonItem42_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("I_fors_a!");
        }

        private void barButtonItem43_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("D_fors_a!");
        }

        private void barButtonItem30_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Insp_mat!");
        }

        private void barButtonItem15_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Ign_map_0!");
        }

        private void barButtonItem17_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Ign_map_4!");
        }

        private void barButtonItem44_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            BDMCommPD pdcomm = new BDMCommPD();
            pdcomm.onError += new BDMCommPD.NotifyError(pdcomm_onError);
            pdcomm.Init(0,15000);
            int Stopped = pdcomm.StopChip();
            string result = string.Empty;
            for (int reg = 0; reg < 8; reg++)
            {
                result += "register: " + reg.ToString() + "= "  + pdcomm.GetReg((int)BDMRegs.REG_A0 + reg).ToString("X8") + Environment.NewLine;
            }
            Console.WriteLine(result);
            if (Stopped>0) pdcomm.RunChip (0);
            pdcomm.DeInit();
            MessageBox.Show(result);
        }

        void pdcomm_onError(object sender, BDMCommPD.ErrorEventArgs e)
        {
            if (sender is BDMCommPD)
            {
                Console.WriteLine("Error event raised: " + e.Error.ToString());
                BDMCommPD commpd = (BDMCommPD)sender;
                commpd.DeInit();
            }
        }

        private void barButtonItem45_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Fuel_knock_mat!");
        }

        private void barButtonItem39_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Reg_kon_mat!");
        }

        private void barButtonItem46_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartTableViewer("Reg_kon_mat_a!");

        }

        private void SetIgnitionMap(int rpm, int MAPvalue, double degreestoadd)
        {
            //Ign_map_0!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!"), GetSymbolLength(m_symbols, "Ign_map_0!"));
            int rows = 0;
            int cols = 0;
            GetTableMatrixWitdhByName("Ign_map_0!", out cols, out rows);
            int[] rpmvalues = GetYaxisValues("Ign_map_0!");
            int[] mapvalues = GetXaxisValues("Ign_map_0!");
            for (int xt = 0; xt < mapvalues.Length; xt++)
            {
                if ((int)mapvalues.GetValue(xt) == MAPvalue)
                {
                    for (int yt = 0; yt < rpmvalues.Length; yt++)
                    {
                        if ((int)rpmvalues.GetValue(yt) == rpm)
                        {
                            // gevonden
                            Console.WriteLine("tuning Ign_map_0 at x = " + xt.ToString() + " y = " + yt.ToString() + " val = " + degreestoadd.ToString());
                            
                            double curr_value = readbytefromfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!") + (yt * cols * 2) + (xt * 2)) * 256;
                            curr_value += readbytefromfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!") + (yt * cols * 2) + (xt * 2) + 1);
                            Console.WriteLine("Current value was: :" + curr_value.ToString());
                            double curr_real_value = curr_value / 10;
                            AddToResumeTable("Updated ignition map value at x = " + xt.ToString() + ", y = " + yt.ToString() + " from " + curr_real_value.ToString() + " degrees with " + degreestoadd.ToString() + " degrees");
                            curr_value += degreestoadd * 10;
                            //Console.WriteLine("New value would be: :" + curr_value.ToString());
                            byte b1 = (byte)(curr_value / 256);
                            byte b2 = (byte) (curr_value - (double)(b1 * 256));
                            //Console.WriteLine("byte 1 would be : " + b1.ToString() + " byte 2 would be : " + b2.ToString());
                            writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!") + (yt * cols * 2) + (xt * 2), b1);
                            writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!") + (yt * cols * 2) + (xt * 2) + 1, b2);
                            //writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Ign_map_0!") + (yt * cols) + xt, (byte)value);
                        }
                    }
                }
            }
        }

        private void SetBoostRequestMap(int rowindex, int colindex, double value, double autoGearBoxPercentage)
        {
            //Tryck_mat!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat!"), GetSymbolLength(m_symbols, "Tryck_mat!"));
            int rows = 0;
            int cols = 0;
            GetTableMatrixWitdhByName("Tryck_mat!", out cols, out rows);
            int[] rpmvalues = GetYaxisValues("Tryck_mat!");
            int[] mapvalues = GetXaxisValues("Tryck_mat!");
            int xt = colindex;
            int yt = rowindex;
            // gevonden
            //Console.WriteLine("tuning boost request map at x = " + xt.ToString() + " y = " + yt.ToString() + " perc = " + percentage.ToString());
            byte curr_byte = readbytefromfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat!") + (yt * cols) + xt);
            //double newval = (double)curr_byte * percentage;
            double curr_real_value = (double)curr_byte;
            curr_real_value /= 100;
            curr_real_value -= 1;
            AddToResumeTable("Changed boostrequest (MAN) value at x = " + xt.ToString() + ", y = " + yt.ToString() + " from " + curr_real_value.ToString() + " bar to " + value.ToString() + " bar");

            double newval = (value + 1) * 100;
            if (newval > 254) newval = 254;
            //if (newval > 236) newval = 236; // block at 1.36 bar... 
            curr_byte = Convert.ToByte(newval);
            writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat!") + (yt * cols) + xt, curr_byte);
            // do for auto transmission also
            SetBoostRequestMapAutoTrans(rowindex, colindex, value * (autoGearBoxPercentage / 100));
        }

        private void SetBoostRequestMapAutoTrans(int rowindex, int colindex, double value)
        {
            //Tryck_mat_a!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat_a!"), GetSymbolLength(m_symbols, "Tryck_mat_a!"));
            int rows = 0;
            int cols = 0;
            GetTableMatrixWitdhByName("Tryck_mat_a!", out cols, out rows);
            int[] rpmvalues = GetYaxisValues("Tryck_mat_a!");
            int[] mapvalues = GetXaxisValues("Tryck_mat_a!");
            int xt = colindex;
            int yt = rowindex;
            // gevonden
            //Console.WriteLine("tuning boost request map at x = " + xt.ToString() + " y = " + yt.ToString() + " perc = " + percentage.ToString());
            byte curr_byte = readbytefromfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat_a!") + (yt * cols) + xt);
            double curr_real_value = (double)curr_byte;
            curr_real_value /= 100;
            curr_real_value -= 1;
            //double newval = (double)curr_byte * percentage;
            AddToResumeTable("Changed boostrequest (AUT) value at x = " + xt.ToString() + ", y = " + yt.ToString() + " from " + curr_real_value.ToString() + " bar to " + value.ToString() + " bar");
            double newval = (value + 1) * 100;
            if (newval > 254) newval = 254;
            //if (newval > 236) newval = 236; // block at 1.36 bar... 
            curr_byte = Convert.ToByte(newval);
            writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_mat_a!") + (yt * cols) + xt, curr_byte);
        }


        private void SetInjectionMap(int rpm, int MAPvalue, int value)
        {
            // Insp_mat!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols,"Insp_mat!"), GetSymbolLength(m_symbols, "Insp_mat!"));
            int rows = 0;
            int cols = 0;
            GetTableMatrixWitdhByName("Insp_mat!", out cols, out rows);
            int[] rpmvalues = GetYaxisValues("Insp_mat!");
            int[] mapvalues = GetXaxisValues("Insp_mat!");
            for (int xt = 0; xt < mapvalues.Length; xt++)
            {
                if ((int)mapvalues.GetValue(xt) == MAPvalue)
                {
                    for (int yt = 0; yt < rpmvalues.Length; yt++)
                    {
                        if ((int)rpmvalues.GetValue(yt) == rpm)
                        {
                            // gevonden
                            //Console.WriteLine("tuning insp_mat at x = " + xt.ToString() + ", y = " + yt.ToString() + " val = " + value.ToString());
                            byte currval = readbytefromfile(m_currentfile, GetSymbolAddress(m_symbols, "Insp_mat!") + (yt * cols) + xt);
                            AddToResumeTable("Changed injection map value at x = " + xt.ToString() + ", y = " + yt.ToString() + " from " + currval.ToString() + " to " + value.ToString());

                            if (currval > value) value = currval;
                            writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Insp_mat!") + (yt * cols) + xt, (byte)value);
                        }
                    }
                }
            }

        }

        private void SetBoostLimitMap(byte value)
        {
            //Tryck_vakt_tab!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_vakt_tab!"), GetSymbolLength(m_symbols, "Tryck_vakt_tab!"));
            for (int tel = 0; tel < mapdata.Length; tel++)
            {
                writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Tryck_vakt_tab!") + tel, (byte)value);
            }
        }

        private void SetFirstGearLimiter(byte value)
        {
            //Regl_tryck_fgm!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_fgm!"), GetSymbolLength(m_symbols, "Regl_tryck_fgm!"));
            for (int tel = 0; tel < mapdata.Length; tel++)
            {
                writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_fgm!") + tel, (byte)value);
            }
        }

        private void SetSecondGearLimiter(byte value)
        {
            //Regl_tryck_sgm!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_sgm!"), GetSymbolLength(m_symbols, "Regl_tryck_sgm!"));
            for (int tel = 0; tel < mapdata.Length; tel++)
            {
                writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_sgm!") + tel, (byte)value);
            }

        }

        private void SetFirstGearLimiterAutoTrans(byte value)
        {
            //Regl_tryck_fgaut!
            byte[] mapdata = readdatafromfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_fgaut!"), GetSymbolLength(m_symbols, "Regl_tryck_fgaut!"));
            for (int tel = 0; tel < mapdata.Length; tel++)
            {
                writebyteinfile(m_currentfile, GetSymbolAddress(m_symbols, "Regl_tryck_fgaut!") + tel, (byte)value);
            }

        }


        System.Data.DataTable resumeTuning = new System.Data.DataTable();

        private void AddToResumeTable(string description)
        {
            if (resumeTuning != null)
            {
                if (resumeTuning.Columns.Count == 1)
                {
                    resumeTuning.Rows.Add(description);
                }
            }
        }

        private void TuneToStage(int stage, double maxBoostValue, double maxBoostFirstGear, double maxBoostSecondGear, double maxBoostFirstGearAUT, double fuelCutLevel, double AutoGearBoxPercentage, bool isLpt)
        {
            frmProgress progress = new frmProgress();
            progress.Show();
            progress.SetProgress("Checking current configuration...");
            resumeTuning = new System.Data.DataTable();
            resumeTuning.Columns.Add("Description");
            // get the software ID from the bainery
            string enginetp = readenginetype();
            string partnumber = readpartnumber();
            // look up parameters for this sw id
            PartNumberConverter pnc = new PartNumberConverter();
            ECUInformation ecuinfo = pnc.GetECUInfo(partnumber, enginetp);
            progress.SetProgress("Creating backup file...");
            File.Copy(m_currentfile, Path.GetDirectoryName(m_currentfile) + "\\" + Path.GetFileNameWithoutExtension(m_currentfile) + DateTime.Now.ToString("yyyyMMddHHmmss") + "beforetuningtostage" + stage.ToString() + ".bin", true);
            AddToResumeTable("Backup file created (" + Path.GetFileNameWithoutExtension(m_currentfile) + DateTime.Now.ToString("yyyyMMddHHmmss") + "beforetuningtostage" + stage.ToString() + ".bin"); 
            progress.SetProgress("Modifying boost request map...");
            SetBoostRequestMap(0, 6, maxBoostValue * 0.85, AutoGearBoxPercentage); // 75% of max boost
            SetBoostRequestMap(1, 6, maxBoostValue * 0.87, AutoGearBoxPercentage);
            SetBoostRequestMap(2, 6, maxBoostValue * 0.89, AutoGearBoxPercentage);
            SetBoostRequestMap(3, 6, maxBoostValue * 0.90, AutoGearBoxPercentage);
            SetBoostRequestMap(4, 6, maxBoostValue * 0.95, AutoGearBoxPercentage);
            SetBoostRequestMap(5, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(6, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(7, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(8, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(9, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(10, 6, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(11, 6, maxBoostValue * 0.9, AutoGearBoxPercentage);
            SetBoostRequestMap(12, 6, maxBoostValue * 0.8, AutoGearBoxPercentage);
            SetBoostRequestMap(13, 6, maxBoostValue * 0.7, AutoGearBoxPercentage);
            SetBoostRequestMap(14, 6, maxBoostValue * 0.65, AutoGearBoxPercentage);
            SetBoostRequestMap(15, 6, maxBoostValue * 0.6, AutoGearBoxPercentage);

            SetBoostRequestMap(0, 7, maxBoostValue * 0.85, AutoGearBoxPercentage); // 75% of max boost
            SetBoostRequestMap(1, 7, maxBoostValue * 0.89, AutoGearBoxPercentage);
            SetBoostRequestMap(2, 7, maxBoostValue * 0.9, AutoGearBoxPercentage);
            SetBoostRequestMap(3, 7, maxBoostValue * 0.95, AutoGearBoxPercentage);
            SetBoostRequestMap(4, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(5, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(6, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(7, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(8, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(9, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(10, 7, maxBoostValue, AutoGearBoxPercentage);
            SetBoostRequestMap(11, 7, maxBoostValue * 0.9, AutoGearBoxPercentage);
            SetBoostRequestMap(12, 7, maxBoostValue * 0.8, AutoGearBoxPercentage);
            SetBoostRequestMap(13, 7, maxBoostValue * 0.7, AutoGearBoxPercentage);
            SetBoostRequestMap(14, 7, maxBoostValue * 0.65, AutoGearBoxPercentage);
            SetBoostRequestMap(15, 7, maxBoostValue * 0.6, AutoGearBoxPercentage);

            if (isLpt)
            {
                // more columns need adjusting
                SetBoostRequestMap(0, 5, maxBoostValue * 0.65, AutoGearBoxPercentage); // 75% of max boost
                SetBoostRequestMap(1, 5, maxBoostValue * 0.67, AutoGearBoxPercentage);
                SetBoostRequestMap(2, 5, maxBoostValue * 0.69, AutoGearBoxPercentage);
                SetBoostRequestMap(3, 5, maxBoostValue * 0.70, AutoGearBoxPercentage);
                SetBoostRequestMap(4, 5, maxBoostValue * 0.75, AutoGearBoxPercentage);
                SetBoostRequestMap(5, 5, maxBoostValue * 0.80, AutoGearBoxPercentage);
                SetBoostRequestMap(6, 5, maxBoostValue * 0.80, AutoGearBoxPercentage);
                SetBoostRequestMap(7, 5, maxBoostValue * 0.80, AutoGearBoxPercentage);
                SetBoostRequestMap(8, 5, maxBoostValue * 0.80, AutoGearBoxPercentage);
                SetBoostRequestMap(9, 5, maxBoostValue * 0.80, AutoGearBoxPercentage);
                SetBoostRequestMap(10, 5, maxBoostValue * 0.70, AutoGearBoxPercentage);
                SetBoostRequestMap(11, 5, maxBoostValue * 0.6, AutoGearBoxPercentage);
                SetBoostRequestMap(12, 5, maxBoostValue * 0.5, AutoGearBoxPercentage);
                SetBoostRequestMap(13, 5, maxBoostValue * 0.45, AutoGearBoxPercentage);
                SetBoostRequestMap(14, 5, maxBoostValue * 0.45, AutoGearBoxPercentage);
                SetBoostRequestMap(15, 5, maxBoostValue * 0.4, AutoGearBoxPercentage);

                SetBoostRequestMap(0, 4, maxBoostValue * 0.55, AutoGearBoxPercentage); // 75% of max boost
                SetBoostRequestMap(1, 4, maxBoostValue * 0.55, AutoGearBoxPercentage);
                SetBoostRequestMap(2, 4, maxBoostValue * 0.55, AutoGearBoxPercentage);
                SetBoostRequestMap(3, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(4, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(5, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(6, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(7, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(8, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(9, 4, maxBoostValue * 0.50, AutoGearBoxPercentage);
                SetBoostRequestMap(10, 4, maxBoostValue * 0.40, AutoGearBoxPercentage);
                SetBoostRequestMap(11, 4, maxBoostValue * 0.3, AutoGearBoxPercentage);
                SetBoostRequestMap(12, 4, maxBoostValue * 0.2, AutoGearBoxPercentage);
                SetBoostRequestMap(13, 4, maxBoostValue * 0.15, AutoGearBoxPercentage);
                SetBoostRequestMap(14, 4, maxBoostValue * 0.15, AutoGearBoxPercentage);
                SetBoostRequestMap(15, 4, maxBoostValue * 0.1, AutoGearBoxPercentage);
            }


            progress.SetProgress("Modifying fuel injection map...");
            SetInjectionMap(6200, 224, 241);
            SetInjectionMap(6200, 208, 241);
            SetInjectionMap(5820, 224, 241);
            SetInjectionMap(5820, 208, 241);
            SetInjectionMap(5440, 224, 238);
            SetInjectionMap(5440, 208, 238);
            progress.SetProgress("Modifying ignition map...");
            SetIgnitionMap(6200, 240, 1.5);
            SetIgnitionMap(5820, 240, 1.0);
            SetIgnitionMap(5440, 240, 0.5);
            progress.SetProgress("Modifying limiters...");
            byte fuelcut = (byte)((fuelCutLevel + 1) * 100);
            SetBoostLimitMap(/*254*/ fuelcut);

            AddToResumeTable("Updated fuelcut map to: " + fuelCutLevel.ToString() + " bar");
            byte fglimit = (byte)((maxBoostFirstGear + 1) * 100);
            SetFirstGearLimiter(/*172*/fglimit);
            AddToResumeTable("Updated first gear limiter (MAN) to: " + maxBoostFirstGear.ToString() + " bar");
            byte fgalimit = (byte)((maxBoostFirstGearAUT + 1) * 100);
            SetFirstGearLimiterAutoTrans(/*162*/fgalimit);
            AddToResumeTable("Updated first gear limiter (AUT) to: " + maxBoostFirstGearAUT.ToString() + " bar");
            byte sglimit = (byte)((maxBoostSecondGear + 1) * 100);
            SetSecondGearLimiter(/*254*/sglimit);
            AddToResumeTable("Updated second gear limiter (MAN) to: " + maxBoostSecondGear.ToString() + " bar");
            /*switch (stage)
            {
                case 1:
                     SetBoostRequestMap(0, 6, 1 + 0.085 / 5);
            SetBoostRequestMap(1, 6, 1 + 0.17 / 5);
            SetBoostRequestMap(2, 6, 1 + 0.275 / 5);
            SetBoostRequestMap(3, 6, 1 + 0.275 / 5);
            SetBoostRequestMap(4, 6, 1 + 0.26 / 5);
            SetBoostRequestMap(5, 6, 1 + 0.26 / 5);
            SetBoostRequestMap(6, 6, 1 + 0.34 / 5);
            SetBoostRequestMap(7, 6, 1 + 0.48 / 5);
            SetBoostRequestMap(8, 6, 1 + 0.60 / 5);
            SetBoostRequestMap(9, 6, 1 + 0.54 / 5);
            SetBoostRequestMap(10, 6, 1 + 0.43 / 5);
            SetBoostRequestMap(11, 6, 1 + 0.39 / 5);
            SetBoostRequestMap(12, 6, 1 + 0.36 / 5);
            SetBoostRequestMap(13, 6, 1 + 0.38 / 5);
            SetBoostRequestMap(14, 6, 1 + 0.27 / 5);
            SetBoostRequestMap(15, 6, 1 + 0.32 / 5);
            SetBoostRequestMap(0, 7, 1 + 0.085 / 5);
            SetBoostRequestMap(1, 7, 1 + 0.17 / 5);
            SetBoostRequestMap(2, 7, 1 + 0.17 / 5);
            SetBoostRequestMap(3, 7, 1 + 0.23 / 5);
            SetBoostRequestMap(4, 7, 1 + 0.22 / 5);
            SetBoostRequestMap(5, 7, 1 + 0.27 / 5);
            SetBoostRequestMap(6, 7, 1 + 0.46 / 5);
            SetBoostRequestMap(7, 7, 1 + 0.62 / 5);
            SetBoostRequestMap(8, 7, 1 + 0.74 / 5);
            SetBoostRequestMap(9, 7, 1 + 0.70 / 5);
            SetBoostRequestMap(10, 7, 1 + 0.62 / 5);
            SetBoostRequestMap(11, 7, 1 + 0.70 / 5);
            SetBoostRequestMap(12, 7, 1 + 0.79 / 5);
            SetBoostRequestMap(13, 7, 1 + 0.85 / 5);
            SetBoostRequestMap(14, 7, 1 + 0.97 / 5);
            SetBoostRequestMap(15, 7, 1 + 1.20 / 5);
            progress.SetProgress("Modifying fuel injection map...");
            SetInjectionMap(6200, 224, 241);
            SetInjectionMap(6200, 208, 241);
            SetInjectionMap(5820, 224, 241);
            SetInjectionMap(5820, 208, 241);
            SetInjectionMap(5440, 224, 238);
            SetInjectionMap(5440, 208, 238);
            progress.SetProgress("Modifying ignition map...");
            SetIgnitionMap(6200, 240, 1.5);
            SetIgnitionMap(5820, 240, 1.0);
            SetIgnitionMap(5440, 240, 0.5);
            progress.SetProgress("Modifying limiters...");
            SetBoostLimitMap(254);
            SetFirstGearLimiter(172);
            SetFirstGearLimiterAutoTrans(162);
            SetSecondGearLimiter(254);
                  

                    break;
                case 2:
                    SetBoostRequestMap(0, 6, 1 + 0.085 / 3);
                    SetBoostRequestMap(1, 6, 1 + 0.17 / 3);
                    SetBoostRequestMap(2, 6, 1 + 0.275 / 3);
                    SetBoostRequestMap(3, 6, 1 + 0.275 / 3);
                    SetBoostRequestMap(4, 6, 1 + 0.26 / 3);
                    SetBoostRequestMap(5, 6, 1 + 0.26 / 3);
                    SetBoostRequestMap(6, 6, 1 + 0.34 / 3);
                    SetBoostRequestMap(7, 6, 1 + 0.48 / 3);
                    SetBoostRequestMap(8, 6, 1 + 0.60 / 3);
                    SetBoostRequestMap(9, 6, 1 + 0.54 / 3);
                    SetBoostRequestMap(10, 6, 1 + 0.43 / 3);
                    SetBoostRequestMap(11, 6, 1 + 0.39 / 3);
                    SetBoostRequestMap(12, 6, 1 + 0.36 / 3);
                    SetBoostRequestMap(13, 6, 1 + 0.38 / 3);
                    SetBoostRequestMap(14, 6, 1 + 0.27 / 3);
                    SetBoostRequestMap(15, 6, 1 + 0.32 / 3);
                    SetBoostRequestMap(0, 7, 1 + 0.085 / 3);
                    SetBoostRequestMap(1, 7, 1 + 0.17 / 3);
                    SetBoostRequestMap(2, 7, 1 + 0.17 / 3);
                    SetBoostRequestMap(3, 7, 1 + 0.23 / 3);
                    SetBoostRequestMap(4, 7, 1 + 0.22 / 3);
                    SetBoostRequestMap(5, 7, 1 + 0.27 / 3);
                    SetBoostRequestMap(6, 7, 1 + 0.46 / 3);
                    SetBoostRequestMap(7, 7, 1 + 0.62 / 3);
                    SetBoostRequestMap(8, 7, 1 + 0.74 / 3);
                    SetBoostRequestMap(9, 7, 1 + 0.70 / 3);
                    SetBoostRequestMap(10, 7, 1 + 0.62 / 3);
                    SetBoostRequestMap(11, 7, 1 + 0.70 / 3);
                    SetBoostRequestMap(12, 7, 1 + 0.79 / 3);
                    SetBoostRequestMap(13, 7, 1 + 0.85 / 3);
                    SetBoostRequestMap(14, 7, 1 + 0.97 / 3);
                    SetBoostRequestMap(15, 7, 1 + 1.20 / 3);
                    progress.SetProgress("Modifying fuel injection map...");
                    SetInjectionMap(6200, 224, 241);
                    SetInjectionMap(6200, 208, 241);
                    SetInjectionMap(5820, 224, 241);
                    SetInjectionMap(5820, 208, 241);
                    SetInjectionMap(5440, 224, 238);
                    SetInjectionMap(5440, 208, 238);
                    progress.SetProgress("Modifying ignition map...");
                    SetIgnitionMap(6200, 240, 1.5);
                    SetIgnitionMap(5820, 240, 1.0);
                    SetIgnitionMap(5440, 240, 0.5);
                    progress.SetProgress("Modifying limiters...");
                    SetBoostLimitMap(254);
                    SetFirstGearLimiter(172);
                    SetFirstGearLimiterAutoTrans(162);
                    SetSecondGearLimiter(254);
                    break;
                case 3:
                    SetBoostRequestMap(0, 6, 1.085);
                    SetBoostRequestMap(1, 6, 1.17);
                    SetBoostRequestMap(2, 6, 1.275);
                    SetBoostRequestMap(3, 6, 1.275);
                    SetBoostRequestMap(4, 6, 1.26);
                    SetBoostRequestMap(5, 6, 1.26);
                    SetBoostRequestMap(6, 6, 1.34);
                    SetBoostRequestMap(7, 6, 1.48);
                    SetBoostRequestMap(8, 6, 1.60);
                    SetBoostRequestMap(9, 6, 1.54);
                    SetBoostRequestMap(10, 6, 1.43);
                    SetBoostRequestMap(11, 6, 1.39);
                    SetBoostRequestMap(12, 6, 1.36);
                    SetBoostRequestMap(13, 6, 1.38);
                    SetBoostRequestMap(14, 6, 1.27);
                    SetBoostRequestMap(15, 6, 1.32);
                    SetBoostRequestMap(0, 7, 1.085);
                    SetBoostRequestMap(1, 7, 1.17);
                    SetBoostRequestMap(2, 7, 1.17);
                    SetBoostRequestMap(3, 7, 1.23);
                    SetBoostRequestMap(4, 7, 1.22);
                    SetBoostRequestMap(5, 7, 1.27);
                    SetBoostRequestMap(6, 7, 1.46);
                    SetBoostRequestMap(7, 7, 1.62);
                    SetBoostRequestMap(8, 7, 1.74);
                    SetBoostRequestMap(9, 7, 1.70);
                    SetBoostRequestMap(10, 7, 1.62);
                    SetBoostRequestMap(11, 7, 1.70);
                    SetBoostRequestMap(12, 7, 1.79);
                    SetBoostRequestMap(13, 7, 1.85);
                    SetBoostRequestMap(14, 7, 1.97);
                    SetBoostRequestMap(15, 7, 2.20);
                    progress.SetProgress("Modifying fuel injection map...");
                    SetInjectionMap(6200, 224, 241);
                    SetInjectionMap(6200, 208, 241);
                    SetInjectionMap(5820, 224, 241);
                    SetInjectionMap(5820, 208, 241);
                    SetInjectionMap(5440, 224, 238);
                    SetInjectionMap(5440, 208, 238);
                    progress.SetProgress("Modifying ignition map...");
                    SetIgnitionMap(6200, 240, 1.5);
                    SetIgnitionMap(5820, 240, 1.0);
                    SetIgnitionMap(5440, 240, 0.5);
                    progress.SetProgress("Modifying limiters...");
                    SetBoostLimitMap(254);
                    SetFirstGearLimiter(172);
                    SetFirstGearLimiterAutoTrans(162);
                    SetSecondGearLimiter(254);
                    break;
            }*/
            // mark this particular file as tuned to stage X, to prevent running the wizard to the same stage again!
            enginetp = enginetp.Substring(0, enginetp.Length - 4);
            enginetp += "T5S" + stage.ToString();
            writeenginetype(enginetp);
            AddToResumeTable("Updated binary description with tuned stage");
            updatechecksum();
            AddToResumeTable("Updated checksum");
            progress.Close();
            RefreshOpenViewers();

        }

        private void RefreshViewer(MapViewer tabdet)
        {

            tabdet.GraphVisible = m_appSettings.ShowGraphs;
            //tabdet.IsHexMode = barViewInHex.Checked;
            if (barViewInHex.Checked)
            {
                tabdet.Viewtype = ViewType.Hexadecimal;
            }
            else
            {
                tabdet.Viewtype = ViewType.Easy;
            }

            tabdet.IsRedWhite = m_appSettings.ShowRedWhite;
            //tabdet.Map_name = dr.Row["SYMBOLNAME"].ToString();
            //tabdet.Map_descr = TranslateSymbolName(tabdet.Map_name);
            //tabdet.Map_cat = TranslateSymbolNameToCategory(tabdet.Map_name);
            tabdet.X_axisvalues = GetXaxisValues(tabdet.Map_name);
            tabdet.Y_axisvalues = GetYaxisValues(tabdet.Map_name);
            // z, y and z axis to do
            string xdescr = string.Empty;
            string ydescr = string.Empty;
            string zdescr = string.Empty;
            GetAxisDescriptions(tabdet.Map_name, out xdescr, out ydescr, out zdescr);
            tabdet.X_axis_name = xdescr;
            tabdet.Y_axis_name = ydescr;
            tabdet.Z_axis_name = zdescr;
            int columns = 8;
            int rows = 8;
            int tablewidth = GetTableMatrixWitdhByName(tabdet.Map_name, out columns, out rows);
            //int address = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
            //int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"].ToString());
            byte[] mapdata = readdatafromfile(m_currentfile, tabdet.Map_address, tabdet.Map_length);
            tabdet.Map_content = mapdata;
            tabdet.Correction_factor = GetMapCorrectionFactor(tabdet.Map_name);
            tabdet.Correction_offset = GetMapCorrectionOffset(tabdet.Map_name);
            tabdet.IsUpsideDown = GetMapUpsideDown(tabdet.Map_name);
            tabdet.ShowTable(columns, isSixteenBitTable(tabdet.Map_name));
        }

        private void RefreshOpenViewers()
        {
            //DevExpress.XtraBars.Docking.DockPanel dockPanel;
            //bool pnlfound = false;
            try
            {
                foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
                {
                    if (pnl.Text.StartsWith("Symbol: "))
                    {
                        foreach (Control c in pnl.Controls)
                        {
                            if (c is MapViewer)
                            {
                                MapViewer vwr = (MapViewer)c;
                                RefreshViewer(vwr);
                            }
                            else if (c is DevExpress.XtraBars.Docking.DockPanel)
                            {
                                DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                                foreach (Control c2 in tpnl.Controls)
                                {
                                    if (c2 is MapViewer)
                                    {
                                        MapViewer vwr2 = (MapViewer)c2;
                                        RefreshViewer(vwr2);
                                    }
                                }
                            }
                            else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                            {
                                DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                                foreach (Control c3 in cntr.Controls)
                                {
                                    if (c3 is MapViewer)
                                    {
                                        MapViewer vwr3 = (MapViewer)c3;
                                        RefreshViewer(vwr3);
                                    }
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception E)
            {
                Console.WriteLine("RefreshOpenViewers: " + E.Message);
            }
        }

        private void barButtonItem47_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //PSTaskDialog.VistaTaskDialog tuningwizard = new VistaTaskDialog();
            //PSTaskDialog.frmTaskDialog tskdialog = new frmTaskDialog();
            //��
            if (VerifyFile())
            {
                // get the software ID from the bainery
                string enginetp = readenginetype();
                string partnumber = readpartnumber();
                // look up parameters for this sw id
                PartNumberConverter pnc = new PartNumberConverter();
                ECUInformation ecuinfo = pnc.GetECUInfo(partnumber, enginetp);
                bool isLpt = false;
                string msg = string.Empty;
                if (ecuinfo.Tunedbyt5stostage > 0)
                {
                    MessageBox.Show("This file is already tuned by T5Suite, please select the original file to tune it to a different stage!");
                }
                else
                {
                    if (ecuinfo.Valid)
                    {
                        msg = "Tuning your: " + ecuinfo.Bhp.ToString() + " bhp ";
                        msg += ecuinfo.Carmodel.ToString() + " (" + ecuinfo.Enginetype.ToString() + ") ";
                        if (ecuinfo.Is2point3liter) msg += " 2.3 liter ";
                        else msg += " 2.0 liter ";
                        if (ecuinfo.Isaero) msg += " Aero binary";
                        else if (ecuinfo.Isfpt) msg += " Full pressure turbo binary";
                        else if (ecuinfo.Isturbo)
                        {
                            msg += " Low pressure turbo, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                            isLpt = true;
                        }
                        else msg += " non turbo car to stage, you'll have to modify hardware to get this working!";
                    }
                    else
                    {
                        msg = "Partnumber not recognized, tuning will continue anyway, please verify settings afterwards";
                    }

                    PSTaskDialog.cTaskDialog.ForceEmulationMode = false;
                    PSTaskDialog.cTaskDialog.EmulatedFormWidth = 600;
                    PSTaskDialog.cTaskDialog.UseToolWindowOnXP = false;
                    PSTaskDialog.cTaskDialog.VerificationChecked = true;
                    PSTaskDialog.cTaskDialog.ShowTaskDialogBox("Tune me up� to stage I wizard", "This wizard will tune your binary to a stage I equivalent.", "Boost request map, fuel injection and ignition tables will be altered" + Environment.NewLine + msg, "Happy driving!!!\nDilemma � 2007", "The author does not take responsibility for any damage done to your car or other objects in any form!", "Show me a summary after tuning", "", "Yes, tune me to stage I|No thanks!", eTaskDialogButtons.None, eSysIcons.Information, eSysIcons.Warning);
                    switch (PSTaskDialog.cTaskDialog.CommandButtonResult)
                    {
                        case 0:
                            // tune to stage 1
                            TuneToStage(1, ecuinfo.Stage1boost, 0.72,1.54,0.62, 1.54, 80, isLpt);
                            break;
/*                        case 1:
                            // tune to stage 2
                            TuneToStage(2, ecuinfo.Stage2boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 2:
                            // tune to stage 3
                            TuneToStage(3, ecuinfo.Stage3boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;*/
                        case 1:
                            // cancel
                            break;
                    }
                    if (PSTaskDialog.cTaskDialog.VerificationChecked && PSTaskDialog.cTaskDialog.CommandButtonResult != 1)
                    {
                        frmTuningWizardResume frmres = new frmTuningWizardResume();
                        frmres.SetDataTable(resumeTuning);
                        frmres.ShowDialog();
                    }
                }
            }
        }

        private void barButtonItem48_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                // get the software ID from the bainery
                string enginetp = readenginetype();
                string partnumber = readpartnumber();
                // look up parameters for this sw id
                PartNumberConverter pnc = new PartNumberConverter();
                ECUInformation ecuinfo = pnc.GetECUInfo(partnumber, enginetp);
                bool isLpt = false;
                string msg = string.Empty;
                if (ecuinfo.Tunedbyt5stostage > 0)
                {
                    MessageBox.Show("This file is already tuned by T5Suite, please select the original file to tune it to a different stage!");
                }
                else
                {
                    if (ecuinfo.Valid)
                    {
                        msg = "Tuning your: " + ecuinfo.Bhp.ToString() + " bhp ";
                        msg += ecuinfo.Carmodel.ToString() + " (" + ecuinfo.Enginetype.ToString() + ") ";
                        if (ecuinfo.Is2point3liter) msg += " 2.3 liter ";
                        else msg += " 2.0 liter ";
                        if (ecuinfo.Isaero) msg += " Aero binary";
                        else if (ecuinfo.Isfpt) msg += " Full pressure turbo binary";
                        else if (ecuinfo.Isturbo)
                        {
                            msg += " Low pressure turbo to stage, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                            isLpt = true;
                        }
                        else msg += " non turbo car to stage, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                    }
                    else
                    {
                        msg = "Partnumber not recognized, tuning will continue anyway, please verify settings afterwards";
                    }
                    PSTaskDialog.cTaskDialog.ForceEmulationMode = false;
                    PSTaskDialog.cTaskDialog.EmulatedFormWidth = 600;
                    PSTaskDialog.cTaskDialog.UseToolWindowOnXP = false;
                    PSTaskDialog.cTaskDialog.ShowTaskDialogBox("Tune me up� to stage II wizard", "This wizard will tune your binary to a stage II equivalent.", "Boost request map, fuel injection and ignition tables will be altered" + Environment.NewLine + msg, "Happy driving!!!\nDilemma � 2007", "The author does not take responsibility for any damage done to your car or other objects in any form!", "Show me a summary after tuning", "", "Yes, tune me to stage II|Tune me to stage I instead|Tune me to stage III instead|No thanks!", eTaskDialogButtons.None, eSysIcons.Information, eSysIcons.Warning);
                    switch (PSTaskDialog.cTaskDialog.CommandButtonResult)
                    {
                        case 0:
                            // tune to stage 2
                            TuneToStage(2, ecuinfo.Stage2boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 1:
                            // tune to stage 1
                            TuneToStage(1, ecuinfo.Stage1boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 2:
                            // tune to stage 3
                            TuneToStage(3, ecuinfo.Stage3boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 3:
                            // cancel
                            break;
                    }
                    if (PSTaskDialog.cTaskDialog.VerificationChecked && PSTaskDialog.cTaskDialog.CommandButtonResult != 3)
                    {
                        frmTuningWizardResume frmres = new frmTuningWizardResume();
                        frmres.SetDataTable(resumeTuning);
                        frmres.ShowDialog();
                    }

                }
            }
        }

        private void barButtonItem49_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                // get the software ID from the bainery
                string enginetp = readenginetype();
                string partnumber = readpartnumber();
                // look up parameters for this sw id
                PartNumberConverter pnc = new PartNumberConverter();
                ECUInformation ecuinfo = pnc.GetECUInfo(partnumber, enginetp);
                bool isLpt = false;
                string msg = string.Empty;
                if (ecuinfo.Tunedbyt5stostage > 0)
                {
                    MessageBox.Show("This file is already tuned by T5Suite, please select the original file to tune it to a different stage!");
                }
                else
                {
                    if (ecuinfo.Valid)
                    {
                        msg = "Tuning your: " + ecuinfo.Bhp.ToString() + " bhp ";
                        msg += ecuinfo.Carmodel.ToString() + " (" + ecuinfo.Enginetype.ToString() + ") ";
                        if (ecuinfo.Is2point3liter) msg += " 2.3 liter ";
                        else msg += " 2.0 liter ";
                        if (ecuinfo.Isaero) msg += " Aero binary";
                        else if (ecuinfo.Isfpt) msg += " Full pressure turbo binary";
                        else if (ecuinfo.Isturbo)
                        {
                            msg += " Low pressure turbo, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                            isLpt = true;
                        }
                        else msg += " non turbo car to stage, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                    }
                    else
                    {
                        msg = "Partnumber not recognized, tuning will continue anyway, please verify settings afterwards";
                    }
                    PSTaskDialog.cTaskDialog.ForceEmulationMode = false;
                    PSTaskDialog.cTaskDialog.EmulatedFormWidth = 600;
                    PSTaskDialog.cTaskDialog.UseToolWindowOnXP = false;
                    PSTaskDialog.cTaskDialog.ShowTaskDialogBox("Tune me up� to stage III wizard", "This wizard will tune your binary to a stage III equivalent.", "Boost request map, fuel injection and ignition tables will be altered" + Environment.NewLine + msg, "Happy driving!!!\nDilemma � 2007", "The author does not take responsibility for any damage done to your car or other objects in any form!", "Show me a summary after tuning", "", "Yes, tune me to stage III|Tune me to stage I instead|Tune me to stage II instead|No thanks!", eTaskDialogButtons.None, eSysIcons.Information, eSysIcons.Warning);
                    switch (PSTaskDialog.cTaskDialog.CommandButtonResult)
                    {
                        case 0:
                            // tune to stage 3
                            TuneToStage(3, ecuinfo.Stage3boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 1:
                            // tune to stage 1
                            TuneToStage(1, ecuinfo.Stage1boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 2:
                            // tune to stage 2
                            TuneToStage(2, ecuinfo.Stage2boost, 0.72, 1.54, 0.62, 1.54, 80, isLpt);
                            break;
                        case 3:
                            // cancel
                            break;
                    }
                    if (PSTaskDialog.cTaskDialog.VerificationChecked && PSTaskDialog.cTaskDialog.CommandButtonResult != 3)
                    {
                        frmTuningWizardResume frmres = new frmTuningWizardResume();
                        frmres.SetDataTable(resumeTuning);
                        frmres.ShowDialog();
                    }

                }
            }

        }
        private void AdvancedTuneToStage(int stage, double maxBoostLevel, bool isLpt)
        {
            frmTuningWizardSettings frmtwset = new frmTuningWizardSettings();
            // set parameters to right values
            frmtwset.MaxBoostLevel = maxBoostLevel;
            if (frmtwset.ShowDialog() == DialogResult.OK)
            {
                TuneToStage(stage, frmtwset.MaxBoostLevel, frmtwset.MaxBoostInFirstGear, frmtwset.MaxBoostInSecondGear, frmtwset.MaxBoostInFirstGearAUT, frmtwset.FuelCutLevel, frmtwset.AutoGearBoxPercentage, isLpt);
            }
        }

        private void barButtonItem50_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (VerifyFile())
            {
                // get the software ID from the bainery
                string enginetp = readenginetype();
                string partnumber = readpartnumber();
                // look up parameters for this sw id
                PartNumberConverter pnc = new PartNumberConverter();
                ECUInformation ecuinfo = pnc.GetECUInfo(partnumber, enginetp);
                bool isLpt = false;
                string msg = string.Empty;
                if (ecuinfo.Tunedbyt5stostage > 0)
                {
                    MessageBox.Show("This file is already tuned by T5Suite, please select the original file to tune it to a different stage!");
                }
                else
                {
                    if (ecuinfo.Valid)
                    {
                        msg = "Tuning your: " + ecuinfo.Bhp.ToString() + " bhp ";
                        msg += ecuinfo.Carmodel.ToString() + " (" + ecuinfo.Enginetype.ToString() + ") ";
                        if (ecuinfo.Is2point3liter) msg += " 2.3 liter ";
                        else msg += " 2.0 liter ";
                        if (ecuinfo.Isaero) msg += " Aero binary";
                        else if (ecuinfo.Isfpt) msg += " Full pressure turbo binary";
                        else if (ecuinfo.Isturbo)
                        {
                            msg += " Low pressure turbo, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                            isLpt = true;
                        }
                        else msg += " non turbo car to stage, you'll have to modify hardware (solenoid valve, hoses etc.) to get this working!";
                    }
                    else
                    {
                        msg = "Partnumber not recognized, tuning will continue anyway, please verify settings afterwards";
                    }

                    PSTaskDialog.cTaskDialog.ForceEmulationMode = false;
                    PSTaskDialog.cTaskDialog.EmulatedFormWidth = 600;
                    PSTaskDialog.cTaskDialog.UseToolWindowOnXP = false;
                    PSTaskDialog.cTaskDialog.ShowTaskDialogBox("Tune me up� to stage X (free-tune) wizard", "This wizard lets you tune your binary with your own parameters.", "Boost request map, fuel injection and ignition tables will be altered" + Environment.NewLine + msg, "Happy driving!!!\nDilemma � 2007", "The author does not take responsibility for any damage done to your car or other objects in any form!", "Show me a summary after tuning", "", "Preset levels for stage I|Preset levels for stage II|Preset levels for stage III|No thanks!", eTaskDialogButtons.None, eSysIcons.Information, eSysIcons.Warning);

                    switch (PSTaskDialog.cTaskDialog.CommandButtonResult)
                    {
                        case 0:
                            // tune to stage 1
                            AdvancedTuneToStage(1, ecuinfo.Stage1boost, isLpt);
                            break;
                        case 1:
                            // tune to stage 2
                            AdvancedTuneToStage(2, ecuinfo.Stage2boost, isLpt);
                            break;
                        case 2:
                            // tune to stage 3
                            AdvancedTuneToStage(3, ecuinfo.Stage3boost, isLpt);
                            break;
                        case 3:
                            // cancel
                            break;
                    }
                    if (PSTaskDialog.cTaskDialog.VerificationChecked && PSTaskDialog.cTaskDialog.CommandButtonResult != 3)
                    {
                        if (resumeTuning != null)
                        {
                            if (resumeTuning.Rows.Count > 0)
                            {
                                frmTuningWizardResume frmres = new frmTuningWizardResume();
                                frmres.SetDataTable(resumeTuning);
                                frmres.ShowDialog();
                            }
                        }
                    }

                }
            }

        }

        private void barButtonItem51_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmAbout abt = new frmAbout();
            abt.ShowDialog();
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            try
            {
                m_msiUpdater = new msiupdater(new Version(System.Windows.Forms.Application.ProductVersion));
                m_msiUpdater.Apppath = System.Windows.Forms.Application.UserAppDataPath;
                m_msiUpdater.onDataPump += new msiupdater.DataPump(m_msiUpdater_onDataPump);
                m_msiUpdater.onUpdateProgressChanged += new msiupdater.UpdateProgressChanged(m_msiUpdater_onUpdateProgressChanged);
                m_msiUpdater.CheckForUpdates("Global", "http://reverse-that-trionic.googlecode.com/svn/trunk/T5Suite/", "", "", false);
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
        }

        void m_msiUpdater_onUpdateProgressChanged(msiupdater.MSIUpdateProgressEventArgs e)
        {
            
        }

        void m_msiUpdater_onDataPump(msiupdater.MSIUpdaterEventArgs e)
        {
            SetStatusText(e.Data);
            if (e.UpdateAvailable)
            {
//                barUpdatestatus.ImageIndex = 28;
                frmUpdateAvailable frmUpdate = new frmUpdateAvailable();
                frmUpdate.SetVersionNumber(e.Version.ToString());
                m_msiUpdater.Blockauto_updates = false;

                if (frmUpdate.ShowDialog() == DialogResult.OK)
                {
                    m_msiUpdater.ExecuteUpdate(e.Version);
                    System.Windows.Forms.Application.Exit();
                }
                else
                {
                    // gebruiker heeft nee gekozen, niet meer lastig vallen
                    m_msiUpdater.Blockauto_updates = false;
                }
            }
        }

        private void barButtonItem52_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                if (m_msiUpdater != null)
                {
                    m_msiUpdater.CheckForUpdates("Global", "http://reverse-that-trionic.googlecode.com/svn/trunk/T5Suite/", "", "", false);
                }
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
        }

        private void StartHexViewer()
        {
            if (m_currentfile != "")
            {
                DevExpress.XtraBars.Docking.DockPanel dockPanel = dockManager1.AddPanel(DevExpress.XtraBars.Docking.DockingStyle.Right);
                dockPanel.Text = "Hexviewer: " + Path.GetFileName(m_currentfile);
                HexViewer hv = new HexViewer();
                hv.Issramviewer = false;
                hv.Dock = DockStyle.Fill;
                dockPanel.Width = 580;
                hv.LoadDataFromFile(m_currentfile, m_symbols);
                dockPanel.Controls.Add(hv);
            }
        }

        private void StartSRAMHexViewer()
        {
            if (m_currentsramfile != "")
            {
                DevExpress.XtraBars.Docking.DockPanel dockPanel = dockManager1.AddPanel(DevExpress.XtraBars.Docking.DockingStyle.Right);
                dockPanel.Text = "SRAM Hexviewer: " + Path.GetFileName(m_currentfile);
                HexViewer hv = new HexViewer();
                hv.Issramviewer = true;
                hv.Dock = DockStyle.Fill;
                dockPanel.Width = 580;
                hv.LoadDataFromFile(m_currentsramfile, m_symbols);
                dockPanel.Controls.Add(hv);
            }
        }

        private void barButtonItem53_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            StartHexViewer();
            StartSRAMHexViewer();
        }

        private void SelectSymbolInHexViewer(string symbolname, int fileoffset, int length)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is HexViewer)
                    {
                        HexViewer vwr = (HexViewer)c;
                        if (!vwr.Issramviewer)
                        {
                            if (vwr.FileName == m_currentfile)
                            {
                                vwr.SelectText(symbolname, fileoffset, length);
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is HexViewer)
                            {
                                HexViewer vwr2 = (HexViewer)c2;
                                if (!vwr2.Issramviewer)
                                {
                                    if (vwr2.FileName == m_currentfile)
                                    {
                                        vwr2.SelectText(symbolname, fileoffset, length);
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is HexViewer )
                            {
                                HexViewer vwr3 = (HexViewer)c3;
                                if (!vwr3.Issramviewer)
                                {
                                    if (vwr3.FileName == m_currentfile)
                                    {
                                        vwr3.SelectText(symbolname, fileoffset, length);
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

        private void SelectSymbolInSRAMHexViewer(string symbolname, int fileoffset, int length)
        {
            foreach (DevExpress.XtraBars.Docking.DockPanel pnl in dockManager1.Panels)
            {
                foreach (Control c in pnl.Controls)
                {
                    if (c is HexViewer)
                    {
                        HexViewer vwr = (HexViewer)c;
                        if (vwr.Issramviewer)
                        {
                            if (vwr.FileName == m_currentsramfile)
                            {
                                vwr.SelectText(symbolname, fileoffset, length);
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.DockPanel)
                    {
                        DevExpress.XtraBars.Docking.DockPanel tpnl = (DevExpress.XtraBars.Docking.DockPanel)c;
                        foreach (Control c2 in tpnl.Controls)
                        {
                            if (c2 is HexViewer)
                            {
                                HexViewer vwr2 = (HexViewer)c2;
                                if (vwr2.Issramviewer)
                                {
                                    if (vwr2.FileName == m_currentsramfile)
                                    {
                                        vwr2.SelectText(symbolname, fileoffset, length);
                                    }
                                }
                            }
                        }
                    }
                    else if (c is DevExpress.XtraBars.Docking.ControlContainer)
                    {
                        DevExpress.XtraBars.Docking.ControlContainer cntr = (DevExpress.XtraBars.Docking.ControlContainer)c;
                        foreach (Control c3 in cntr.Controls)
                        {
                            if (c3 is HexViewer)
                            {
                                HexViewer vwr3 = (HexViewer)c3;
                                if (vwr3.Issramviewer)
                                {
                                    if (vwr3.FileName == m_currentsramfile)
                                    {
                                        vwr3.SelectText(symbolname, fileoffset, length);
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }


        private void showSymbolInHexviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (gridViewSymbols.SelectedRowsCount > 0)
            {
                int[] selrows = gridViewSymbols.GetSelectedRows();
                if (selrows.Length > 0)
                {
                    if (!HexViewerActive(true))
                    {
                        // nieuwe hexviewer starten
                        StartHexViewer();
                    }
                    if (!SRAMHexViewerActive(true))
                    {
                        StartSRAMHexViewer();
                    }                    
                    // select symbol in viewer & scroll to it
                    DataRowView dr = (DataRowView)gridViewSymbols.GetRow((int)selrows.GetValue(0));
                    string symbolname = dr.Row["SYMBOLNAME"].ToString();
                    int flashaddress = Convert.ToInt32(dr.Row["FLASHADDRESS"].ToString());
                    int sramaddress = Convert.ToInt32(dr.Row["SRAMADDRESS"].ToString());
                    int symbollength = Convert.ToInt32(dr.Row["LENGTHBYTES"]);
                    if (flashaddress > 0x40000) flashaddress -= 0x40000;
                    SelectSymbolInHexViewer(symbolname, flashaddress, symbollength);
                    SelectSymbolInSRAMHexViewer(symbolname, sramaddress, symbollength);
                }
            }
        }

        private void barButtonItem54_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
          //  System.Diagnostics.Process.Start("mailto:t5suitepro@home.nl");
            //System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(
            try
            {
                frmSupport supp = new frmSupport();
                if (supp.ShowDialog() == DialogResult.OK)
                {
                    MailMessage msg = new MailMessage();
                    msg.From = "masked@hotmail.com";
                    msg.To = "t5suite@home.nl";
                    if (supp.SendAttachments)
                    {
                        if (m_currentfile != "")
                        {
                            msg.Attachments.Add(new System.Web.Mail.MailAttachment(m_currentfile));
                        }
                        if (m_currentsramfile != "")
                        {
                            msg.Attachments.Add(new System.Web.Mail.MailAttachment(m_currentsramfile));
                        }
                    }
                    supp.Message += Environment.NewLine + "Sender: " + supp.SenderAddress;
                    msg.Body = supp.Message;
                    msg.Subject = supp.Subject;
                    SmtpMail.Send(msg);
                    MessageBox.Show("You message was submitted");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }



    }
}