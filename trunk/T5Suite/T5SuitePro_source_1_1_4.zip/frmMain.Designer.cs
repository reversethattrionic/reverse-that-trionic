namespace T5SuitePro
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            DevExpress.Utils.SuperToolTip superToolTip33 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem36 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem33 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip34 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem37 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem34 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip35 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem38 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem35 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip36 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem39 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem36 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip37 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem40 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem37 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip38 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem41 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem38 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip39 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem42 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem39 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip40 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem43 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem40 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip41 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem44 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem41 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip42 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem45 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem42 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip43 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem46 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem43 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip44 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem47 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem44 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip45 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem48 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem45 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip46 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem49 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem46 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip47 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem50 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem47 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip48 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem51 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem48 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip49 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem52 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem49 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip50 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem53 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem50 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip51 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem54 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem51 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip52 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem55 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem52 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip53 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem56 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem53 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip54 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem57 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem54 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.ToolTipSeparatorItem toolTipSeparatorItem4 = new DevExpress.Utils.ToolTipSeparatorItem();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem58 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip55 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem59 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem55 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.ToolTipSeparatorItem toolTipSeparatorItem5 = new DevExpress.Utils.ToolTipSeparatorItem();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem60 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip56 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem61 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem56 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.ToolTipSeparatorItem toolTipSeparatorItem6 = new DevExpress.Utils.ToolTipSeparatorItem();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem62 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip57 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem63 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem57 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip58 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem64 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem58 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip59 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem65 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem59 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip60 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem66 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem60 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip61 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem67 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem61 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip62 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem68 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem62 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip63 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem69 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem63 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip64 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem70 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem64 = new DevExpress.Utils.ToolTipItem();
            this.barAndDockingController1 = new DevExpress.XtraBars.BarAndDockingController(this.components);
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.dockSymbols = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.gridSymbols = new DevExpress.XtraGrid.GridControl();
            this.mnuSymbols = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuShowTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShowGraph = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExportExcel = new System.Windows.Forms.ToolStripMenuItem();
            this.showSRAMMapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showSymbolInHexviewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridViewSymbols = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gcSymbolsName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsSRAM = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsFlash = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsLength = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsLengthAbsolute = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gcSymbolsChanged = new DevExpress.XtraGrid.Columns.GridColumn();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.controlContainer1 = new DevExpress.XtraBars.Docking.ControlContainer();
            this.webBrowserUserManual = new System.Windows.Forms.WebBrowser();
            this.dockPanel2 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel2_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.webBrowserDocumentation = new System.Windows.Forms.WebBrowser();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem12 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem13 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem14 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem16 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem20 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem23 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem24 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem25 = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem26 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem15 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem17 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem19 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem27 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem28 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem29 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem30 = new DevExpress.XtraBars.BarButtonItem();
            this.barViewInHex = new DevExpress.XtraBars.BarCheckItem();
            this.barButtonItem31 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem32 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem33 = new DevExpress.XtraBars.BarButtonItem();
            this.barOnlyRed = new DevExpress.XtraBars.BarCheckItem();
            this.barButtonItem34 = new DevExpress.XtraBars.BarButtonItem();
            this.checkVSSEnable = new DevExpress.XtraBars.BarCheckItem();
            this.barShowGraph = new DevExpress.XtraBars.BarButtonItem();
            this.barAutoChecksum = new DevExpress.XtraBars.BarCheckItem();
            this.barSRAMDumpImport = new DevExpress.XtraBars.BarButtonItem();
            this.barEngineEmulator = new DevExpress.XtraBars.BarButtonItem();
            this.barT5Docu = new DevExpress.XtraBars.BarButtonItem();
            this.barUserManual = new DevExpress.XtraBars.BarButtonItem();
            this.barShowGraphs = new DevExpress.XtraBars.BarCheckItem();
            this.barMaximise = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem18 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem21 = new DevExpress.XtraBars.BarButtonItem();
            this.barCheckSymbolWindow = new DevExpress.XtraBars.BarCheckItem();
            this.barEditSymbollist = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.barButtonItem22 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem35 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem36 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem37 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.barButtonItem38 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem40 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem41 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem42 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem43 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem44 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem45 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem39 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem46 = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem3 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem47 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem48 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem49 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem50 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem51 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem52 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem53 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem54 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageFile = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup11 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup14 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup15 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup22 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup23 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup21 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup18 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup20 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup12 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup17 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup19 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup13 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup24 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup25 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.repositoryItemMRUEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMRUEdit();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.defaultLookAndFeel1 = new DevExpress.LookAndFeel.DefaultLookAndFeel(this.components);
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog3 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog3 = new System.Windows.Forms.SaveFileDialog();
            this.ribbonPageGroup16 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.dockSymbols.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSymbols)).BeginInit();
            this.mnuSymbols.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSymbols)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.dockPanel1.SuspendLayout();
            this.controlContainer1.SuspendLayout();
            this.dockPanel2.SuspendLayout();
            this.dockPanel2_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMRUEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // barAndDockingController1
            // 
            this.barAndDockingController1.LookAndFeel.SkinName = "Blue";
            this.barAndDockingController1.PropertiesBar.AllowLinkLighting = false;
            // 
            // dockManager1
            // 
            this.dockManager1.Controller = this.barAndDockingController1;
            this.dockManager1.DockingOptions.FloatOnDblClick = false;
            this.dockManager1.Form = this;
            this.dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockSymbols});
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // dockSymbols
            // 
            this.dockSymbols.Controls.Add(this.dockPanel1_Container);
            this.dockSymbols.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.dockSymbols.FloatVertical = true;
            this.dockSymbols.ID = new System.Guid("2f21170f-7351-48b5-b5d1-4d12b73a8e58");
            this.dockSymbols.Location = new System.Drawing.Point(0, 144);
            this.dockSymbols.Name = "dockSymbols";
            this.dockSymbols.Options.FloatOnDblClick = false;
            this.dockSymbols.Options.ShowCloseButton = false;
            this.dockSymbols.Options.ShowMaximizeButton = false;
            this.dockSymbols.Size = new System.Drawing.Size(483, 779);
            this.dockSymbols.Text = "Symbols found in binary";
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.gridSymbols);
            this.dockPanel1_Container.Controls.Add(this.toolStrip1);
            this.dockPanel1_Container.Location = new System.Drawing.Point(3, 29);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(477, 747);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // gridSymbols
            // 
            this.gridSymbols.ContextMenuStrip = this.mnuSymbols;
            this.gridSymbols.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridSymbols.EmbeddedNavigator.Name = "";
            this.gridSymbols.Location = new System.Drawing.Point(0, 25);
            this.gridSymbols.LookAndFeel.SkinName = "Blue";
            this.gridSymbols.MainView = this.gridViewSymbols;
            this.gridSymbols.Name = "gridSymbols";
            this.gridSymbols.Size = new System.Drawing.Size(477, 722);
            this.gridSymbols.TabIndex = 1;
            this.gridSymbols.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewSymbols});
            // 
            // mnuSymbols
            // 
            this.mnuSymbols.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuShowTable,
            this.mnuShowGraph,
            this.mnuExportExcel,
            this.showSRAMMapToolStripMenuItem,
            this.showSymbolInHexviewerToolStripMenuItem});
            this.mnuSymbols.Name = "mnuSymbols";
            this.mnuSymbols.Size = new System.Drawing.Size(176, 114);
            this.mnuSymbols.Opening += new System.ComponentModel.CancelEventHandler(this.mnuSymbols_Opening);
            // 
            // mnuShowTable
            // 
            this.mnuShowTable.Name = "mnuShowTable";
            this.mnuShowTable.Size = new System.Drawing.Size(175, 22);
            this.mnuShowTable.Text = "Show in editor";
            this.mnuShowTable.Click += new System.EventHandler(this.mnuShowTable_Click);
            // 
            // mnuShowGraph
            // 
            this.mnuShowGraph.Name = "mnuShowGraph";
            this.mnuShowGraph.Size = new System.Drawing.Size(175, 22);
            this.mnuShowGraph.Text = "Show 3D graph";
            this.mnuShowGraph.Click += new System.EventHandler(this.mnuShowGraph_Click);
            // 
            // mnuExportExcel
            // 
            this.mnuExportExcel.Name = "mnuExportExcel";
            this.mnuExportExcel.Size = new System.Drawing.Size(175, 22);
            this.mnuExportExcel.Text = "Show in MS Excel";
            this.mnuExportExcel.Click += new System.EventHandler(this.mnuExportExcel_Click);
            // 
            // showSRAMMapToolStripMenuItem
            // 
            this.showSRAMMapToolStripMenuItem.Enabled = false;
            this.showSRAMMapToolStripMenuItem.Name = "showSRAMMapToolStripMenuItem";
            this.showSRAMMapToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.showSRAMMapToolStripMenuItem.Text = "Show SRAM map";
            this.showSRAMMapToolStripMenuItem.Click += new System.EventHandler(this.showSRAMMapToolStripMenuItem_Click);
            // 
            // showSymbolInHexviewerToolStripMenuItem
            // 
            this.showSymbolInHexviewerToolStripMenuItem.Name = "showSymbolInHexviewerToolStripMenuItem";
            this.showSymbolInHexviewerToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.showSymbolInHexviewerToolStripMenuItem.Text = "Show in hexviewer";
            this.showSymbolInHexviewerToolStripMenuItem.Click += new System.EventHandler(this.showSymbolInHexviewerToolStripMenuItem_Click);
            // 
            // gridViewSymbols
            // 
            this.gridViewSymbols.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gcSymbolsName,
            this.gcSymbolsSRAM,
            this.gcSymbolsFlash,
            this.gcSymbolsLength,
            this.gcSymbolsLengthAbsolute,
            this.gcSymbolsDescription,
            this.gcSymbolsChanged});
            this.gridViewSymbols.GridControl = this.gridSymbols;
            this.gridViewSymbols.Name = "gridViewSymbols";
            this.gridViewSymbols.OptionsBehavior.AllowIncrementalSearch = true;
            this.gridViewSymbols.OptionsBehavior.Editable = false;
            this.gridViewSymbols.OptionsFilter.UseNewCustomFilterDialog = true;
            this.gridViewSymbols.OptionsView.ShowGroupPanel = false;
            this.gridViewSymbols.OptionsView.ShowIndicator = false;
            this.gridViewSymbols.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gcSymbolsName, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridViewSymbols.ViewCaption = "Symbols";
            this.gridViewSymbols.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridViewSymbols_KeyDown);
            this.gridViewSymbols.DoubleClick += new System.EventHandler(this.gridViewSymbols_DoubleClick);
            this.gridViewSymbols.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridViewSymbols_CustomDrawCell);
            // 
            // gcSymbolsName
            // 
            this.gcSymbolsName.Caption = "Symbol name";
            this.gcSymbolsName.FieldName = "SYMBOLNAME";
            this.gcSymbolsName.Name = "gcSymbolsName";
            this.gcSymbolsName.Visible = true;
            this.gcSymbolsName.VisibleIndex = 0;
            // 
            // gcSymbolsSRAM
            // 
            this.gcSymbolsSRAM.Caption = "SRAM address";
            this.gcSymbolsSRAM.DisplayFormat.FormatString = "{0:X4}";
            this.gcSymbolsSRAM.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gcSymbolsSRAM.FieldName = "SRAMADDRESS";
            this.gcSymbolsSRAM.Name = "gcSymbolsSRAM";
            this.gcSymbolsSRAM.Visible = true;
            this.gcSymbolsSRAM.VisibleIndex = 1;
            // 
            // gcSymbolsFlash
            // 
            this.gcSymbolsFlash.Caption = "Flash address";
            this.gcSymbolsFlash.DisplayFormat.FormatString = "{0:X4}";
            this.gcSymbolsFlash.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gcSymbolsFlash.FieldName = "FLASHADDRESS";
            this.gcSymbolsFlash.Name = "gcSymbolsFlash";
            this.gcSymbolsFlash.Visible = true;
            this.gcSymbolsFlash.VisibleIndex = 2;
            // 
            // gcSymbolsLength
            // 
            this.gcSymbolsLength.Caption = "Length (bytes)";
            this.gcSymbolsLength.DisplayFormat.FormatString = "{0:X4}";
            this.gcSymbolsLength.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gcSymbolsLength.FieldName = "LENGTHBYTES";
            this.gcSymbolsLength.Name = "gcSymbolsLength";
            this.gcSymbolsLength.Visible = true;
            this.gcSymbolsLength.VisibleIndex = 3;
            // 
            // gcSymbolsLengthAbsolute
            // 
            this.gcSymbolsLengthAbsolute.Caption = "Length (values)";
            this.gcSymbolsLengthAbsolute.DisplayFormat.FormatString = "{0:X4}";
            this.gcSymbolsLengthAbsolute.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gcSymbolsLengthAbsolute.FieldName = "LENGTHVALUES";
            this.gcSymbolsLengthAbsolute.Name = "gcSymbolsLengthAbsolute";
            // 
            // gcSymbolsDescription
            // 
            this.gcSymbolsDescription.Caption = "Description";
            this.gcSymbolsDescription.FieldName = "DESCRIPTION";
            this.gcSymbolsDescription.Name = "gcSymbolsDescription";
            this.gcSymbolsDescription.Visible = true;
            this.gcSymbolsDescription.VisibleIndex = 4;
            // 
            // gcSymbolsChanged
            // 
            this.gcSymbolsChanged.Caption = "Changed";
            this.gcSymbolsChanged.FieldName = "ISCHANGED";
            this.gcSymbolsChanged.Name = "gcSymbolsChanged";
            this.gcSymbolsChanged.Visible = true;
            this.gcSymbolsChanged.VisibleIndex = 5;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripSeparator3,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(477, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Export to PDF";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Export to excel";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton7.Text = "Filter on/off";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton8.Text = "Grouping on/off";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Column chooser";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Show print preview";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Print symbollist";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Help";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.controlContainer1);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel1.ID = new System.Guid("a85e192e-b0dd-4531-848a-377d8aa96088");
            this.dockPanel1.Location = new System.Drawing.Point(3, 29);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel1.SavedIndex = 1;
            this.dockPanel1.SavedParent = this.dockSymbols;
            this.dockPanel1.SavedTabbed = true;
            this.dockPanel1.Size = new System.Drawing.Size(477, 486);
            // 
            // controlContainer1
            // 
            this.controlContainer1.Controls.Add(this.webBrowserUserManual);
            this.controlContainer1.Location = new System.Drawing.Point(0, 0);
            this.controlContainer1.Name = "controlContainer1";
            this.controlContainer1.Size = new System.Drawing.Size(477, 486);
            this.controlContainer1.TabIndex = 0;
            // 
            // webBrowserUserManual
            // 
            this.webBrowserUserManual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserUserManual.Location = new System.Drawing.Point(0, 0);
            this.webBrowserUserManual.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserUserManual.Name = "webBrowserUserManual";
            this.webBrowserUserManual.Size = new System.Drawing.Size(477, 486);
            this.webBrowserUserManual.TabIndex = 0;
            // 
            // dockPanel2
            // 
            this.dockPanel2.Controls.Add(this.dockPanel2_Container);
            this.dockPanel2.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel2.ID = new System.Guid("f3b4e476-169b-4466-a699-aadd9baf40e8");
            this.dockPanel2.Location = new System.Drawing.Point(3, 29);
            this.dockPanel2.Name = "dockPanel2";
            this.dockPanel2.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel2.SavedIndex = 2;
            this.dockPanel2.SavedParent = this.dockSymbols;
            this.dockPanel2.SavedTabbed = true;
            this.dockPanel2.Size = new System.Drawing.Size(477, 486);
            // 
            // dockPanel2_Container
            // 
            this.dockPanel2_Container.Controls.Add(this.webBrowserDocumentation);
            this.dockPanel2_Container.Location = new System.Drawing.Point(0, 0);
            this.dockPanel2_Container.Name = "dockPanel2_Container";
            this.dockPanel2_Container.Size = new System.Drawing.Size(477, 486);
            this.dockPanel2_Container.TabIndex = 0;
            // 
            // webBrowserDocumentation
            // 
            this.webBrowserDocumentation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserDocumentation.Location = new System.Drawing.Point(0, 0);
            this.webBrowserDocumentation.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserDocumentation.Name = "webBrowserDocumentation";
            this.webBrowserDocumentation.Size = new System.Drawing.Size(477, 486);
            this.webBrowserDocumentation.TabIndex = 0;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonKeyTip = "";
            this.ribbonControl1.ApplicationCaption = "T5SuitePro";
            this.ribbonControl1.ApplicationDocumentCaption = "T5 tuning software";
            this.ribbonControl1.ApplicationIcon = ((System.Drawing.Bitmap)(resources.GetObject("ribbonControl1.ApplicationIcon")));
            this.ribbonControl1.Controller = this.barAndDockingController1;
            this.ribbonControl1.Images = this.imageList1;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonItem7,
            this.barButtonItem8,
            this.barButtonItem9,
            this.barButtonItem10,
            this.barButtonItem11,
            this.barButtonItem12,
            this.barButtonItem13,
            this.barButtonItem14,
            this.barButtonItem16,
            this.barButtonItem20,
            this.barButtonItem23,
            this.barButtonItem24,
            this.barButtonItem25,
            this.barStaticItem1,
            this.barStaticItem2,
            this.barButtonItem26,
            this.barButtonItem15,
            this.barButtonItem17,
            this.barButtonItem19,
            this.barButtonItem27,
            this.barButtonItem28,
            this.barButtonItem29,
            this.barButtonItem30,
            this.barViewInHex,
            this.barButtonItem31,
            this.barButtonItem32,
            this.barButtonItem33,
            this.barOnlyRed,
            this.barButtonItem34,
            this.checkVSSEnable,
            this.barShowGraph,
            this.barAutoChecksum,
            this.barSRAMDumpImport,
            this.barEngineEmulator,
            this.barT5Docu,
            this.barUserManual,
            this.barShowGraphs,
            this.barMaximise,
            this.barButtonItem18,
            this.barButtonItem21,
            this.barCheckSymbolWindow,
            this.barEditSymbollist,
            this.barButtonItem22,
            this.barButtonItem35,
            this.barButtonItem36,
            this.barButtonItem37,
            this.barEditItem1,
            this.barButtonItem38,
            this.barButtonItem40,
            this.barButtonItem41,
            this.barButtonItem42,
            this.barButtonItem43,
            this.barButtonItem44,
            this.barButtonItem45,
            this.barButtonItem39,
            this.barButtonItem46,
            this.barStaticItem3,
            this.barButtonItem47,
            this.barButtonItem48,
            this.barButtonItem49,
            this.barButtonItem50,
            this.barButtonItem51,
            this.barButtonItem52,
            this.barButtonItem53,
            this.barButtonItem54});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 85;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPageFile,
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.repositoryItemMRUEdit1,
            this.repositoryItemLookUpEdit2});
            this.ribbonControl1.SelectedPage = this.ribbonPage4;
            this.ribbonControl1.Size = new System.Drawing.Size(1272, 144);
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            this.ribbonControl1.Click += new System.EventHandler(this.ribbonControl1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "shield_warning.ico");
            this.imageList1.Images.SetKeyName(1, "shield_help.ico");
            this.imageList1.Images.SetKeyName(2, "shield_off.ico");
            this.imageList1.Images.SetKeyName(3, "shield_ok.ico");
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Open";
            this.barButtonItem1.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem1.Glyph")));
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.Name = "barButtonItem1";
            toolTipTitleItem36.Text = "Open file";
            toolTipItem33.LeftIndent = 6;
            toolTipItem33.Text = "Lets you select a binary that you want to view and examine.";
            superToolTip33.Items.Add(toolTipTitleItem36);
            superToolTip33.Items.Add(toolTipItem33);
            this.barButtonItem1.SuperTip = superToolTip33;
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Save";
            this.barButtonItem2.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.Glyph")));
            this.barButtonItem2.Id = 1;
            this.barButtonItem2.Name = "barButtonItem2";
            toolTipTitleItem37.Text = "Save all";
            toolTipItem34.LeftIndent = 6;
            toolTipItem34.Text = "Lets you save all pending changes to the binary in one click";
            superToolTip34.Items.Add(toolTipTitleItem37);
            superToolTip34.Items.Add(toolTipItem34);
            this.barButtonItem2.SuperTip = superToolTip34;
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Save as...";
            this.barButtonItem3.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem3.Glyph")));
            this.barButtonItem3.Id = 2;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "Export to XDF";
            this.barButtonItem4.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem4.Glyph")));
            this.barButtonItem4.Id = 3;
            this.barButtonItem4.Name = "barButtonItem4";
            toolTipTitleItem38.Text = "Export to XDF";
            toolTipItem35.LeftIndent = 6;
            toolTipItem35.Text = "Exports an XDF file that may be used with the freeware tuning software \"TunerPro\"" +
                ".";
            superToolTip35.Items.Add(toolTipTitleItem38);
            superToolTip35.Items.Add(toolTipItem35);
            this.barButtonItem4.SuperTip = superToolTip35;
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "Export to S19";
            this.barButtonItem5.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem5.Glyph")));
            this.barButtonItem5.Id = 4;
            this.barButtonItem5.Name = "barButtonItem5";
            toolTipTitleItem39.Text = "Export to S19";
            toolTipItem36.LeftIndent = 6;
            toolTipItem36.Text = "Exports the selected binary in motorola S19 format. Some programmers only accept " +
                "S19 format in stead of binary format.";
            superToolTip36.Items.Add(toolTipTitleItem39);
            superToolTip36.Items.Add(toolTipItem36);
            this.barButtonItem5.SuperTip = superToolTip36;
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "Exit";
            this.barButtonItem6.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem6.Glyph")));
            this.barButtonItem6.Id = 5;
            this.barButtonItem6.Name = "barButtonItem6";
            toolTipTitleItem40.Text = "Exit";
            toolTipItem37.LeftIndent = 6;
            toolTipItem37.Text = "What do you think?";
            superToolTip37.Items.Add(toolTipTitleItem40);
            superToolTip37.Items.Add(toolTipItem37);
            this.barButtonItem6.SuperTip = superToolTip37;
            this.barButtonItem6.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem6_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "File information";
            this.barButtonItem7.Enabled = false;
            this.barButtonItem7.Id = 6;
            this.barButtonItem7.Name = "barButtonItem7";
            this.barButtonItem7.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem7_ItemClick);
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "Create backup file";
            this.barButtonItem8.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem8.Glyph")));
            this.barButtonItem8.Id = 7;
            this.barButtonItem8.Name = "barButtonItem8";
            toolTipTitleItem41.Text = "Create backup file";
            toolTipItem38.LeftIndent = 6;
            toolTipItem38.Text = "Creates a binary backup from the opened file.\r\nYou may create a backup before you" +
                " start working on a new map for instance.";
            superToolTip38.Items.Add(toolTipTitleItem41);
            superToolTip38.Items.Add(toolTipItem38);
            this.barButtonItem8.SuperTip = superToolTip38;
            this.barButtonItem8.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem8_ItemClick);
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "Restore backup file";
            this.barButtonItem9.Enabled = false;
            this.barButtonItem9.Id = 8;
            this.barButtonItem9.Name = "barButtonItem9";
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "Compare maps with other binary";
            this.barButtonItem10.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem10.Glyph")));
            this.barButtonItem10.Id = 9;
            this.barButtonItem10.Name = "barButtonItem10";
            toolTipTitleItem42.Text = "Compare maps with other binary";
            toolTipItem39.LeftIndent = 6;
            toolTipItem39.Text = "This option lets you compare all symbols in the currently opened firmware to symb" +
                "ols in another binary. It first lets you select the other bin-file.";
            superToolTip39.Items.Add(toolTipTitleItem42);
            superToolTip39.Items.Add(toolTipItem39);
            this.barButtonItem10.SuperTip = superToolTip39;
            this.barButtonItem10.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem10_ItemClick);
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "Analyze binary";
            this.barButtonItem11.Enabled = false;
            this.barButtonItem11.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem11.Glyph")));
            this.barButtonItem11.Id = 10;
            this.barButtonItem11.Name = "barButtonItem11";
            this.barButtonItem11.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem11.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem11_ItemClick);
            // 
            // barButtonItem12
            // 
            this.barButtonItem12.Caption = "Merge binaries";
            this.barButtonItem12.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem12.Glyph")));
            this.barButtonItem12.Id = 11;
            this.barButtonItem12.Name = "barButtonItem12";
            this.barButtonItem12.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem12_ItemClick);
            // 
            // barButtonItem13
            // 
            this.barButtonItem13.Caption = "Split binary";
            this.barButtonItem13.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem13.Glyph")));
            this.barButtonItem13.Id = 12;
            this.barButtonItem13.Name = "barButtonItem13";
            this.barButtonItem13.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem13_ItemClick);
            // 
            // barButtonItem14
            // 
            this.barButtonItem14.Caption = "Extract symbol table";
            this.barButtonItem14.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem14.Glyph")));
            this.barButtonItem14.Id = 13;
            this.barButtonItem14.Name = "barButtonItem14";
            this.barButtonItem14.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem14_ItemClick);
            // 
            // barButtonItem16
            // 
            this.barButtonItem16.Caption = "Box number";
            this.barButtonItem16.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem16.Glyph")));
            this.barButtonItem16.Id = 15;
            this.barButtonItem16.Name = "barButtonItem16";
            toolTipTitleItem43.Text = "Box number";
            toolTipItem40.LeftIndent = 6;
            toolTipItem40.Text = "Lets you alter the boxnumber within the selected binary.";
            superToolTip40.Items.Add(toolTipTitleItem43);
            superToolTip40.Items.Add(toolTipItem40);
            this.barButtonItem16.SuperTip = superToolTip40;
            this.barButtonItem16.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem16_ItemClick);
            // 
            // barButtonItem20
            // 
            this.barButtonItem20.Caption = "Verify checksum";
            this.barButtonItem20.Id = 19;
            this.barButtonItem20.ImageIndex = 1;
            this.barButtonItem20.Name = "barButtonItem20";
            toolTipTitleItem44.Text = "Verify checksum";
            toolTipItem41.LeftIndent = 6;
            toolTipItem41.Text = "Verifies the checkum in the selected binary. Lets you know if checksum is correct" +
                " or not.";
            superToolTip41.Items.Add(toolTipTitleItem44);
            superToolTip41.Items.Add(toolTipItem41);
            this.barButtonItem20.SuperTip = superToolTip41;
            this.barButtonItem20.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem20_ItemClick);
            // 
            // barButtonItem23
            // 
            this.barButtonItem23.Caption = "Set VSS code";
            this.barButtonItem23.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem23.Glyph")));
            this.barButtonItem23.Id = 22;
            this.barButtonItem23.Name = "barButtonItem23";
            toolTipTitleItem45.Text = "Set VSS code";
            toolTipItem42.LeftIndent = 6;
            toolTipItem42.Text = "Lets you enter a VSS code. This code is only used when VSS Enable is checked.";
            superToolTip42.Items.Add(toolTipTitleItem45);
            superToolTip42.Items.Add(toolTipItem42);
            this.barButtonItem23.SuperTip = superToolTip42;
            this.barButtonItem23.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem23_ItemClick);
            // 
            // barButtonItem24
            // 
            this.barButtonItem24.Caption = "Software ID";
            this.barButtonItem24.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem24.Glyph")));
            this.barButtonItem24.Id = 23;
            this.barButtonItem24.Name = "barButtonItem24";
            toolTipTitleItem46.Text = "Software ID";
            toolTipItem43.LeftIndent = 6;
            toolTipItem43.Text = "Lets you alter the software ID within the selected binary.";
            superToolTip43.Items.Add(toolTipTitleItem46);
            superToolTip43.Items.Add(toolTipItem43);
            this.barButtonItem24.SuperTip = superToolTip43;
            this.barButtonItem24.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem24_ItemClick);
            // 
            // barButtonItem25
            // 
            this.barButtonItem25.Caption = "File comments";
            this.barButtonItem25.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem25.Glyph")));
            this.barButtonItem25.Id = 24;
            this.barButtonItem25.Name = "barButtonItem25";
            toolTipTitleItem47.Text = "File comments";
            toolTipItem44.LeftIndent = 6;
            toolTipItem44.Text = "Lets you alter the textual file comments within the selected binary.";
            superToolTip44.Items.Add(toolTipTitleItem47);
            superToolTip44.Items.Add(toolTipItem44);
            this.barButtonItem25.SuperTip = superToolTip44;
            this.barButtonItem25.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem25_ItemClick);
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Id = 25;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Id = 26;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barButtonItem26
            // 
            this.barButtonItem26.Caption = "Export map to excel";
            this.barButtonItem26.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem26.Glyph")));
            this.barButtonItem26.Id = 27;
            this.barButtonItem26.Name = "barButtonItem26";
            toolTipTitleItem48.Text = "Export map to Excel";
            toolTipItem45.LeftIndent = 6;
            toolTipItem45.Text = "Exports this map this excel and shows a 3D surface graph for it.";
            superToolTip45.Items.Add(toolTipTitleItem48);
            superToolTip45.Items.Add(toolTipItem45);
            this.barButtonItem26.SuperTip = superToolTip45;
            this.barButtonItem26.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem26_ItemClick);
            // 
            // barButtonItem15
            // 
            this.barButtonItem15.Caption = "Main ignition map";
            this.barButtonItem15.Id = 28;
            this.barButtonItem15.Name = "barButtonItem15";
            toolTipTitleItem49.Text = "Main ignition map";
            toolTipItem46.LeftIndent = 6;
            toolTipItem46.Text = "Starts the editor for the main ignition map.";
            superToolTip46.Items.Add(toolTipTitleItem49);
            superToolTip46.Items.Add(toolTipItem46);
            this.barButtonItem15.SuperTip = superToolTip46;
            this.barButtonItem15.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem15_ItemClick_1);
            // 
            // barButtonItem17
            // 
            this.barButtonItem17.Caption = "Knocking ignition";
            this.barButtonItem17.Id = 29;
            this.barButtonItem17.Name = "barButtonItem17";
            toolTipTitleItem50.Text = "Knocking ignition";
            toolTipItem47.LeftIndent = 6;
            toolTipItem47.Text = "Starts the editor for the knocking control ignition map";
            superToolTip47.Items.Add(toolTipTitleItem50);
            superToolTip47.Items.Add(toolTipItem47);
            this.barButtonItem17.SuperTip = superToolTip47;
            this.barButtonItem17.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem17_ItemClick_1);
            // 
            // barButtonItem19
            // 
            this.barButtonItem19.Caption = "Boost request map";
            this.barButtonItem19.Id = 30;
            this.barButtonItem19.Name = "barButtonItem19";
            toolTipTitleItem51.Text = "Boost request map for manual transmission";
            toolTipItem48.LeftIndent = 6;
            toolTipItem48.Text = "Starts the editor for the turbo boost request map for cars with a manual transmis" +
                "sion\r\n";
            superToolTip48.Items.Add(toolTipTitleItem51);
            superToolTip48.Items.Add(toolTipItem48);
            this.barButtonItem19.SuperTip = superToolTip48;
            this.barButtonItem19.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem19_ItemClick_1);
            // 
            // barButtonItem27
            // 
            this.barButtonItem27.Caption = "Fuel cut map";
            this.barButtonItem27.Id = 31;
            this.barButtonItem27.Name = "barButtonItem27";
            toolTipTitleItem52.Text = "Fuel cut map";
            toolTipItem49.LeftIndent = 6;
            toolTipItem49.Text = "Starts the editor for the boost limit map\r\n";
            superToolTip49.Items.Add(toolTipTitleItem52);
            superToolTip49.Items.Add(toolTipItem49);
            this.barButtonItem27.SuperTip = superToolTip49;
            this.barButtonItem27.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem27_ItemClick);
            // 
            // barButtonItem28
            // 
            this.barButtonItem28.Caption = "First gear limiter";
            this.barButtonItem28.Id = 32;
            this.barButtonItem28.Name = "barButtonItem28";
            toolTipTitleItem53.Text = "First gear limiter";
            toolTipItem50.LeftIndent = 6;
            toolTipItem50.Text = "Starts the editor for the boost limiter map for cars with a manual transmission (" +
                "boost is reduced to save the gearbox). This map limits boost for first gear";
            superToolTip50.Items.Add(toolTipTitleItem53);
            superToolTip50.Items.Add(toolTipItem50);
            this.barButtonItem28.SuperTip = superToolTip50;
            this.barButtonItem28.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem28_ItemClick);
            // 
            // barButtonItem29
            // 
            this.barButtonItem29.Caption = "Second gear limiter";
            this.barButtonItem29.Id = 33;
            this.barButtonItem29.Name = "barButtonItem29";
            toolTipTitleItem54.Text = "Second gear limiter";
            toolTipItem51.LeftIndent = 6;
            toolTipItem51.Text = "Starts the editor for the boost limiter map for cars with a manual transmission (" +
                "boost is reduced to save the gearbox). This map limits boost for second gear";
            superToolTip51.Items.Add(toolTipTitleItem54);
            superToolTip51.Items.Add(toolTipItem51);
            this.barButtonItem29.SuperTip = superToolTip51;
            this.barButtonItem29.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem29_ItemClick);
            // 
            // barButtonItem30
            // 
            this.barButtonItem30.Caption = "Main fuel injection map";
            this.barButtonItem30.Id = 34;
            this.barButtonItem30.Name = "barButtonItem30";
            toolTipTitleItem55.Text = "Main fuel injection map";
            toolTipItem52.LeftIndent = 6;
            toolTipItem52.Text = "Starts the editor for the main fuel injection map";
            superToolTip52.Items.Add(toolTipTitleItem55);
            superToolTip52.Items.Add(toolTipItem52);
            this.barButtonItem30.SuperTip = superToolTip52;
            this.barButtonItem30.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem30_ItemClick);
            // 
            // barViewInHex
            // 
            this.barViewInHex.Caption = "View tables in hex";
            this.barViewInHex.Checked = true;
            this.barViewInHex.Glyph = ((System.Drawing.Image)(resources.GetObject("barViewInHex.Glyph")));
            this.barViewInHex.Id = 35;
            this.barViewInHex.Name = "barViewInHex";
            toolTipTitleItem56.Text = "View tables in hex";
            toolTipItem53.LeftIndent = 6;
            toolTipItem53.Text = "When checked all displayed tables are showed in hexadecimal format. If unchecked " +
                "shows them in decimal format.";
            superToolTip53.Items.Add(toolTipTitleItem56);
            superToolTip53.Items.Add(toolTipItem53);
            this.barViewInHex.SuperTip = superToolTip53;
            this.barViewInHex.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barViewInHex_CheckedChanged);
            // 
            // barButtonItem31
            // 
            this.barButtonItem31.Caption = "Set parameters";
            this.barButtonItem31.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem31.Glyph")));
            this.barButtonItem31.Id = 36;
            this.barButtonItem31.Name = "barButtonItem31";
            toolTipTitleItem57.Text = "Set parameters ";
            toolTipItem54.LeftIndent = 6;
            toolTipItem54.Text = "Lets you select the relevant parameters for using the PE micro programmer to inte" +
                "rface with your ECU.\r\n";
            toolTipTitleItem58.LeftIndent = 6;
            toolTipTitleItem58.Text = "PE micro interface\r\n";
            superToolTip54.Items.Add(toolTipTitleItem57);
            superToolTip54.Items.Add(toolTipItem54);
            superToolTip54.Items.Add(toolTipSeparatorItem4);
            superToolTip54.Items.Add(toolTipTitleItem58);
            this.barButtonItem31.SuperTip = superToolTip54;
            this.barButtonItem31.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem31_ItemClick);
            // 
            // barButtonItem32
            // 
            this.barButtonItem32.Caption = "Program ECU";
            this.barButtonItem32.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem32.Glyph")));
            this.barButtonItem32.Id = 37;
            this.barButtonItem32.Name = "barButtonItem32";
            toolTipTitleItem59.Text = "Program ECU";
            toolTipItem55.LeftIndent = 6;
            toolTipItem55.Text = "Lets you write the opened binary to the ECU, provided you\'ve entered all the rele" +
                "vant options in \"Set parameters\".";
            toolTipTitleItem60.LeftIndent = 6;
            toolTipTitleItem60.Text = "PE micro interface\r\n";
            superToolTip55.Items.Add(toolTipTitleItem59);
            superToolTip55.Items.Add(toolTipItem55);
            superToolTip55.Items.Add(toolTipSeparatorItem5);
            superToolTip55.Items.Add(toolTipTitleItem60);
            this.barButtonItem32.SuperTip = superToolTip55;
            this.barButtonItem32.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem32_ItemClick);
            // 
            // barButtonItem33
            // 
            this.barButtonItem33.Caption = "Read ECU";
            this.barButtonItem33.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem33.Glyph")));
            this.barButtonItem33.Id = 38;
            this.barButtonItem33.Name = "barButtonItem33";
            toolTipTitleItem61.Text = "Read ECU";
            toolTipItem56.LeftIndent = 6;
            toolTipItem56.Text = "Lets you read a binary from the ECU, provided you\'ve entered all the relevant opt" +
                "ions in \"Set parameters\".";
            toolTipTitleItem62.LeftIndent = 6;
            toolTipTitleItem62.Text = "PE micro interface\r\n";
            superToolTip56.Items.Add(toolTipTitleItem61);
            superToolTip56.Items.Add(toolTipItem56);
            superToolTip56.Items.Add(toolTipSeparatorItem6);
            superToolTip56.Items.Add(toolTipTitleItem62);
            this.barButtonItem33.SuperTip = superToolTip56;
            this.barButtonItem33.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem33_ItemClick);
            // 
            // barOnlyRed
            // 
            this.barOnlyRed.Caption = "Show red && white maps";
            this.barOnlyRed.Glyph = ((System.Drawing.Image)(resources.GetObject("barOnlyRed.Glyph")));
            this.barOnlyRed.Id = 39;
            this.barOnlyRed.Name = "barOnlyRed";
            toolTipTitleItem63.Text = "Show red && white maps";
            toolTipItem57.LeftIndent = 6;
            toolTipItem57.Text = "If checked, shows all maps in the editor in only red and white colors. If uncheck" +
                "ed, shows maps in the editor in green and red.";
            superToolTip57.Items.Add(toolTipTitleItem63);
            superToolTip57.Items.Add(toolTipItem57);
            this.barOnlyRed.SuperTip = superToolTip57;
            this.barOnlyRed.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barOnlyRed_CheckedChanged);
            // 
            // barButtonItem34
            // 
            this.barButtonItem34.Caption = "Import map from excel";
            this.barButtonItem34.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem34.Glyph")));
            this.barButtonItem34.Id = 40;
            this.barButtonItem34.Name = "barButtonItem34";
            toolTipTitleItem64.Text = "Import map from Excel";
            toolTipItem58.LeftIndent = 6;
            toolTipItem58.Text = "Imports a map from excel that has been exported earlier. Values may have changed," +
                " format may not!";
            superToolTip58.Items.Add(toolTipTitleItem64);
            superToolTip58.Items.Add(toolTipItem58);
            this.barButtonItem34.SuperTip = superToolTip58;
            this.barButtonItem34.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem34_ItemClick);
            // 
            // checkVSSEnable
            // 
            this.checkVSSEnable.Caption = "VSS Enable";
            this.checkVSSEnable.Glyph = ((System.Drawing.Image)(resources.GetObject("checkVSSEnable.Glyph")));
            this.checkVSSEnable.Id = 41;
            this.checkVSSEnable.Name = "checkVSSEnable";
            toolTipTitleItem65.Text = "VSS Enable";
            toolTipItem59.LeftIndent = 6;
            toolTipItem59.Text = "Lets you enable (checked) or disable (unchecked) the Vehicle Security System opti" +
                "on in the selected binary.\r\n";
            superToolTip59.Items.Add(toolTipTitleItem65);
            superToolTip59.Items.Add(toolTipItem59);
            this.checkVSSEnable.SuperTip = superToolTip59;
            this.checkVSSEnable.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.checkVSSEnable_CheckedChanged);
            // 
            // barShowGraph
            // 
            this.barShowGraph.Caption = "Show 3D graph";
            this.barShowGraph.Glyph = ((System.Drawing.Image)(resources.GetObject("barShowGraph.Glyph")));
            this.barShowGraph.Id = 42;
            this.barShowGraph.Name = "barShowGraph";
            toolTipTitleItem66.Text = "Show a 3D graph ";
            toolTipItem60.LeftIndent = 6;
            toolTipItem60.Text = "Show the currently selected table in a 3D surface graph.";
            superToolTip60.Items.Add(toolTipTitleItem66);
            superToolTip60.Items.Add(toolTipItem60);
            this.barShowGraph.SuperTip = superToolTip60;
            this.barShowGraph.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barShowGraph_ItemClick);
            // 
            // barAutoChecksum
            // 
            this.barAutoChecksum.Caption = "Auto update checksum";
            this.barAutoChecksum.Checked = true;
            this.barAutoChecksum.Glyph = ((System.Drawing.Image)(resources.GetObject("barAutoChecksum.Glyph")));
            this.barAutoChecksum.Id = 43;
            this.barAutoChecksum.Name = "barAutoChecksum";
            toolTipTitleItem67.Text = "Auto update checksum";
            toolTipItem61.LeftIndent = 6;
            toolTipItem61.Text = "If checked T5SuitePro automatically updates the checksum for the selected binary " +
                "whenever you change the contents.";
            superToolTip61.Items.Add(toolTipTitleItem67);
            superToolTip61.Items.Add(toolTipItem61);
            this.barAutoChecksum.SuperTip = superToolTip61;
            this.barAutoChecksum.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barAutoChecksum_CheckedChanged);
            // 
            // barSRAMDumpImport
            // 
            this.barSRAMDumpImport.Caption = "Import SRAM dump";
            this.barSRAMDumpImport.Glyph = ((System.Drawing.Image)(resources.GetObject("barSRAMDumpImport.Glyph")));
            this.barSRAMDumpImport.Id = 44;
            this.barSRAMDumpImport.Name = "barSRAMDumpImport";
            this.barSRAMDumpImport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSRAMDumpImport_ItemClick);
            // 
            // barEngineEmulator
            // 
            this.barEngineEmulator.Caption = "Run engine emulator";
            this.barEngineEmulator.Enabled = false;
            this.barEngineEmulator.Glyph = ((System.Drawing.Image)(resources.GetObject("barEngineEmulator.Glyph")));
            this.barEngineEmulator.Id = 45;
            this.barEngineEmulator.Name = "barEngineEmulator";
            this.barEngineEmulator.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barEngineEmulator_ItemClick);
            // 
            // barT5Docu
            // 
            this.barT5Docu.Caption = "T5 Documentation";
            this.barT5Docu.Glyph = ((System.Drawing.Image)(resources.GetObject("barT5Docu.Glyph")));
            this.barT5Docu.Id = 46;
            this.barT5Docu.Name = "barT5Docu";
            this.barT5Docu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barT5Docu_ItemClick);
            // 
            // barUserManual
            // 
            this.barUserManual.Caption = "User manual";
            this.barUserManual.Glyph = ((System.Drawing.Image)(resources.GetObject("barUserManual.Glyph")));
            this.barUserManual.Id = 47;
            this.barUserManual.Name = "barUserManual";
            this.barUserManual.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barUserManual_ItemClick);
            // 
            // barShowGraphs
            // 
            this.barShowGraphs.Caption = "Show graphs in viewer";
            this.barShowGraphs.Checked = true;
            this.barShowGraphs.Glyph = ((System.Drawing.Image)(resources.GetObject("barShowGraphs.Glyph")));
            this.barShowGraphs.Id = 49;
            this.barShowGraphs.Name = "barShowGraphs";
            this.barShowGraphs.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barShowGraphs_CheckedChanged);
            // 
            // barMaximise
            // 
            this.barMaximise.Caption = "Toggle fullscreen";
            this.barMaximise.Glyph = ((System.Drawing.Image)(resources.GetObject("barMaximise.Glyph")));
            this.barMaximise.Id = 50;
            this.barMaximise.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F12);
            this.barMaximise.Name = "barMaximise";
            this.barMaximise.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barMaximise_ItemClick);
            // 
            // barButtonItem18
            // 
            this.barButtonItem18.Caption = "Firmware info";
            this.barButtonItem18.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem18.Glyph")));
            this.barButtonItem18.Id = 51;
            this.barButtonItem18.Name = "barButtonItem18";
            this.barButtonItem18.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem18_ItemClick_1);
            // 
            // barButtonItem21
            // 
            this.barButtonItem21.Caption = "Realtime view";
            this.barButtonItem21.Id = 52;
            this.barButtonItem21.Name = "barButtonItem21";
            this.barButtonItem21.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem21_ItemClick_1);
            // 
            // barCheckSymbolWindow
            // 
            this.barCheckSymbolWindow.Caption = "Hide symbol window";
            this.barCheckSymbolWindow.Glyph = ((System.Drawing.Image)(resources.GetObject("barCheckSymbolWindow.Glyph")));
            this.barCheckSymbolWindow.Id = 54;
            this.barCheckSymbolWindow.Name = "barCheckSymbolWindow";
            this.barCheckSymbolWindow.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckSymbolWindow_CheckedChanged);
            // 
            // barEditSymbollist
            // 
            this.barEditSymbollist.Edit = this.repositoryItemLookUpEdit1;
            this.barEditSymbollist.Id = 55;
            this.barEditSymbollist.Name = "barEditSymbollist";
            this.barEditSymbollist.Width = 150;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Right, "Start symbol viewer")});
            this.repositoryItemLookUpEdit1.DropDownRows = 20;
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "select a symbol to edit";
            this.repositoryItemLookUpEdit1.PopupWidth = 350;
            this.repositoryItemLookUpEdit1.ValueMember = "SYMBOLNAME";
            this.repositoryItemLookUpEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemLookUpEdit1_ButtonClick);
            // 
            // barButtonItem22
            // 
            this.barButtonItem22.Caption = "barButtonItem22";
            this.barButtonItem22.Id = 57;
            this.barButtonItem22.Name = "barButtonItem22";
            // 
            // barButtonItem35
            // 
            this.barButtonItem35.Caption = "P of PID (manual)";
            this.barButtonItem35.Id = 59;
            this.barButtonItem35.Name = "barButtonItem35";
            this.barButtonItem35.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem35_ItemClick);
            // 
            // barButtonItem36
            // 
            this.barButtonItem36.Caption = "I of PID (manual)";
            this.barButtonItem36.Id = 60;
            this.barButtonItem36.Name = "barButtonItem36";
            this.barButtonItem36.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem36_ItemClick);
            // 
            // barButtonItem37
            // 
            this.barButtonItem37.Caption = "D of PID (manual)";
            this.barButtonItem37.Id = 61;
            this.barButtonItem37.Name = "barButtonItem37";
            this.barButtonItem37.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem37_ItemClick);
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "Recent";
            this.barEditItem1.Edit = this.repositoryItemLookUpEdit2;
            this.barEditItem1.Id = 63;
            this.barEditItem1.Name = "barEditItem1";
            this.barEditItem1.ShowingEditor += new DevExpress.XtraBars.ItemCancelEventHandler(this.barEditItem1_ShowingEditor);
            this.barEditItem1.EditValueChanged += new System.EventHandler(this.barEditItem1_EditValueChanged);
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("FILENAME", "Filename", 150),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("FULLPATH", "Path", 250)});
            this.repositoryItemLookUpEdit2.DisplayMember = "FILENAME";
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "...";
            this.repositoryItemLookUpEdit2.PopupWidth = 400;
            this.repositoryItemLookUpEdit2.ValueMember = "FULLPATH";
            // 
            // barButtonItem38
            // 
            this.barButtonItem38.Caption = "Boost request map";
            this.barButtonItem38.Id = 64;
            this.barButtonItem38.Name = "barButtonItem38";
            toolTipTitleItem68.Text = "Boost request map for automatic transmission";
            toolTipItem62.LeftIndent = 6;
            toolTipItem62.Text = "Starts the editor for the turbo boost request map for cars with a automatic trans" +
                "mission\r\n";
            superToolTip62.Items.Add(toolTipTitleItem68);
            superToolTip62.Items.Add(toolTipItem62);
            this.barButtonItem38.SuperTip = superToolTip62;
            this.barButtonItem38.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem38_ItemClick);
            // 
            // barButtonItem40
            // 
            this.barButtonItem40.Caption = "First gear limiter";
            this.barButtonItem40.Id = 66;
            this.barButtonItem40.Name = "barButtonItem40";
            toolTipTitleItem69.Text = "First gear limiter";
            toolTipItem63.LeftIndent = 6;
            toolTipItem63.Text = "Starts the editor for the boost limiter map for cars with a automatic transmissio" +
                "n (boost is reduced to save the gearbox). This map limits boost for first gear";
            superToolTip63.Items.Add(toolTipTitleItem69);
            superToolTip63.Items.Add(toolTipItem63);
            this.barButtonItem40.SuperTip = superToolTip63;
            this.barButtonItem40.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem40_ItemClick);
            // 
            // barButtonItem41
            // 
            this.barButtonItem41.Caption = "P of PID (auto)";
            this.barButtonItem41.Id = 67;
            this.barButtonItem41.Name = "barButtonItem41";
            this.barButtonItem41.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem41_ItemClick);
            // 
            // barButtonItem42
            // 
            this.barButtonItem42.Caption = "I of PID (auto)";
            this.barButtonItem42.Id = 68;
            this.barButtonItem42.Name = "barButtonItem42";
            this.barButtonItem42.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem42_ItemClick);
            // 
            // barButtonItem43
            // 
            this.barButtonItem43.Caption = "D of PID (auto)";
            this.barButtonItem43.Id = 69;
            this.barButtonItem43.Name = "barButtonItem43";
            this.barButtonItem43.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem43_ItemClick);
            // 
            // barButtonItem44
            // 
            this.barButtonItem44.Caption = "Test BDM interface";
            this.barButtonItem44.Id = 70;
            this.barButtonItem44.Name = "barButtonItem44";
            this.barButtonItem44.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem44_ItemClick);
            // 
            // barButtonItem45
            // 
            this.barButtonItem45.Caption = "Fuel knock map";
            this.barButtonItem45.Id = 71;
            this.barButtonItem45.Name = "barButtonItem45";
            toolTipTitleItem70.Text = "Fuel knock map";
            toolTipItem64.LeftIndent = 6;
            toolTipItem64.Text = "Starts the editor for the fuel knocking adaption map\r\n";
            superToolTip64.Items.Add(toolTipTitleItem70);
            superToolTip64.Items.Add(toolTipItem64);
            this.barButtonItem45.SuperTip = superToolTip64;
            this.barButtonItem45.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem45_ItemClick);
            // 
            // barButtonItem39
            // 
            this.barButtonItem39.Caption = "Reg kon mat (manual)";
            this.barButtonItem39.Id = 72;
            this.barButtonItem39.Name = "barButtonItem39";
            this.barButtonItem39.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem39_ItemClick_1);
            // 
            // barButtonItem46
            // 
            this.barButtonItem46.Caption = "Reg kon mat (auto)";
            this.barButtonItem46.Id = 73;
            this.barButtonItem46.Name = "barButtonItem46";
            this.barButtonItem46.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem46_ItemClick);
            // 
            // barStaticItem3
            // 
            this.barStaticItem3.Id = 74;
            this.barStaticItem3.Name = "barStaticItem3";
            this.barStaticItem3.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barButtonItem47
            // 
            this.barButtonItem47.Caption = "Easy tune to stage I";
            this.barButtonItem47.Id = 75;
            this.barButtonItem47.Name = "barButtonItem47";
            this.barButtonItem47.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem47_ItemClick);
            // 
            // barButtonItem48
            // 
            this.barButtonItem48.Caption = "Easy tune to stage II";
            this.barButtonItem48.Enabled = false;
            this.barButtonItem48.Id = 76;
            this.barButtonItem48.Name = "barButtonItem48";
            this.barButtonItem48.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem48_ItemClick);
            // 
            // barButtonItem49
            // 
            this.barButtonItem49.Caption = "Easy tune to stage III";
            this.barButtonItem49.Enabled = false;
            this.barButtonItem49.Id = 77;
            this.barButtonItem49.Name = "barButtonItem49";
            this.barButtonItem49.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem49_ItemClick);
            // 
            // barButtonItem50
            // 
            this.barButtonItem50.Caption = "Tune to stage X";
            this.barButtonItem50.Enabled = false;
            this.barButtonItem50.Id = 78;
            this.barButtonItem50.Name = "barButtonItem50";
            this.barButtonItem50.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem50_ItemClick);
            // 
            // barButtonItem51
            // 
            this.barButtonItem51.Caption = "About T5Suite";
            this.barButtonItem51.Id = 81;
            this.barButtonItem51.Name = "barButtonItem51";
            this.barButtonItem51.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem51_ItemClick);
            // 
            // barButtonItem52
            // 
            this.barButtonItem52.Caption = "Check for updates";
            this.barButtonItem52.Id = 82;
            this.barButtonItem52.Name = "barButtonItem52";
            this.barButtonItem52.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem52_ItemClick);
            // 
            // barButtonItem53
            // 
            this.barButtonItem53.Caption = "View file in Hex";
            this.barButtonItem53.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem53.Glyph")));
            this.barButtonItem53.Id = 83;
            this.barButtonItem53.Name = "barButtonItem53";
            this.barButtonItem53.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem53_ItemClick);
            // 
            // barButtonItem54
            // 
            this.barButtonItem54.Caption = "@Mail for support";
            this.barButtonItem54.Id = 84;
            this.barButtonItem54.Name = "barButtonItem54";
            this.barButtonItem54.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem54_ItemClick);
            // 
            // ribbonPageFile
            // 
            this.ribbonPageFile.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup11});
            this.ribbonPageFile.KeyTip = "";
            this.ribbonPageFile.Name = "ribbonPageFile";
            this.ribbonPageFile.Text = "File";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.barEditItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2, true);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem4, true);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem5);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem6);
            this.ribbonPageGroup2.KeyTip = "";
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "File actions";
            // 
            // ribbonPageGroup11
            // 
            this.ribbonPageGroup11.ItemLinks.Add(this.barButtonItem7);
            this.ribbonPageGroup11.ItemLinks.Add(this.barButtonItem8);
            this.ribbonPageGroup11.ItemLinks.Add(this.barButtonItem9);
            this.ribbonPageGroup11.KeyTip = "";
            this.ribbonPageGroup11.Name = "ribbonPageGroup11";
            this.ribbonPageGroup11.Text = "Misc actions";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3,
            this.ribbonPageGroup4,
            this.ribbonPageGroup5,
            this.ribbonPageGroup6,
            this.ribbonPageGroup14,
            this.ribbonPageGroup15});
            this.ribbonPage1.KeyTip = "";
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Actions";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.AllowTextClipping = false;
            this.ribbonPageGroup3.ItemLinks.Add(this.barButtonItem20);
            this.ribbonPageGroup3.ItemLinks.Add(this.barAutoChecksum);
            this.ribbonPageGroup3.KeyTip = "";
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Checksum";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.AllowTextClipping = false;
            this.ribbonPageGroup4.ItemLinks.Add(this.checkVSSEnable);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem23);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem18);
            this.ribbonPageGroup4.KeyTip = "";
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Information";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.AllowTextClipping = false;
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem25);
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem16);
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem24);
            this.ribbonPageGroup5.KeyTip = "";
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "File information";
            this.ribbonPageGroup5.Visible = false;
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.AllowTextClipping = false;
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem10);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem12);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem13);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem53);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem14);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem26);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem34);
            this.ribbonPageGroup6.ItemLinks.Add(this.barShowGraph);
            this.ribbonPageGroup6.ItemLinks.Add(this.barSRAMDumpImport);
            this.ribbonPageGroup6.ItemLinks.Add(this.barButtonItem11);
            this.ribbonPageGroup6.KeyTip = "";
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Tools";
            // 
            // ribbonPageGroup14
            // 
            this.ribbonPageGroup14.AllowTextClipping = false;
            this.ribbonPageGroup14.ItemLinks.Add(this.barViewInHex);
            this.ribbonPageGroup14.ItemLinks.Add(this.barOnlyRed);
            this.ribbonPageGroup14.ItemLinks.Add(this.barShowGraphs);
            this.ribbonPageGroup14.ItemLinks.Add(this.barMaximise);
            this.ribbonPageGroup14.ItemLinks.Add(this.barCheckSymbolWindow);
            this.ribbonPageGroup14.ItemLinks.Add(this.barEditSymbollist);
            this.ribbonPageGroup14.KeyTip = "";
            this.ribbonPageGroup14.Name = "ribbonPageGroup14";
            this.ribbonPageGroup14.Text = "Options";
            // 
            // ribbonPageGroup15
            // 
            this.ribbonPageGroup15.AllowTextClipping = false;
            this.ribbonPageGroup15.ItemLinks.Add(this.barButtonItem31);
            this.ribbonPageGroup15.ItemLinks.Add(this.barButtonItem32);
            this.ribbonPageGroup15.ItemLinks.Add(this.barButtonItem33);
            this.ribbonPageGroup15.KeyTip = "";
            this.ribbonPageGroup15.Name = "ribbonPageGroup15";
            this.ribbonPageGroup15.Text = "Programmer (PE micro)";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup22,
            this.ribbonPageGroup23,
            this.ribbonPageGroup7,
            this.ribbonPageGroup8,
            this.ribbonPageGroup21,
            this.ribbonPageGroup9,
            this.ribbonPageGroup18,
            this.ribbonPageGroup20,
            this.ribbonPageGroup10,
            this.ribbonPageGroup12});
            this.ribbonPage2.KeyTip = "";
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Tuning";
            // 
            // ribbonPageGroup22
            // 
            this.ribbonPageGroup22.AllowTextClipping = false;
            this.ribbonPageGroup22.ItemLinks.Add(this.barButtonItem47);
            this.ribbonPageGroup22.ItemLinks.Add(this.barButtonItem48);
            this.ribbonPageGroup22.ItemLinks.Add(this.barButtonItem49);
            this.ribbonPageGroup22.KeyTip = "";
            this.ribbonPageGroup22.Name = "ribbonPageGroup22";
            this.ribbonPageGroup22.Text = "Tuning wizards";
            // 
            // ribbonPageGroup23
            // 
            this.ribbonPageGroup23.AllowTextClipping = false;
            this.ribbonPageGroup23.ItemLinks.Add(this.barButtonItem50);
            this.ribbonPageGroup23.KeyTip = "";
            this.ribbonPageGroup23.Name = "ribbonPageGroup23";
            this.ribbonPageGroup23.Text = "Advanced tuning";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.Glyph = ((System.Drawing.Image)(resources.GetObject("ribbonPageGroup7.Glyph")));
            this.ribbonPageGroup7.ItemLinks.Add(this.barButtonItem15);
            this.ribbonPageGroup7.ItemLinks.Add(this.barButtonItem17);
            this.ribbonPageGroup7.KeyTip = "";
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            this.ribbonPageGroup7.Text = "Ignition";
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.Glyph = ((System.Drawing.Image)(resources.GetObject("ribbonPageGroup8.Glyph")));
            this.ribbonPageGroup8.ItemLinks.Add(this.barButtonItem30);
            this.ribbonPageGroup8.ItemLinks.Add(this.barButtonItem45);
            this.ribbonPageGroup8.KeyTip = "";
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "Injection";
            // 
            // ribbonPageGroup21
            // 
            this.ribbonPageGroup21.AllowTextClipping = false;
            this.ribbonPageGroup21.ItemLinks.Add(this.barButtonItem27);
            this.ribbonPageGroup21.KeyTip = "";
            this.ribbonPageGroup21.Name = "ribbonPageGroup21";
            this.ribbonPageGroup21.Text = "General boost control";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.AllowTextClipping = false;
            this.ribbonPageGroup9.ItemLinks.Add(this.barButtonItem19);
            this.ribbonPageGroup9.ItemLinks.Add(this.barButtonItem28);
            this.ribbonPageGroup9.ItemLinks.Add(this.barButtonItem29);
            this.ribbonPageGroup9.KeyTip = "";
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            this.ribbonPageGroup9.Text = "Boost control (Manual)";
            // 
            // ribbonPageGroup18
            // 
            this.ribbonPageGroup18.AllowTextClipping = false;
            this.ribbonPageGroup18.ItemLinks.Add(this.barButtonItem38);
            this.ribbonPageGroup18.ItemLinks.Add(this.barButtonItem40);
            this.ribbonPageGroup18.KeyTip = "";
            this.ribbonPageGroup18.Name = "ribbonPageGroup18";
            this.ribbonPageGroup18.Text = "Boost control (Automatic)";
            // 
            // ribbonPageGroup20
            // 
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem35);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem36);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem37);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem41, true);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem42);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem43);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem39, true);
            this.ribbonPageGroup20.ItemLinks.Add(this.barButtonItem46);
            this.ribbonPageGroup20.KeyTip = "";
            this.ribbonPageGroup20.Name = "ribbonPageGroup20";
            this.ribbonPageGroup20.Text = "Advanced boost control";
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.KeyTip = "";
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "Idle correction";
            this.ribbonPageGroup10.Visible = false;
            // 
            // ribbonPageGroup12
            // 
            this.ribbonPageGroup12.KeyTip = "";
            this.ribbonPageGroup12.Name = "ribbonPageGroup12";
            this.ribbonPageGroup12.Text = "Cold start correction";
            this.ribbonPageGroup12.Visible = false;
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup17,
            this.ribbonPageGroup19,
            this.ribbonPageGroup13});
            this.ribbonPage3.KeyTip = "";
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Realtime";
            this.ribbonPage3.Visible = false;
            // 
            // ribbonPageGroup17
            // 
            this.ribbonPageGroup17.ItemLinks.Add(this.barButtonItem21);
            this.ribbonPageGroup17.KeyTip = "";
            this.ribbonPageGroup17.Name = "ribbonPageGroup17";
            this.ribbonPageGroup17.Text = "Logworks";
            // 
            // ribbonPageGroup19
            // 
            this.ribbonPageGroup19.AllowTextClipping = false;
            this.ribbonPageGroup19.ItemLinks.Add(this.barButtonItem44);
            this.ribbonPageGroup19.KeyTip = "";
            this.ribbonPageGroup19.Name = "ribbonPageGroup19";
            this.ribbonPageGroup19.Text = "Background Debugger";
            // 
            // ribbonPageGroup13
            // 
            this.ribbonPageGroup13.ItemLinks.Add(this.barEngineEmulator);
            this.ribbonPageGroup13.KeyTip = "";
            this.ribbonPageGroup13.Name = "ribbonPageGroup13";
            this.ribbonPageGroup13.Text = "Other";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup24,
            this.ribbonPageGroup25});
            this.ribbonPage4.KeyTip = "";
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Help";
            // 
            // ribbonPageGroup24
            // 
            this.ribbonPageGroup24.ItemLinks.Add(this.barUserManual);
            this.ribbonPageGroup24.ItemLinks.Add(this.barEngineEmulator);
            this.ribbonPageGroup24.ItemLinks.Add(this.barT5Docu);
            this.ribbonPageGroup24.KeyTip = "";
            this.ribbonPageGroup24.Name = "ribbonPageGroup24";
            this.ribbonPageGroup24.Text = "Documentation";
            // 
            // ribbonPageGroup25
            // 
            this.ribbonPageGroup25.AllowTextClipping = false;
            this.ribbonPageGroup25.ItemLinks.Add(this.barButtonItem51);
            this.ribbonPageGroup25.ItemLinks.Add(this.barButtonItem52);
            this.ribbonPageGroup25.ItemLinks.Add(this.barButtonItem54);
            this.ribbonPageGroup25.KeyTip = "";
            this.ribbonPageGroup25.Name = "ribbonPageGroup25";
            this.ribbonPageGroup25.Text = "About";
            // 
            // repositoryItemMRUEdit1
            // 
            this.repositoryItemMRUEdit1.AutoHeight = false;
            this.repositoryItemMRUEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMRUEdit1.Name = "repositoryItemMRUEdit1";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.KeyTip = "";
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.ItemLinks.Add(this.barStaticItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.barStaticItem2);
            this.ribbonStatusBar1.ItemLinks.Add(this.barStaticItem3);
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 923);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(1272, 23);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Binary files|*.bin|Motorola S19 files|*.s19";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "bin";
            this.saveFileDialog1.Filter = "Binary files|*.bin|All files|*.*";
            this.saveFileDialog1.SupportMultiDottedExtensions = true;
            this.saveFileDialog1.Title = "Save binary as...";
            // 
            // defaultLookAndFeel1
            // 
            this.defaultLookAndFeel1.LookAndFeel.SkinName = "Blue";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.Filter = "Excel files|*.xls";
            // 
            // openFileDialog3
            // 
            this.openFileDialog3.Filter = "SRAM dump files|*.RAM";
            // 
            // saveFileDialog2
            // 
            this.saveFileDialog2.DefaultExt = "XDF";
            this.saveFileDialog2.Filter = "XDF Files|*.xdf|All files|*.*";
            this.saveFileDialog2.Title = "Save file to XDF...";
            // 
            // saveFileDialog3
            // 
            this.saveFileDialog3.DefaultExt = "S19";
            this.saveFileDialog3.Filter = "S19 files|*.S19|All files|*.*";
            this.saveFileDialog3.Title = "Save file to S19...";
            // 
            // ribbonPageGroup16
            // 
            this.ribbonPageGroup16.ItemLinks.Add(this.barT5Docu);
            this.ribbonPageGroup16.ItemLinks.Add(this.barUserManual);
            this.ribbonPageGroup16.KeyTip = "";
            this.ribbonPageGroup16.Name = "ribbonPageGroup16";
            this.ribbonPageGroup16.Text = "Help";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1272, 946);
            this.Controls.Add(this.dockSymbols);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "T5SuitePro";
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.dockSymbols.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            this.dockPanel1_Container.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSymbols)).EndInit();
            this.mnuSymbols.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSymbols)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.dockPanel1.ResumeLayout(false);
            this.controlContainer1.ResumeLayout(false);
            this.dockPanel2.ResumeLayout(false);
            this.dockPanel2_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMRUEdit1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarAndDockingController barAndDockingController1;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.Docking.DockPanel dockSymbols;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private DevExpress.XtraGrid.GridControl gridSymbols;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSymbols;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsName;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsSRAM;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsFlash;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsLength;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsLengthAbsolute;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsDescription;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageFile;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup11;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup12;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup13;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private DevExpress.XtraBars.BarButtonItem barButtonItem12;
        private DevExpress.XtraBars.BarButtonItem barButtonItem13;
        private DevExpress.XtraBars.BarButtonItem barButtonItem14;
        private DevExpress.XtraBars.BarButtonItem barButtonItem16;
        private DevExpress.XtraBars.BarButtonItem barButtonItem20;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem23;
        private DevExpress.XtraBars.BarButtonItem barButtonItem24;
        private DevExpress.XtraBars.BarButtonItem barButtonItem25;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.LookAndFeel.DefaultLookAndFeel defaultLookAndFeel1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem26;
        private DevExpress.XtraBars.BarButtonItem barButtonItem15;
        private DevExpress.XtraBars.BarButtonItem barButtonItem17;
        private DevExpress.XtraBars.BarButtonItem barButtonItem19;
        private DevExpress.XtraBars.BarButtonItem barButtonItem27;
        private DevExpress.XtraBars.BarButtonItem barButtonItem28;
        private DevExpress.XtraBars.BarButtonItem barButtonItem29;
        private DevExpress.XtraBars.BarButtonItem barButtonItem30;
        private DevExpress.XtraGrid.Columns.GridColumn gcSymbolsChanged;
        private DevExpress.XtraBars.BarCheckItem barViewInHex;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup14;
        private DevExpress.XtraBars.BarButtonItem barButtonItem31;
        private DevExpress.XtraBars.BarButtonItem barButtonItem32;
        private DevExpress.XtraBars.BarButtonItem barButtonItem33;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup15;
        private DevExpress.XtraBars.BarCheckItem barOnlyRed;
        private DevExpress.XtraBars.BarButtonItem barButtonItem34;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private DevExpress.XtraBars.BarCheckItem checkVSSEnable;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer controlContainer1;
        private System.Windows.Forms.WebBrowser webBrowserUserManual;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel2;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel2_Container;
        private System.Windows.Forms.WebBrowser webBrowserDocumentation;
        private DevExpress.XtraBars.BarButtonItem barShowGraph;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ContextMenuStrip mnuSymbols;
        private System.Windows.Forms.ToolStripMenuItem mnuShowTable;
        private System.Windows.Forms.ToolStripMenuItem mnuShowGraph;
        private System.Windows.Forms.ToolStripMenuItem mnuExportExcel;
        private DevExpress.XtraBars.BarCheckItem barAutoChecksum;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private DevExpress.XtraBars.BarButtonItem barSRAMDumpImport;
        private System.Windows.Forms.OpenFileDialog openFileDialog3;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripMenuItem showSRAMMapToolStripMenuItem;
        private DevExpress.XtraBars.BarButtonItem barEngineEmulator;
        private DevExpress.XtraBars.BarButtonItem barT5Docu;
        private DevExpress.XtraBars.BarButtonItem barUserManual;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private DevExpress.XtraBars.BarCheckItem barShowGraphs;
        private DevExpress.XtraBars.BarButtonItem barMaximise;
        private DevExpress.XtraBars.BarButtonItem barButtonItem18;
        private DevExpress.XtraBars.BarButtonItem barButtonItem21;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup17;
        private DevExpress.XtraBars.BarCheckItem barCheckSymbolWindow;
        private DevExpress.XtraBars.BarEditItem barEditSymbollist;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem22;
        private DevExpress.XtraBars.BarButtonItem barButtonItem35;
        private DevExpress.XtraBars.BarButtonItem barButtonItem36;
        private DevExpress.XtraBars.BarButtonItem barButtonItem37;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup18;
        private DevExpress.XtraEditors.Repository.RepositoryItemMRUEdit repositoryItemMRUEdit1;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem38;
        private DevExpress.XtraBars.BarButtonItem barButtonItem40;
        private DevExpress.XtraBars.BarButtonItem barButtonItem41;
        private DevExpress.XtraBars.BarButtonItem barButtonItem42;
        private DevExpress.XtraBars.BarButtonItem barButtonItem43;
        private DevExpress.XtraBars.BarButtonItem barButtonItem44;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup19;
        private DevExpress.XtraBars.BarButtonItem barButtonItem45;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup20;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup21;
        private DevExpress.XtraBars.BarButtonItem barButtonItem39;
        private DevExpress.XtraBars.BarButtonItem barButtonItem46;
        private DevExpress.XtraBars.BarStaticItem barStaticItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem47;
        private DevExpress.XtraBars.BarButtonItem barButtonItem48;
        private DevExpress.XtraBars.BarButtonItem barButtonItem49;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup22;
        private DevExpress.XtraBars.BarButtonItem barButtonItem50;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup23;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.SaveFileDialog saveFileDialog3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem51;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup24;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup25;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup16;
        private DevExpress.XtraBars.BarButtonItem barButtonItem52;
        private DevExpress.XtraBars.BarButtonItem barButtonItem53;
        private System.Windows.Forms.ToolStripMenuItem showSymbolInHexviewerToolStripMenuItem;
        private DevExpress.XtraBars.BarButtonItem barButtonItem54;

  
    }
}

