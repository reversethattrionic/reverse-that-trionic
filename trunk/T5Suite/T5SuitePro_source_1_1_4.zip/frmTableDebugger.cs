using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmTableDebugger : DevExpress.XtraEditors.XtraForm
    {
        public frmTableDebugger()
        {
            InitializeComponent();
        }

        public void ShowTable(System.Data.DataTable dt)
        {
            gridControl1.DataSource = dt;
        }
    }
}