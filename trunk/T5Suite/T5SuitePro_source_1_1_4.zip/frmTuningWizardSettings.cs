using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public partial class frmTuningWizardSettings : DevExpress.XtraEditors.XtraForm
    {
        public double MaxBoostLevel
        {
            get
            {
                return Convert.ToDouble(spinEdit1.EditValue);
            }
            set
            {
                spinEdit1.EditValue = value;
            }
        }

        public double AutoGearBoxPercentage
        {
            get
            {
                return Convert.ToDouble(spinEdit2.EditValue);
            }
            set
            {
                spinEdit2.EditValue = value;
            }
        }

        public double MaxBoostInFirstGear
        {
            get
            {
                return Convert.ToDouble(spinEdit3.EditValue);
            }
            set
            {
                spinEdit3.EditValue = value;
            }
        }

        public double MaxBoostInSecondGear
        {
            get
            {
                return Convert.ToDouble(spinEdit4.EditValue);
            }
            set
            {
                spinEdit4.EditValue = value;
            }
        }

        public double MaxBoostInFirstGearAUT
        {
            get
            {
                return Convert.ToDouble(spinEdit5.EditValue);
            }
            set
            {
                spinEdit5.EditValue = value;
            }
        }

        public double FuelCutLevel
        {
            get
            {
                return Convert.ToDouble(spinEdit6.EditValue);
            }
            set
            {
                spinEdit6.EditValue = value;
            }
        }

        public frmTuningWizardSettings()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}