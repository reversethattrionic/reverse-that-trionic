using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace T5SuitePro
{
    enum BDMRegs : int
    {
        REG_PC = 0,
        REG_USP = 1,
        REG_SSP = 2,
        REG_VBR = 3,
        REG_SR = 4,
        REG_SFC = 5,
        REG_DFC = 6,
        REG_ATEMP = 7,
        REG_D0 = 8,
        REG_D1 = 9,
        REG_D2 = 10,
        REG_D3 = 11,
        REG_D4 = 12,
        REG_D5 = 13,
        REG_D6 = 14,
        REG_D7 = 15,
        REG_A0 = 16,
        REG_A1 = 17,
        REG_A2 = 18,
        REG_A3 = 19,
        REG_A4 = 20,
        REG_A5 = 21,
        REG_A6 = 22,
        REG_A7 = 23,
        REG_MAX = 23
    }

    enum BDMCommand : int
    {
         BDM_RDREG       =0x2180,
         BDM_WRREG       =0x2080,
         BDM_RSREG       =0x2580,
         BDM_WSREG       =0x2480,
         BDM_READ        =0x1900,
         BDM_WRITE       =0x1800,
         BDM_DUMP        =0x1D00,
         BDM_FILL        =0x1C00,
         BDM_GO          =0x0C00,
         BDM_CALL        =0x0800,
         BDM_RST         =0x0400,
         BDM_NOP         =0x0000,

         BDM_BYTESIZE    =0x00,
         BDM_WORDSIZE    =0x40,
         BDM_LONGSIZE    =0x80,
         BDM_RDBIT       =0x100,

         BDM_RPC         =0x0,
         BDM_PCC         =0x1,
         BDM_SR          =0xb,
         BDM_USP         =0xc,
         BDM_SSP         =0xd,
         BDM_SFC         =0xe,
         BDM_DFC         =0xf,
         BDM_ATEMP       =0x8,
         BDM_FAR         =0x9,
         BDM_VBR         =0xa,

         BDM_NOTREADY    =0x10000,
         BDM_BERR        =0x10001,
         BDM_ILLEGAL     =0x1FFFF,
         BDM_CMDCMPLTE   =0x0FFFF,
    }

    enum TargetState : int
    {
        TARGETRESET = 1,
        TARGETHALT = 2,
        TARGETSTOPPED = 4,
        TARGETPOWER = 8,
        TARGETNC = 0x10
    }
    enum LPTPinsPD : int
    {
        bdm_ctl = 2,               // offset of control port from base    
        dsi = 4,               // data shift input - PC->MCU          
        dsclk = 1,               // data shift clock/breakpoint pin     
        step_out = 8,               // set low to force breakpoint	       
        rst_out = 2,               // set low to force reset on MCU       
        reset = 2,
        oe = 0x10,		// set to a 1 to enable DSI 	       
        force_berr = 0x40		// set to a 1 to force BERR on target  
    }

    enum BDMError : int
    {
        BDM_FAULT_UNKNOWN = 0,
        BDM_FAULT_POWER = 1,
        BDM_FAULT_CABLE = 2,
        BDM_FAULT_RESPONSE = 3,
        BDM_FAULT_RESET = 4,
        BDM_FAULT_PORT = 5,
        BDM_FAULT_BERR = 6
    }

    enum TargetStatePD : int
    {
        TARGETRESET = 1,
        TARGETHALT = 2,
        TARGETSTOPPED = 4,
        TARGETPOWER = 8,
        TARGETNC = 0x10
    }
    class BDMCommPD
    {
        public delegate void NotifyError(object sender, ErrorEventArgs e);
        public event BDMCommPD.NotifyError onError;


        private int bdm_stat = 1;		// offset of status port from base     
        private int nc = 0x80;            // not connected - low when unplugged  
        private int pwr_dwn = 0x40;            // power down - low when Vcc failed    
        private int dso = 0x20;            // data shift output - MCU->PC         
        private int freeze = 8;             // FREEZE asserted when MCU stopped    
        //private int nop_cmd = 0;               // null (NOP) command                  
        //private int waitcnt = 0xffff;          // no of loops to wait for response    
        private int waitcnt = 0x00ff;          // no of loops to wait for response    
        int bdm_speed = 0;
        int bdm_port = 0;
        int old_ctl = 0;
        //int go_cmd = 0;
        //int CommandBitCount = 0;
        //public byte RegsValid = 0;

        int UserData = 1;
        int UserCode = 2;
        int SupervisorData = 5;
        int SupervisorCode = 6;


        int fc_set = 0, fc = 5;
        long old_sfc, old_dfc;
        int last_rw;
        long last_addr;
        int go_cmd = (int)BDMCommand.BDM_GO;
        private int CommandBitCount = 17;
        int Initted = 0;
        int RegsValid;


        // Call OutPut function from DLL file.
        [DllImport("inpout32.dll", EntryPoint = "Out32")]
        public static extern void Output(int adress, int value);

        // Call Input functionfrom DLL file
        [DllImport("inpout32.dll", EntryPoint = "Inp32")]
        public static extern int Input(int adress);

        public class ErrorEventArgs : System.EventArgs
        {
            private BDMError _error;

            public BDMError Error
            {
                get
                {
                    return _error;
                }
            }

            public ErrorEventArgs(BDMError error)
            {
                this._error = error;
            }
        }

        private void CastErrorEvent(BDMError error)
        {
            if (onError != null)
            {
                onError(this, new ErrorEventArgs(error));
            }
        }


        void bdm_deinit()
        {
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, old_ctl);
        }

        // bdm_init initializes parallel port to talk to target 

        void bdm_init(int port, int baud)
        {
            RegsValid = 0;
            old_ctl = Input(bdm_port + (int)LPTPinsPD.bdm_ctl);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.step_out);
            bdm_port = port;
            bdm_speed = baud;
        }

        void ResetChip()
        {
            RegsValid = 0;
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.rst_out + (int)LPTPinsPD.step_out);
            bdm_delay(waitcnt);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.step_out);
        }

        void RestartChip()
        {
            int LoopCount;

            RegsValid = 0;
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.rst_out | (int)LPTPinsPD.dsclk);
            bdm_delay(waitcnt);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.dsclk);
            bdm_delay(waitcnt);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.step_out | (int)LPTPinsPD.dsclk);
            for (LoopCount = 0xffff; LoopCount > 0; LoopCount--)
                if ((Input(bdm_port + bdm_stat) & freeze) > 0) break;
            if (LoopCount <= 0) bdm_error(BDMError.BDM_FAULT_RESPONSE);
        }

        private void bdm_error(BDMError err)
        {
            // throw error event!
            CastErrorEvent(err);
        }

        public int StopChip()
        {
            int ctr;
            int frozen = 0;

            RegsValid = 0;
            if ((Input(bdm_port + bdm_stat) & freeze) > 0) return frozen;
            frozen = 1;
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.dsclk + (int)LPTPinsPD.step_out);
            for (ctr = waitcnt; ctr > 0; ctr--)
            {
                if ((Input(bdm_port + bdm_stat) & freeze) > 0) break;
                bdm_delay(1);
            }
            if (ctr <= 0) bdm_error(BDMError.BDM_FAULT_RESPONSE);
            return frozen;
        }

        // bdm_clk sends <value> to MCU for <parameter> bits, returns MCU response 

        /* #define	C_CLOCK_ROUTINE // uncomment this line to use C language
                         * clock routine instead of assembly language
                         * C version is slower, but easier to
                         * follow when debugging*/


        long bdm_clk(long value, int count)
        {
            long ShiftRegister = ((long)value) << (32 - count);
            int DataOut;
            int stat = GetStatus();

            if ((stat & (int)TargetStatePD.TARGETRESET) > 0)
                bdm_error(BDMError.BDM_FAULT_RESET);
            if ((stat & (int)TargetStatePD.TARGETNC) > 0)
                bdm_error(BDMError.BDM_FAULT_CABLE);
            if ((stat & (int)TargetStatePD.TARGETPOWER) > 0)
                bdm_error(BDMError.BDM_FAULT_POWER);

            while (count-- > 0)
            {
                DataOut = ((ShiftRegister & 0x80000000) > 0) ? (int)LPTPinsPD.dsi : 0;
                ShiftRegister <<= 1;
                if ((Input(bdm_port + bdm_stat) & dso) <= 0)
                    ShiftRegister |= 1;
                Output(bdm_port + (int)LPTPinsPD.bdm_ctl, DataOut | (int)LPTPinsPD.step_out | (int)LPTPinsPD.dsclk);
                bdm_delay(bdm_speed + 1);
                Output(bdm_port + (int)LPTPinsPD.bdm_ctl, DataOut | (int)LPTPinsPD.step_out);
                bdm_delay((bdm_speed >> 1) + 1);
            }
            return ShiftRegister;
        }

        private int DataOut()
        {
            int retval = ((go_cmd & 1) > 0) ? (int)LPTPinsPD.dsi : 0;
            return retval;
        }

        // StepChip sends GO command word, then triggers breakpoint on first fetch        

        void StepChip()
        {
            int stat = GetStatus();
            RegsValid = 0;
            if ((stat & (int)TargetStatePD.TARGETRESET) > 0)
                bdm_error(BDMError.BDM_FAULT_RESET);
            if ((stat & (int)TargetStatePD.TARGETNC) > 0)
                bdm_error(BDMError.BDM_FAULT_CABLE);
            if ((stat & (int)TargetStatePD.TARGETPOWER) > 0)
                bdm_error(BDMError.BDM_FAULT_POWER);
            bdm_clk(go_cmd >> 1, CommandBitCount - 1);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.dsclk | (int)LPTPinsPD.step_out | DataOut());
            bdm_delay(bdm_speed + 1);
            //            disable();
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, (int)LPTPinsPD.dsclk | DataOut());
            bdm_delay(1);
            Output(bdm_port + (int)LPTPinsPD.bdm_ctl, DataOut());
            //            enable();
        }

        int GetStatus()
        {
            int temp = Input(bdm_port + bdm_stat);

            if ((temp & nc) == 0) return (int)TargetStatePD.TARGETNC;
            if ((temp & pwr_dwn) == 0) return (int)TargetStatePD.TARGETPOWER;
            return ((temp & freeze) > 0 ? (int)TargetStatePD.TARGETSTOPPED : 0)
                | ((Input(bdm_port + (int)LPTPinsPD.bdm_ctl) & (int)LPTPinsPD.reset) > 0 ? (int)TargetStatePD.TARGETRESET : 0);
        }

        // GetStatusMask returns mask showing which stat bits are valid 

        int GetStatusMask()
        {
            return (int)TargetStatePD.TARGETRESET | (int)TargetStatePD.TARGETSTOPPED | (int)TargetStatePD.TARGETPOWER | (int)TargetStatePD.TARGETNC;
        }
        static void bdm_delay(int count)
        {
            System.Threading.Thread.Sleep(count);
        }

        int set_fc()
        {
            if (fc_set > 0) return 0;
            old_sfc = (int)GetReg((int)BDMRegs.REG_SFC);
            old_dfc = (int)GetReg((int)BDMRegs.REG_DFC);
            PutReg((int)BDMRegs.REG_SFC, (long)fc);
            PutReg((int)BDMRegs.REG_DFC, (long)fc);
            return fc_set = 1;
        }

        private int restore_fc()
        {
            if (fc_set == 0) return 0;
            PutReg((int)BDMRegs.REG_SFC, (long)old_sfc);
            PutReg((int)BDMRegs.REG_DFC, (long)old_dfc);
            fc_set = 0;
            return 1;
        }

        private int ValidPorts()
        {
            return 1;
        }

        private void SetFC(int NewFC)
        {
            if (NewFC == UserData || NewFC == UserCode || NewFC == SupervisorData || NewFC == SupervisorCode)
            {
                fc = NewFC;
            }
        }

        // DeInit must be called before program quits or shells to DOS
        /* un-do any bad things which have been done to talk to target*/


        public void DeInit()
        {
            if (Initted > 0) bdm_deinit();
            Initted = 0;
        }

        // Init initializes parallel port to talk to target 

        public int Init(int port, int baud)
        {
            int ThePort;
            DeInit();
            if ((ValidPorts() & (1 << (port - 1))) == 0) return -1;
            ThePort = 1;
            if (ThePort == 0) return -1;
            bdm_init(ThePort, baud);
            GetStatus();
            Initted = 1;
            return 0;
        }

        private void bdm_clrerror()
        {
            int count=0;
            //long response;
            int cnt = this.CommandBitCount;
            bdm_clk((long)BDMCommand.BDM_NOP, cnt);
            cnt = this.CommandBitCount;
            bdm_clk((long)BDMCommand.BDM_NOP, cnt);
            cnt = this.CommandBitCount;
            bdm_clk((long)BDMCommand.BDM_NOP, cnt);
            cnt = this.CommandBitCount;
            bdm_clk((long)BDMCommand.BDM_NOP, cnt);
            while (bdm_clk(0, 1) > 0 && count ++ < 10) ;
            count = 0;
            while (bdm_clk(0, 1) == 0 && count ++ < 10) ;
            bdm_clk(0, 15);
        }

        int[] RegCodes = {
(int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_RPC, (int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_USP,
(int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_SSP, (int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_VBR,
(int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_SR, (int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_SFC,
(int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_DFC, (int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_ATEMP,

(int)BDMCommand.BDM_WRREG + 0, (int)BDMCommand.BDM_WRREG + 1, (int)BDMCommand.BDM_WRREG + 2, (int)BDMCommand.BDM_WRREG + 3,
(int)BDMCommand.BDM_WRREG + 4, (int)BDMCommand.BDM_WRREG + 5, (int)BDMCommand.BDM_WRREG + 6, (int)BDMCommand.BDM_WRREG + 7,

(int)BDMCommand.BDM_WRREG + 8, (int)BDMCommand.BDM_WRREG + 9, (int)BDMCommand.BDM_WRREG + 10, (int)BDMCommand.BDM_WRREG + 11,
(int)BDMCommand.BDM_WRREG + 12, (int)BDMCommand.BDM_WRREG + 13, (int)BDMCommand.BDM_WRREG + 14, (int)BDMCommand.BDM_WRREG + 15
    };

        public long GetReg(int which)
        {
            int frozen;
            long result;

            frozen = StopChip();
            result = bdm_read(0L, 0, (int)BDMCommand.BDM_RDBIT + RegCodes[which], new int[0]);
            if (frozen>0) RunChip(0L);
            return result;
        }

        public void PutReg(int which, long data)
        {
            int frozen;

            frozen = StopChip();
            int[] args = new int[2];
            args.SetValue((int)(data >> 16), 0);
            args.SetValue((int)data, 1);
            bdm_write(0L, 2, RegCodes[which], args);
            if (frozen>0) RunChip(0L);
        }

        public void RunChip(long where)
        {
            StopChip();
            if (where > 0)
            {
                int[] args = new int[2];
                args.SetValue((int)(where >> 16), 0);
                args.SetValue( (int)where, 1);
                bdm_write(where, 2, (int)BDMCommand.BDM_WSREG + (int)BDMCommand.BDM_RPC, args);
            }
            bdm_clk((int)BDMCommand.BDM_GO, CommandBitCount);
        }



        private long bdm_read(long addr, int pcount, int cmd, int[] args)
        {
            //	va_list arg;
            int err, count;
            long response, result;
            int retry_count = 0;
            last_addr = addr;
            last_rw = 1;
            result = 0L;
            if (Initted == 0) bdm_error(BDMError.BDM_FAULT_PORT);
            for (err = 3; err >= 0; err--)
            {
                count = pcount;
                //va_start (arg,cmd);
                response = bdm_clk(cmd, CommandBitCount);
                int argcount = 0;
                while (count-- > 0)
                    if ((response = bdm_clk(Convert.ToInt32(args.GetValue(argcount++)), CommandBitCount)) > (int)BDMCommand.BDM_NOTREADY)
                    {
                        if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
                        if (retry_count++ < 10)
                        {
                            continue;
                        }
                        else
                        {
                            return -1;
                        }
                    }
                for (count = ((cmd & (int)BDMCommand.BDM_LONGSIZE)>0) ? 2 : 1; count >= 0; count--)
                {
                    while ((response = bdm_clk((int)BDMCommand.BDM_NOP, CommandBitCount)) == (int)BDMCommand.BDM_NOTREADY) ;
                    if (response < (int)BDMCommand.BDM_NOTREADY)
                    {
                        result <<= 16;
                        result |= response;
                    }
                    else
                    {
                        if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
                        break;
                    }
                }
                retry_count = 0;
                if (response > (int)BDMCommand.BDM_NOTREADY)
                {
                    if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
                    bdm_clrerror();
                    if (retry_count++ < 10)
                    {
                        continue;
                    }
                    else
                    {
                        return -1;
                    }
                }
                //		va_end (arg);
                break;
            }
            if (err==0) bdm_error(BDMError.BDM_FAULT_UNKNOWN);
            response = bdm_clk((int)BDMCommand.BDM_NOP, CommandBitCount);
            if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
            return result;
        }

        private void bdm_write(long addr, int pcount, int cmd, int[] args)
        {

            int err, count;
            long response;//, result;

            last_addr = addr;
            last_rw = 0;
            if (Initted == 0) bdm_error(BDMError.BDM_FAULT_PORT);

            for (err = 3; err >= 0; err--)
            {
                int argcount = 0;
                count = pcount;
                //va_start (arg,cmd);
                response = bdm_clk(cmd, CommandBitCount);
                while (count-- >0)
                    if ((response = bdm_clk(Convert.ToInt32(args.GetValue(argcount++)), CommandBitCount)) > (int)BDMCommand.BDM_NOTREADY)
                    {
                        if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
                        bdm_clrerror();
                        continue;
                    }
                while ((response = bdm_clk((int)BDMCommand.BDM_NOP, CommandBitCount)) == (int)BDMCommand.BDM_NOTREADY) ;
                if (response == (int)BDMCommand.BDM_CMDCMPLTE) break;
                else if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);

            }
            if (err == 0) bdm_error(BDMError.BDM_FAULT_UNKNOWN);
            response = bdm_clk((int)BDMCommand.BDM_NOP, CommandBitCount);
            if (response == (int)BDMCommand.BDM_BERR) bdm_error(BDMError.BDM_FAULT_BERR);
        }


    }
}
