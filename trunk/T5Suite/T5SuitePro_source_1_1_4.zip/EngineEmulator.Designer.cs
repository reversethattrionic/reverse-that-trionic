namespace T5SuitePro
{
    partial class EngineEmulator
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rpmGauge = new AquaControls.AquaGauge();
            this.OilTempGauge = new AquaControls.AquaGauge();
            this.CoolantTempGauge = new AquaControls.AquaGauge();
            this.SpeedGauge = new AquaControls.AquaGauge();
            this.BoostGauge = new AquaControls.AquaGauge();
            this.IntakeAirGauge = new AquaControls.AquaGauge();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.trackBarControl1 = new DevExpress.XtraEditors.TrackBarControl();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // rpmGauge
            // 
            this.rpmGauge.BackColor = System.Drawing.Color.Transparent;
            this.rpmGauge.DialColor = System.Drawing.Color.Lavender;
            this.rpmGauge.DialText = "RPM";
            this.rpmGauge.Glossiness = 11.36364F;
            this.rpmGauge.Location = new System.Drawing.Point(7, 9);
            this.rpmGauge.MaxValue = 7500F;
            this.rpmGauge.MinValue = 0F;
            this.rpmGauge.Name = "rpmGauge";
            this.rpmGauge.RecommendedValue = 3000F;
            this.rpmGauge.Size = new System.Drawing.Size(150, 150);
            this.rpmGauge.TabIndex = 0;
            this.rpmGauge.ThresholdPercent = 60F;
            this.rpmGauge.Value = 0F;
            this.rpmGauge.Load += new System.EventHandler(this.rpmGauge_Load);
            // 
            // OilTempGauge
            // 
            this.OilTempGauge.BackColor = System.Drawing.Color.Transparent;
            this.OilTempGauge.DialColor = System.Drawing.Color.Lavender;
            this.OilTempGauge.DialText = "Oil";
            this.OilTempGauge.Glossiness = 11.36364F;
            this.OilTempGauge.Location = new System.Drawing.Point(163, 9);
            this.OilTempGauge.MaxValue = 150F;
            this.OilTempGauge.MinValue = 0F;
            this.OilTempGauge.Name = "OilTempGauge";
            this.OilTempGauge.RecommendedValue = 100F;
            this.OilTempGauge.Size = new System.Drawing.Size(150, 150);
            this.OilTempGauge.TabIndex = 1;
            this.OilTempGauge.ThresholdPercent = 20F;
            this.OilTempGauge.Value = 0F;
            // 
            // CoolantTempGauge
            // 
            this.CoolantTempGauge.BackColor = System.Drawing.Color.Transparent;
            this.CoolantTempGauge.DialColor = System.Drawing.Color.Lavender;
            this.CoolantTempGauge.DialText = "Coolant";
            this.CoolantTempGauge.Glossiness = 11.36364F;
            this.CoolantTempGauge.Location = new System.Drawing.Point(319, 9);
            this.CoolantTempGauge.MaxValue = 120F;
            this.CoolantTempGauge.MinValue = 0F;
            this.CoolantTempGauge.Name = "CoolantTempGauge";
            this.CoolantTempGauge.RecommendedValue = 90F;
            this.CoolantTempGauge.Size = new System.Drawing.Size(150, 150);
            this.CoolantTempGauge.TabIndex = 2;
            this.CoolantTempGauge.ThresholdPercent = 10F;
            this.CoolantTempGauge.Value = 0F;
            // 
            // SpeedGauge
            // 
            this.SpeedGauge.BackColor = System.Drawing.Color.Transparent;
            this.SpeedGauge.DialColor = System.Drawing.Color.Lavender;
            this.SpeedGauge.DialText = "Speed";
            this.SpeedGauge.Glossiness = 11.36364F;
            this.SpeedGauge.Location = new System.Drawing.Point(7, 165);
            this.SpeedGauge.MaxValue = 300F;
            this.SpeedGauge.MinValue = 0F;
            this.SpeedGauge.Name = "SpeedGauge";
            this.SpeedGauge.RecommendedValue = 0F;
            this.SpeedGauge.Size = new System.Drawing.Size(150, 150);
            this.SpeedGauge.TabIndex = 3;
            this.SpeedGauge.ThresholdPercent = 0F;
            this.SpeedGauge.Value = 0F;
            // 
            // BoostGauge
            // 
            this.BoostGauge.BackColor = System.Drawing.Color.Transparent;
            this.BoostGauge.DialColor = System.Drawing.Color.Lavender;
            this.BoostGauge.DialText = "Boost/APC";
            this.BoostGauge.Glossiness = 11.36364F;
            this.BoostGauge.Location = new System.Drawing.Point(163, 165);
            this.BoostGauge.MaxValue = 2F;
            this.BoostGauge.MinValue = -1F;
            this.BoostGauge.Name = "BoostGauge";
            this.BoostGauge.RecommendedValue = 0F;
            this.BoostGauge.Size = new System.Drawing.Size(150, 150);
            this.BoostGauge.TabIndex = 4;
            this.BoostGauge.ThresholdPercent = 0F;
            this.BoostGauge.Value = 0F;
            // 
            // IntakeAirGauge
            // 
            this.IntakeAirGauge.BackColor = System.Drawing.Color.Transparent;
            this.IntakeAirGauge.DialColor = System.Drawing.Color.Lavender;
            this.IntakeAirGauge.DialText = "Intake Air";
            this.IntakeAirGauge.Glossiness = 11.36364F;
            this.IntakeAirGauge.Location = new System.Drawing.Point(319, 165);
            this.IntakeAirGauge.MaxValue = 100F;
            this.IntakeAirGauge.MinValue = 0F;
            this.IntakeAirGauge.Name = "IntakeAirGauge";
            this.IntakeAirGauge.RecommendedValue = 40F;
            this.IntakeAirGauge.Size = new System.Drawing.Size(150, 150);
            this.IntakeAirGauge.TabIndex = 5;
            this.IntakeAirGauge.ThresholdPercent = 30F;
            this.IntakeAirGauge.Value = 0F;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(7, 334);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(75, 23);
            this.simpleButton1.TabIndex = 6;
            this.simpleButton1.Text = "Start engine";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // trackBarControl1
            // 
            this.trackBarControl1.EditValue = null;
            this.trackBarControl1.Location = new System.Drawing.Point(108, 334);
            this.trackBarControl1.Name = "trackBarControl1";
            this.trackBarControl1.Properties.Maximum = 100;
            this.trackBarControl1.Size = new System.Drawing.Size(361, 45);
            this.trackBarControl1.TabIndex = 7;
            this.trackBarControl1.ValueChanged += new System.EventHandler(this.trackBarControl1_ValueChanged);
            // 
            // EngineEmulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.trackBarControl1);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.IntakeAirGauge);
            this.Controls.Add(this.BoostGauge);
            this.Controls.Add(this.SpeedGauge);
            this.Controls.Add(this.CoolantTempGauge);
            this.Controls.Add(this.OilTempGauge);
            this.Controls.Add(this.rpmGauge);
            this.Name = "EngineEmulator";
            this.Size = new System.Drawing.Size(482, 370);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AquaControls.AquaGauge rpmGauge;
        private AquaControls.AquaGauge OilTempGauge;
        private AquaControls.AquaGauge CoolantTempGauge;
        private AquaControls.AquaGauge SpeedGauge;
        private AquaControls.AquaGauge BoostGauge;
        private AquaControls.AquaGauge IntakeAirGauge;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.TrackBarControl trackBarControl1;
    }
}
