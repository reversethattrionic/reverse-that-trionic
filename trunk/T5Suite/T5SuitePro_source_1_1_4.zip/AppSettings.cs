using System;
using System.Collections.Generic;
using System.Text;
//using System.Security.Permissions;
using Microsoft.Win32;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.IO;

//[assembly: RegistryPermissionAttribute(SecurityAction.RequestMinimum,ViewAndModify = "HKEY_CURRENT_USER")]

namespace T5SuitePro
{
    public class AppSettings
    {

        private bool m_ShowGraphs = true;

        public bool ShowGraphs
        {
            get { return m_ShowGraphs; }
            set
            {
                m_ShowGraphs = value;
                SaveRegistrySetting("ShowGraphs", m_ShowGraphs);
            }
        }

        private bool m_HideSymbolTable = false;

        public bool HideSymbolTable
        {
            get { return m_HideSymbolTable; }
            set { m_HideSymbolTable = value;
            SaveRegistrySetting("HideSymbolTable", m_HideSymbolTable);
        }
        }

        private bool m_AutoChecksum = true;

        public bool AutoChecksum
        {
            get { return m_AutoChecksum; }
            set
            {
                m_AutoChecksum = value;
                SaveRegistrySetting("AutoChecksum", m_AutoChecksum);
            }
        }

        private string m_TargetECUReadFile = string.Empty;

        public string TargetECUReadFile
        {
            get { return m_TargetECUReadFile; }
            set
            {
                m_TargetECUReadFile = value;
                SaveRegistrySetting("TargetECUReadFile", m_TargetECUReadFile);
            }
        }

        private string m_write_ecubatchfile = string.Empty;

        public string Write_ecubatchfile
        {
            get { return m_write_ecubatchfile; }
            set 
            {
                if (m_write_ecubatchfile != value)
                {
                    m_write_ecubatchfile = value;
                    SaveRegistrySetting("WriteECUBatchfile", m_write_ecubatchfile);
                }
            }
        }
        private string m_read_ecubatchfile = string.Empty;

        public string Read_ecubatchfile
        {
            get { return m_read_ecubatchfile; }
            set {
                if (m_read_ecubatchfile != value)
                {
                    m_read_ecubatchfile = value;
                    SaveRegistrySetting("ReadECUBatchfile", m_read_ecubatchfile);
                }
            }
        }

        private string m_lastfilename = "";

        private bool m_ShowRedWhite = false;

        public bool ShowRedWhite
        {
            get { return m_ShowRedWhite; }
            set
            {
                if (m_ShowRedWhite != value)
                {
                    m_ShowRedWhite = value;
                    SaveRegistrySetting("ShowRedWhite", m_ShowRedWhite);
                }
            }
        }


        private bool m_AutoExtractSymbols = true;

        public bool AutoExtractSymbols
        {
            get { return m_AutoExtractSymbols; }
            set 
            {
                if(m_AutoExtractSymbols != value)
                {
                    m_AutoExtractSymbols = value;
                    SaveRegistrySetting("AutoExtractSymbols", m_AutoExtractSymbols);
                }
            }
        }



        public string Lastfilename
        {
            get { return m_lastfilename; }
            set {
                if (m_lastfilename != value)
                {
                    m_lastfilename = value;
                    SaveRegistrySetting("LastFilename", m_lastfilename);
                }
            }
        }
        private bool m_viewinhex = false;

        public bool Viewinhex
        {
            get { return m_viewinhex; }
            set 
            {
                if (m_viewinhex != value)
                {
                    m_viewinhex = value;
                    SaveRegistrySetting("ViewInHex", m_viewinhex);
                }
            }
        }

        private bool m_debugmode = false;

        public bool DebugMode
        {
            get { return m_debugmode; }
        }



        private void SaveRegistrySetting(string key, string value)
        {
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software");

            using (RegistryKey saveSettings = TempKey.CreateSubKey("T5SuitePro"))
            {
                saveSettings.SetValue(key, value);
            }
        }
        private void SaveRegistrySetting(string key, Int32 value)
        {
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software");

            using (RegistryKey saveSettings = TempKey.CreateSubKey("T5SuitePro"))
            {
                saveSettings.SetValue(key, value);
            }
        }
        private void SaveRegistrySetting(string key, bool value)
        {
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software");

            using (RegistryKey saveSettings = TempKey.CreateSubKey("T5SuitePro"))
            {
                saveSettings.SetValue(key, value);
            }
        }

        public void SaveSettings()
        {
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software");

            using (RegistryKey saveSettings = TempKey.CreateSubKey("T5SuitePro"))
            {
                saveSettings.SetValue("ViewInHex", m_viewinhex);
                saveSettings.SetValue("LastFilename", m_lastfilename);
                saveSettings.SetValue("AutoExtractSymbols", m_AutoExtractSymbols);
                saveSettings.SetValue("WriteECUBatchfile", m_write_ecubatchfile);
                saveSettings.SetValue("ReadECUBatchfile", m_read_ecubatchfile);
                saveSettings.SetValue("ShowRedWhite", m_ShowRedWhite);
                saveSettings.SetValue("TargetECUReadFile", m_TargetECUReadFile);
                saveSettings.SetValue("AutoChecksum", m_AutoChecksum);
                saveSettings.SetValue("ShowGraphs", m_ShowGraphs);
                saveSettings.SetValue("HideSymbolTable", m_HideSymbolTable);
            }
        }

        public AppSettings()
        {
            // laad alle waarden uit het register
            RegistryKey TempKey = null;
            TempKey = Registry.CurrentUser.CreateSubKey("Software");
            

            using (RegistryKey Settings = TempKey.CreateSubKey("T5SuitePro"))
            {
                if (Settings != null)
                {
                    string[] vals = Settings.GetValueNames();
                    foreach (string a in vals)
                    {
                        try
                        {
                            if (a == "ViewInHex")
                            {
                                m_viewinhex = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                            if (a == "DebugMode")
                            {
                                m_debugmode = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                            else if (a == "LastFilename")
                            {
                                m_lastfilename = Settings.GetValue(a).ToString();
                            }
                            else if (a == "AutoExtractSymbols")
                            {
                                m_AutoExtractSymbols = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                            else if (a == "WriteECUBatchfile")
                            {
                                m_write_ecubatchfile = Settings.GetValue(a).ToString();
                            }
                            else if (a == "TargetECUReadFile")
                            {
                                m_TargetECUReadFile = Settings.GetValue(a).ToString();
                            }
                            else if (a == "AutoChecksum")
                            {
                                m_AutoChecksum = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                            else if (a == "HideSymbolTable")
                            {
                                m_HideSymbolTable = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                            else if (a == "ShowGraphs")
                            {
                                m_ShowGraphs = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }

                            else if (a == "ReadECUBatchfile")
                            {
                                m_read_ecubatchfile = Settings.GetValue(a).ToString();
                            }
                            else if (a == "ShowRedWhite")
                            {
                                m_ShowRedWhite = Convert.ToBoolean(Settings.GetValue(a).ToString());
                            }
                        }
                        catch (Exception E)
                        {
                            Console.WriteLine("error retrieving registry settings: " + E.Message);
                        }

                    }
                }
            }

        }
    }
}
