using System.Collections;
using System;
using System.Globalization;
using System.Windows.Forms;


namespace T5SuitePro
{

    public class DummyProvider : IFormatProvider
    {
        // Normally, GetFormat returns an object of the requested type
        // (usually itself) if it is able; otherwise, it returns Nothing. 
        public object GetFormat(Type argType)
        {
            // Here, GetFormat displays the name of argType, after removing 
            // the namespace information. GetFormat always returns null.
            string argStr = argType.ToString();
            if (argStr == "")
                argStr = "Empty";
            argStr = argStr.Substring(argStr.LastIndexOf('.') + 1);

            Console.Write("{0,-20}", argStr);
            return null;
        }
    }


    /// <summary>
    /// This class is an implementation of the 'IComparer' interface.
    /// </summary>
    public class myListViewColumnSorter : IComparer
    {

        public enum SortType : int
        {
            Text,
            Number,
            DateTime,
            Hex
        }

        private SortType m_typeToSort = SortType.Text; // default= text

        public SortType TypeToSort
        {
            get { return m_typeToSort; }
            set { m_typeToSort = value; }
        }
        /// <summary>
        /// Specifies the column to be sorted
        /// </summary>
        private int ColumnToSort;
        /// <summary>
        /// Specifies the order in which to sort (i.e. 'Ascending').
        /// </summary>
        private SortOrder OrderOfSort;
        /// <summary>
        /// Case insensitive comparer object
        /// </summary>
        private CaseInsensitiveComparer ObjectCompare;

        /// <summary>
        /// Class constructor.  Initializes various elements
        /// </summary>
        public myListViewColumnSorter()
        {
            // Initialize the column to '0'
            ColumnToSort = 0;

            // Initialize the sort order to 'none'
            OrderOfSort = SortOrder.None;

            // Initialize the CaseInsensitiveComparer object
            ObjectCompare = new CaseInsensitiveComparer();
        }

        /// <summary>
        /// This method is inherited from the IComparer interface.  It compares the two objects passed using a case insensitive comparison.
        /// </summary>
        /// <param name="x">First object to be compared</param>
        /// <param name="y">Second object to be compared</param>
        /// <returns>The result of the comparison. "0" if equal, negative if 'x' is less than 'y' and positive if 'x' is greater than 'y'</returns>
        public int Compare(object x, object y)
        {
            DummyProvider provider = new DummyProvider();
            int compareResult = 0;
            ListViewItem listviewX, listviewY;

            // Cast the objects to be compared to ListViewItem objects
            listviewX = (ListViewItem)x;
            listviewY = (ListViewItem)y;

            // Compare the two items
            if (m_typeToSort == SortType.Text)
            {
                compareResult = ObjectCompare.Compare(listviewX.SubItems[ColumnToSort].Text, listviewY.SubItems[ColumnToSort].Text);
            }
            else if (m_typeToSort == SortType.Number)
            {
                try
                {

                    if (Convert.ToInt32(listviewX.SubItems[ColumnToSort].Text) > Convert.ToInt32(listviewY.SubItems[ColumnToSort].Text))
                    {
                        compareResult = 1;
                    }
                    else if (Convert.ToInt32(listviewX.SubItems[ColumnToSort].Text) < Convert.ToInt32(listviewY.SubItems[ColumnToSort].Text))
                    {
                        compareResult = -1;
                    }
                    else
                    {
                        compareResult = 0;
                    }
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }
            else if (m_typeToSort == SortType.Hex)
            {
                try
                {

                    if (Convert.ToInt32(listviewX.SubItems[ColumnToSort].Text,16) > Convert.ToInt32(listviewY.SubItems[ColumnToSort].Text, 16))
                    {
                        compareResult = 1;
                    }
                    else if (Convert.ToInt32(listviewX.SubItems[ColumnToSort].Text, 16) < Convert.ToInt32(listviewY.SubItems[ColumnToSort].Text, 16))
                    {
                        compareResult = -1;
                    }
                    else
                    {
                        compareResult = 0;
                    }
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }
            else if (m_typeToSort == SortType.DateTime)
            {
                try
                {
                    if (listviewX.SubItems[ColumnToSort].Text != "")
                    {
                        if (Convert.ToDateTime(listviewX.SubItems[ColumnToSort].Text, provider) > Convert.ToDateTime(listviewY.SubItems[ColumnToSort].Text, provider))
                        {
                            compareResult = 1;
                        }
                        else if (Convert.ToDateTime(listviewX.SubItems[ColumnToSort].Text, provider) < Convert.ToDateTime(listviewY.SubItems[ColumnToSort].Text, provider))
                        {
                            compareResult = -1;
                        }
                        else
                        {
                            compareResult = 0;
                        }
                    }
                    else
                    {
                        compareResult = 0;
                    }
                }
                catch (Exception E)
                {
                    MessageBox.Show(E.Message);
                }
            }

            // Calculate correct return value based on object comparison
            if (OrderOfSort == SortOrder.Ascending)
            {
                // Ascending sort is selected, return normal result of compare operation
                return compareResult;
            }
            else if (OrderOfSort == SortOrder.Descending)
            {
                // Descending sort is selected, return negative result of compare operation
                return (-compareResult);
            }
            else
            {
                // Return '0' to indicate they are equal
                return 0;
            }
        }

        /// <summary>
        /// Gets or sets the number of the column to which to apply the sorting operation (Defaults to '0').
        /// </summary>
        public int SortColumn
        {
            set
            {
                ColumnToSort = value;
            }
            get
            {
                return ColumnToSort;
            }
        }

        /// <summary>
        /// Gets or sets the order of sorting to apply (for example, 'Ascending' or 'Descending').
        /// </summary>
        public SortOrder Order
        {
            set
            {
                OrderOfSort = value;
            }
            get
            {
                return OrderOfSort;
            }
        }

    }
}
