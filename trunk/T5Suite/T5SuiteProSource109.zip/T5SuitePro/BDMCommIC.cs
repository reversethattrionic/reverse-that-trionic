using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;


namespace T5SuitePro
{
  /*  enum LPTPins : int
    {
         bdm_ctl=0,               // offset of control port from base    
         dsi=1,               // data shift input - PC->MCU          
         dsclk=2,               // data shift clock/breakpoint pin     
         step_out=4,               // set low to force breakpoint	       
         rst_out=8,               // set low to force reset on MCU       
         oe=0x10,		// set to a 1 to enable DSI 	       
         force_berr=0x40		// set to a 1 to force BERR on target  
    }

    enum TargetState : int
    {
        TARGETRESET = 1,
        TARGETHALT = 2,
        TARGETSTOPPED = 4,
        TARGETPOWER = 8,
        TARGETNC = 0x10
    }

    class BDMCommIC
    {
        int	bdm_stat=1;               // offset of status port from base     
        int	freeze=0x40;		// FREEZE asserted when MCU stopped    
        int	dso=0x80;            // data shift output - MCU->PC         
        int waitcnt = 0xffff;          // no of loops to wait for response    

        int go_cmd=0;
        int CommandBitCount = 0;
        int StatMask = TargetState.TARGETSTOPPED;


        public byte RegsValid = 0;
        int bdm_speed=0;
        int bdm_port = 0;
        // Call OutPut function from DLL file.
        [DllImport("inpout32.dll", EntryPoint = "Out32")]
        public static extern void Output(int adress, int value);

        // Call Input functionfrom DLL file
        [DllImport("inpout32.dll", EntryPoint = "Inp32")]
        public static extern void Input(int adress);

        private void bdm_init(int port, int baud)
        {
            RegsValid = 0;
            bdm_port = port;
            bdm_speed = baud;
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.step_out | (int)LPTPins.dsclk | (int)LPTPins.rst_out);
        }

        private void bdm_deinit()
        { 
            // nothing... 
        }

        private int StopChip()
        {
            int ctr;
            char frozen = 0;

            RegsValid = 0;
            if (Input(bdm_port + bdm_stat) & freeze) return frozen;
            frozen = 1;
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk + (int)LPTPins.rst_out);
            for (ctr = waitcnt; ctr; ctr--)
            {
                if (Input(bdm_port + bdm_stat) & freeze) break;
                bdm_delay(1);
            }
            if (!ctr)
            {
                Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.rst_out | (int)LPTPins.force_berr);
                bdm_delay(waitcnt);
                for (ctr = waitcnt; ctr; ctr--)
                {
                    if (Input(bdm_port + bdm_stat) & freeze) break;
                    bdm_delay(1);
                }
            }
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.rst_out | (int)LPTPins.step_out);
            if (!ctr) bdm_error(BDM_FAULT_RESPONSE);
            return frozen;
        }

        // RestartChip resets target MCU, then stops it on first instruction fetch 

        void RestartChip()
        {
            int LoopCount;

            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk);
            bdm_delay(waitcnt);
            StopChip();
        }

        // ResetChip applies hardware reset to the target MCU 

        void ResetChip()
        {
            RegsValid = 0;
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.step_out);
            bdm_delay(waitcnt);
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.rst_out | (int)LPTPins.step_out);
        }

        // bdm_clk sends <value> to MCU for <parameter> bits, returns MCU response 

// #define	C_CLOCK_ROUTINE // uncomment this line to use C language
				 * clock routine instead of assembly language
				 * C version is slower, but easier to
				 * follow when debugging
				 

        long bdm_clk(long value, int count)
        {
            long ShiftRegister = ((LONG)value) << (32 - count);
            char DataOut;
            while (count--)
            {
                DataOut = (ShiftRegister & 0x80000000) ? (int)LPTPins.dsi : 0;
                ShiftRegister <<= 1;
                if (!(Input(bdm_port + bdm_stat) & (int)LPTPins.dso)) ShiftRegister |= 1;
                Output(bdm_port + (int)LPTPins.bdm_ctl, DataOut | (int)LPTPins.rst_out | (int)LPTPins.oe | (int)LPTPins.step_out);
                bdm_delay(bdm_speed + 1);
                Output(bdm_port + (int)LPTPins.bdm_ctl, DataOut | (int)LPTPins.rst_out | (int)LPTPins.oe | (int)LPTPins.step_out | (int)LPTPins.dsclk);
                bdm_delay((bdm_speed >> 1) + 1);
            }
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.step_out | (int)LPTPins.rst_out);
            return ShiftRegister;
        }

        // StepChip sends GO command word, then triggers breakpoint on first fetch        

        private char DataOut(char i)
        {
            char retval = go_cmd & 1 ? (int)LPTPins.dsi : 0;
            return retval;
        }

        void StepChip()
        {
            bdm_clk(go_cmd >> 1, CommandBitCount - 1);
            Input(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.oe | (int)LPTPins.step_out | DataOut | (int)LPTPins.rst_out);
            bdm_delay(bdm_speed + 1);
            disable();
            Output(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.oe | (int)LPTPins.DataOut | (int)LPTPins.dsclk | (int)LPTPins.rst_out);
            outportb(bdm_port + (int)LPTPins.bdm_ctl, (int)LPTPins.dsclk | (int)LPTPins.rst_out);
            enable();
            StopChip();
        }

        
// GetStatus is called by user code to get current status of CPU signals 

        int GetStatus()
        {
            int temp = Input(bdm_port + bdm_stat);

            return (temp & freeze ? TargetState.TARGETSTOPPED : 0);
        }

// GetStatusMask returns mask showing which stat bits are valid 

        int GetStatusMask()
        {
            return TargetState.TARGETSTOPPED;
        }

// bdm_delay waits before returning to the calling routine				  


        static void bdm_delay(int count)
        {
            System.Threading.Thread.Sleep(count);
        }

        private void DumpBinary()
        {
            
        }
    }*/
}
