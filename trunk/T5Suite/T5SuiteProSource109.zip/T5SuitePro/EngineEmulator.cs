using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace T5SuitePro
{
    public delegate void UpdateRPMGauge(float rpm);
    public delegate void UpdateOilGauge(float temperature);
    public delegate void UpdateCoolantGauge(float temperature);
    public delegate void UpdateSpeedGauge(float speed);
    public delegate void UpdateBoostGauge(float boost);
    public delegate void UpdateAirTempGauge(float temperature);

    public partial class EngineEmulator : DevExpress.XtraEditors.XtraUserControl
    {
        private Engine m_engine;

        public UpdateRPMGauge m_UpdateRPMGauge;
        public UpdateOilGauge m_UpdateOilGauge;
        public UpdateCoolantGauge m_UpdateCoolantGauge;
        public UpdateSpeedGauge m_UpdateSpeedGauge;
        public UpdateBoostGauge m_UpdateBoostGauge;
        public UpdateAirTempGauge m_UpdateAirTempGauge;

        public EngineEmulator()
        {
            InitializeComponent();
            m_engine = new Engine();
            m_engine.onEngineRunning += new Engine.NotifyEngineState(m_engine_onEngineRunning);
            m_UpdateRPMGauge = new UpdateRPMGauge(this.UpdateRPMGauge);
            m_UpdateOilGauge = new UpdateOilGauge(this.UpdateOilGauge);
            m_UpdateCoolantGauge = new UpdateCoolantGauge(this.UpdateCoolantGauge);
            m_UpdateSpeedGauge = new UpdateSpeedGauge(this.UpdateSpeedGauge);
            m_UpdateBoostGauge = new UpdateBoostGauge(this.UpdateBoostGauge);
            m_UpdateAirTempGauge = new UpdateAirTempGauge(this.UpdateAirTempGauge);
        }
        private void UpdateOilGauge(float temperature)
        {
            OilTempGauge.Value = temperature;
        }
        private void UpdateCoolantGauge(float temperature)
        {
            CoolantTempGauge.Value = temperature;
        }
        private void UpdateSpeedGauge(float speed)
        {
            SpeedGauge.Value = speed;
        }

        private void UpdateBoostGauge(float boost)
        {
            BoostGauge.Value = boost;
        }

        private void UpdateAirTempGauge(float temperature)
        {
            IntakeAirGauge.Value = temperature;
        }


        private void UpdateRPMGauge(float rpm)
        {
            rpmGauge.Value = rpm;
        }

        void m_engine_onEngineRunning(object sender, Engine.EngineStateEventArgs e)
        {
            //MPMap.BeginInvoke(m_DelegateSetTemperaryPoint, m_locuseffectpoint);
            if (this.IsHandleCreated)
            {
                rpmGauge.Invoke(m_UpdateRPMGauge, e.RPM);
                OilTempGauge.Invoke(m_UpdateOilGauge, e.OilTemperature);
                CoolantTempGauge.Invoke(m_UpdateCoolantGauge, e.CoolantTemperature);
                SpeedGauge.Invoke(m_UpdateSpeedGauge, e.Speed);
                BoostGauge.Invoke(m_UpdateBoostGauge, e.TurboPressure);
                IntakeAirGauge.Invoke(m_UpdateAirTempGauge, e.IntakeAitTemperature);
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (simpleButton1.Text.StartsWith("Start"))
            {
                simpleButton1.Text = "Stop engine";
                m_engine.StartEngine();
            }
            else
            {
                simpleButton1.Text = "Start engine";
                m_engine.StopEngine();
            }
        }

        private void trackBarControl1_ValueChanged(object sender, EventArgs e)
        {
            m_engine.Throttleposition = (float)trackBarControl1.Value;
        }

        private void rpmGauge_Load(object sender, EventArgs e)
        {

        }
    }
}
