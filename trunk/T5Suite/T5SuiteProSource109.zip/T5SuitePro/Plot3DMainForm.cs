using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Plot3D
{
    public partial class Plot3DMainForm : Form
    {
        Surface3DRenderer sr;
        private bool m_IsDragging = false;
        Point m_p = new Point();
        int pov_x = 70;
        int pov_y = 35;
        int pov_z = 40;
        int pan_x = 0;
        int pan_y = 0;

        public Plot3DMainForm()
        {
            InitializeComponent();
            sr = new Surface3DRenderer(pov_x, pov_y, pov_z, 0, 0, ClientRectangle.Width, ClientRectangle.Height, 0.5, 0, 0);
            sr.ColorSchema = new ColorSchema(tbHue.Value);
            
            // create new datatable for test
            System.Data.DataTable dt = new DataTable();
            dt.Columns.Add("V1", System.Type.GetType("System.Double"));
            dt.Columns.Add("V2", System.Type.GetType("System.Double"));
            dt.Columns.Add("V3", System.Type.GetType("System.Double"));
            dt.Columns.Add("V4", System.Type.GetType("System.Double"));
            dt.Columns.Add("V5", System.Type.GetType("System.Double"));
            dt.Columns.Add("V6", System.Type.GetType("System.Double"));
            dt.Columns.Add("V7", System.Type.GetType("System.Double"));
            dt.Columns.Add("V8", System.Type.GetType("System.Double"));

            dt.Rows.Add(0, 0, 1, 1, 1, 1, 2, 2);
            dt.Rows.Add(0, 0, 1, 2, 2, 2, 3, 3);
            dt.Rows.Add(0, 1, 2, 3, 3, 3, 5, 5);
            dt.Rows.Add(1, 2, 4, 4, 6, 8, 8, 10);
            dt.Rows.Add(1, 2, 4, 4, 6, 8, 8, 10);
            dt.Rows.Add(0, 1, 2, 3, 3, 3, 5, 5);
            dt.Rows.Add(0, 0, 1, 2, 2, 2, 3, 3);
            dt.Rows.Add(0, 0, 1, 1, 1, 1, 2, 2);
            dt.Rows.Add(0, 0, 1, 1, 1, 1, 2, 2);
            dt.Rows.Add(0, 0, 1, 2, 2, 2, 3, 3);
            dt.Rows.Add(0, 1, 2, 3, 3, 3, 5, 5);
            dt.Rows.Add(1, 2, 4, 4, 6, 8, 8, 10);
            dt.Rows.Add(1, 2, 4, 4, 6, 8, 8, 10);
            dt.Rows.Add(0, 1, 2, 3, 3, 3, 5, 5);
            dt.Rows.Add(0, 0, 1, 2, 2, 2, 3, 3);
            dt.Rows.Add(0, 0, 1, 1, 1, 1, 2, 2);
            //sr.SetFunction("sin(x1)*cos(x2)/(sqrt(sqrt(x1*x1+x2*x2))+1)*10");
            sr.Mapdata = dt;
            sr.StartPoint = new PointF(0, 0);
            sr.EndPoint = new PointF(7, 15);
            sr.Density = 1;
            Form1_Resize(null, null);
            ResizeRedraw = true;
            DoubleBuffered = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            sr.RenderSurface(e.Graphics);

        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            sr.ReCalculateTransformationsCoeficients(pov_x, pov_y, pov_z, 0, 0, ClientRectangle.Width, ClientRectangle.Height, 0.5, 0, 0);
        }

        private void tbHue_Scroll(object sender, EventArgs e)
        {
            sr.ColorSchema = new ColorSchema(tbHue.Value);
            Console.WriteLine(tbHue.Value.ToString());
            //sr.ReCalculateTransformationsCoeficients(70, 35, 40, 0, 0, ClientRectangle.Width, ClientRectangle.Height, 0.5, 0, 0);
            
            Invalidate();
        }

        private void Plot3DMainForm_Load(object sender, EventArgs e)
        {

        }

        private void Plot3DMainForm_MouseDown(object sender, MouseEventArgs e)
        {
            m_IsDragging = true;
            m_p = e.Location;
        }

        private void Plot3DMainForm_MouseUp(object sender, MouseEventArgs e)
        {
            m_IsDragging = false;
        }

        private void Plot3DMainForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (m_IsDragging)
            {
                if (e.Button == MouseButtons.Left)
                {
                    int deltay = m_p.X - e.Location.X;
                    int deltax = m_p.Y - e.Location.Y;
                    pov_x -= deltax/2;
                    pov_y += deltay/2;
                }
                else if (e.Button == MouseButtons.Right)
                {
                    int deltaz = m_p.Y - e.Location.Y;
                    pov_z -= deltaz/2;
                }
                else if (e.Button == MouseButtons.Middle)
                {
                    int deltax = m_p.X - e.Location.X;
                    int deltay = m_p.Y - e.Location.Y;
                    pan_x -= deltax / 2;
                    pan_y -= deltay / 2;
                }

                sr.ReCalculateTransformationsCoeficients(pov_x, pov_y, pov_z, pan_x, pan_y, ClientRectangle.Width, ClientRectangle.Height, 0.5, 0, 0);
                Invalidate();
                m_p = e.Location;
            }
        }
    }
}
